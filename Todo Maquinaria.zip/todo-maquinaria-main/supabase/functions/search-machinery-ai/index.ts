
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.7.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Initialize Supabase client
const supabaseClient = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
);

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { searchQuery, limit = 10 } = await req.json();

    if (!searchQuery) {
      throw new Error('Search query is required');
    }

    console.log('Processing search query:', searchQuery);

    // Use full text search on machinery table instead of embeddings
    const { data: searchResults, error } = await supabaseClient
      .from('machinery')
      .select(`
        *,
        images (
          url,
          is_primary
        ),
        market_prices (
          platform,
          price,
          currency
        )
      `)
      .textSearch('name', searchQuery)
      .or(`description.ilike.%${searchQuery}%`)
      .limit(limit);

    if (error) {
      throw error;
    }

    return new Response(JSON.stringify(searchResults), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error in search:', error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
