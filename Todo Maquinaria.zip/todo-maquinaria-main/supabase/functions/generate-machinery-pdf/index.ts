
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { PDFDocument, rgb, StandardFonts } from "https://cdn.skypack.dev/pdf-lib@1.17.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      headers: {
        ...corsHeaders,
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
      },
      status: 200
    });
  }

  try {
    console.log('Iniciando generación de PDF...');
    
    const requestBody = await req.json();
    console.log('Datos recibidos:', JSON.stringify(requestBody, null, 2));

    const { machines, settings } = requestBody;

    if (!machines || !Array.isArray(machines)) {
      return new Response(
        JSON.stringify({ error: 'No se recibieron datos válidos' }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200
        }
      );
    }

    // Crear documento PDF
    const pdfDoc = await PDFDocument.create();
    const helvetica = await pdfDoc.embedFont(StandardFonts.Helvetica);
    const helveticaBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);

    // Configurar colores por defecto si no se proporcionan
    const colors = {
      primary: '#1a1a1a',
      secondary: '#4a4a4a',
      accent: '#0ea5e9',
      ...settings?.colors
    };

    // Convertir hex a RGB
    const hexToRgb = (hex: string) => {
      const cleanHex = hex.replace('#', '');
      const r = parseInt(cleanHex.substring(0, 2), 16) / 255;
      const g = parseInt(cleanHex.substring(2, 4), 16) / 255;
      const b = parseInt(cleanHex.substring(4, 6), 16) / 255;
      return { r, g, b };
    };

    // Procesar cada máquina
    for (const machine of machines) {
      try {
        console.log(`Procesando máquina: ${machine.name}`);
        
        const page = pdfDoc.addPage([595.28, 841.89]); // A4
        let yOffset = page.getHeight() - 50;

        // Colores
        const primaryColor = hexToRgb(colors.primary);
        const secondaryColor = hexToRgb(colors.secondary);

        // Título
        page.drawText(machine.name || 'Sin nombre', {
          x: 50,
          y: yOffset,
          size: 24,
          font: helveticaBold,
          color: rgb(primaryColor.r, primaryColor.g, primaryColor.b),
        });
        yOffset -= 40;

        // Detalles
        const details = [
          `Precio: $${machine.price?.toLocaleString() || 'N/A'} USD`,
          `Año: ${machine.year || 'N/A'}`,
          `Ubicación: ${machine.location || 'N/A'}`,
          `Descripción: ${machine.description || 'N/A'}`
        ];

        for (const detail of details) {
          page.drawText(detail, {
            x: 50,
            y: yOffset,
            size: 12,
            font: helvetica,
            color: rgb(secondaryColor.r, secondaryColor.g, secondaryColor.b),
            maxWidth: 500,
          });
          yOffset -= 20;
        }

        // Procesar imagen si existe
        if (machine.imageUrl) {
          try {
            console.log(`Cargando imagen: ${machine.imageUrl}`);
            const imageResponse = await fetch(machine.imageUrl);
            
            if (imageResponse.ok) {
              const imageArrayBuffer = await imageResponse.arrayBuffer();
              const imageFormat = machine.imageUrl.toLowerCase().endsWith('.png') ? 'png' : 'jpeg';
              
              const pdfImage = imageFormat === 'png' 
                ? await pdfDoc.embedPng(imageArrayBuffer)
                : await pdfDoc.embedJpg(imageArrayBuffer);

              // Ajustar tamaño de imagen
              const maxWidth = 400;
              const scale = maxWidth / pdfImage.width;
              const width = pdfImage.width * scale;
              const height = pdfImage.height * scale;

              page.drawImage(pdfImage, {
                x: 50,
                y: yOffset - height,
                width,
                height,
              });
              
              yOffset -= (height + 20);
            }
          } catch (imageError) {
            console.error('Error al procesar imagen:', imageError);
          }
        }
      } catch (machineError) {
        console.error(`Error al procesar máquina ${machine.name}:`, machineError);
      }
    }

    // Generar PDF
    console.log('Generando PDF final...');
    const pdfBytes = await pdfDoc.save();
    
    // Convertir a Base64
    const bytes = new Uint8Array(pdfBytes);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    const base64 = btoa(binary);

    console.log('PDF generado exitosamente');
    return new Response(
      JSON.stringify({ 
        pdfContent: base64,
        success: true 
      }),
      { 
        headers: { 
          ...corsHeaders, 
          'Content-Type': 'application/json'
        },
        status: 200
      }
    );

  } catch (error) {
    console.error('Error general:', error);
    return new Response(
      JSON.stringify({
        error: 'Error al generar el PDF',
        details: error.message,
        success: false
      }),
      { 
        headers: { 
          ...corsHeaders, 
          'Content-Type': 'application/json'
        },
        status: 200
      }
    );
  }
});
