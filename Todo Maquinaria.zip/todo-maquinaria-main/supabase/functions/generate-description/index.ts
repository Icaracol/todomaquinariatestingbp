
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import "https://deno.land/x/xhr@0.1.0/mod.ts"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { name, category, year, specifications } = await req.json()

    const response = await fetch('https://api.deepseek.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${Deno.env.get('DEEPSEEK_API_KEY')}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'deepseek-chat',
        messages: [
          {
            role: 'system',
            content: `Eres un experto en maquinaria industrial y construcción. 
            Tu tarea es generar descripciones profesionales, detalladas y optimizadas para SEO.
            Incluye detalles técnicos relevantes y beneficios clave.
            Usa un tono profesional pero accesible.
            La descripción debe tener entre 100-150 palabras.`
          },
          {
            role: 'user',
            content: `Genera una descripción optimizada para esta máquina:
            Nombre: ${name}
            Categoría: ${category}
            Año: ${year}
            Especificaciones: ${JSON.stringify(specifications)}`
          }
        ],
        temperature: 0.7,
        max_tokens: 500
      }),
    })

    const data = await response.json()
    const description = data.choices[0].message.content

    console.log('Generated description:', description)

    return new Response(
      JSON.stringify({ description }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  } catch (error) {
    console.error('Error in generate-description:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    )
  }
})
