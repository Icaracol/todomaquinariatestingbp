
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.7.1'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface SearchResult {
  title: string;
  price: string;
  url: string;
  source: string;
  image?: string;
  location?: string;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { query } = await req.json()
    const firecrawlApiKey = Deno.env.get('FIRECRAWL_API_KEY')
    
    if (!firecrawlApiKey) {
      throw new Error('Firecrawl API key not configured')
    }

    console.log('Searching for:', query)

    const sources = [
      {
        url: `https://www.facebook.com/marketplace/search?q=${encodeURIComponent(query)}`,
        selectors: {
          items: 'div[data-testid="marketplace_feed_item"]',
          title: 'span[dir="auto"]',
          price: 'span[dir="auto"]',
          image: 'img',
          location: 'span[dir="auto"]'
        }
      },
      {
        url: `https://listado.mercadolibre.com.ar/${encodeURIComponent(query)}`,
        selectors: {
          items: '.ui-search-layout__item',
          title: '.ui-search-item__title',
          price: '.price-tag-amount',
          image: '.ui-search-result-image__element',
          location: '.ui-search-item__location'
        }
      },
      {
        url: `https://www.agrofy.com.ar/buscar?q=${encodeURIComponent(query)}`,
        selectors: {
          items: '.product-item',
          title: '.product-item-link',
          price: '.price',
          image: '.product-image-photo',
          location: '.location'
        }
      }
    ]

    const results: SearchResult[] = []

    for (const source of sources) {
      try {
        console.log(`Crawling ${source.url}`)
        
        const response = await fetch('https://api.firecrawl.co/scrape', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${firecrawlApiKey}`
          },
          body: JSON.stringify({
            url: source.url,
            selectors: source.selectors,
            wait: 2000
          })
        })

        const data = await response.json()
        
        if (data.success && data.results) {
          results.push(...data.results.map((item: any) => ({
            title: item.title,
            price: item.price,
            url: item.url,
            image: item.image,
            location: item.location,
            source: new URL(source.url).hostname
          })))
        }

        console.log(`Found ${data.results?.length || 0} results from ${source.url}`)
      } catch (error) {
        console.error(`Error crawling ${source.url}:`, error)
      }
    }

    return new Response(
      JSON.stringify({ results }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  } catch (error) {
    console.error('Error in search-machinery:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    )
  }
})
