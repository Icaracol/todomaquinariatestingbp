
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.7.1'
import { parse } from 'https://deno.land/std@0.181.0/encoding/csv.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface MachineData {
  name: string;
  description?: string;
  year?: number;
  price?: number;
  location?: string;
  status?: 'available' | 'reserved' | 'sold';
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const formData = await req.formData()
    const file = formData.get('file')
    const userId = req.headers.get('x-user-id')

    if (!file || !userId) {
      return new Response(
        JSON.stringify({ error: 'Archivo CSV y usuario requeridos' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
      )
    }

    const text = await file.text()
    const records = await parse(text, {
      skipFirstRow: true,
      columns: ['name', 'description', 'year', 'price', 'location', 'status']
    }) as MachineData[]

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const machineRecords = records.map(record => ({
      ...record,
      user_id: userId,
      year: record.year ? parseInt(record.year.toString()) : null,
      price: record.price ? parseFloat(record.price.toString()) : null,
      status: record.status || 'available'
    }))

    const { data, error } = await supabase
      .from('machinery')
      .insert(machineRecords)
      .select()

    if (error) {
      console.error('Error inserting records:', error)
      return new Response(
        JSON.stringify({ error: 'Error al importar maquinaria' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
      )
    }

    return new Response(
      JSON.stringify({
        message: 'Importación exitosa',
        count: data.length,
        data
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Error processing CSV:', error)
    return new Response(
      JSON.stringify({ error: 'Error procesando el archivo CSV' }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    )
  }
})
