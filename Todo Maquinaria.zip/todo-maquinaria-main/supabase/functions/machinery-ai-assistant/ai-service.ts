
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { getEnvVars } from './config.ts';

const { openRouterApiKey } = getEnvVars();

export async function callOpenRouterAPI(systemPrompt: string, userPrompt: string, temperature = 0.7) {
  console.log(`Calling OpenRouter API with prompt: ${userPrompt.substring(0, 50)}...`);
  
  try {
    const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openRouterApiKey}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': 'https://maquinariasweb.com',
        'X-Title': 'Maquinarias Web AI Assistant'
      },
      body: JSON.stringify({
        model: "deepseek/deepseek-chat",
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
        temperature: temperature,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error(`OpenRouter API error (${response.status}):`, errorText);
      throw new Error(`OpenRouter API error: ${response.status} - ${errorText}`);
    }

    const result = await response.json();
    return result.choices[0].message.content.trim();
  } catch (error) {
    console.error('Error calling OpenRouter API:', error);
    throw new Error(`Error calling AI service: ${error.message}`);
  }
}
