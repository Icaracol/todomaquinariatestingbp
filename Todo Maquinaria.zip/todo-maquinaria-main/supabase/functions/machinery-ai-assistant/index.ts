
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { corsHeaders } from './config.ts';
import { improveMachineTitle } from './handlers/title-handler.ts';
import { suggestCategory, suggestSubcategory } from './handlers/category-handler.ts';
import { suggestMarketPrice } from './handlers/price-handler.ts';
import { generateMachineDescription } from './handlers/description-handler.ts';
import { analyzeCompleteForm } from './handlers/analysis-handler.ts';
import { suggestBrand } from './handlers/brand-handler.ts';

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { action, data } = await req.json();
    let result = null;
    
    console.log(`Processing AI action: ${action}`);

    switch (action) {
      case 'improveTitle':
        result = await improveMachineTitle(data);
        break;
      case 'suggestCategory':
        result = await suggestCategory(data);
        break;
      case 'suggestSubcategory':
        result = await suggestSubcategory(data);
        break;
      case 'suggestMarketPrice':
        result = await suggestMarketPrice(data);
        break;
      case 'generateDescription':
        result = await generateMachineDescription(data);
        break;
      case 'analyzeCompleteForm':
        result = await analyzeCompleteForm(data);
        break;
      case 'suggestBrand':
        result = await suggestBrand(data);
        break;
      default:
        throw new Error(`Unknown action: ${action}`);
    }

    return new Response(JSON.stringify({ result }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Error in machinery-ai-assistant function:', error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
