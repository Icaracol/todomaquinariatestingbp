
import { callOpenRouterAPI } from '../ai-service.ts';

export async function generateMachineDescription(data: { 
  name: string, 
  category?: string, 
  year?: string, 
  specifications?: Record<string, string>,
  type?: "technical" | "commercial" | "seo" 
}) {
  const type = data.type || "commercial";
  let systemPrompt = 'Eres un experto en redacción de descripciones para maquinaria industrial y agrícola.';
  
  switch (type) {
    case "technical":
      systemPrompt += ' Genera descripciones técnicas y detalladas enfocadas en especificaciones y rendimiento.';
      break;
    case "commercial":
      systemPrompt += ' Genera descripciones persuasivas enfocadas en beneficios y ventajas comerciales.';
      break;
    case "seo":
      systemPrompt += ' Genera descripciones optimizadas para SEO con palabras clave relevantes y estructura adecuada.';
      break;
  }
  
  return callOpenRouterAPI(
    systemPrompt,
    `Genera una descripción ${type === "technical" ? "técnica" : type === "commercial" ? "comercial" : "optimizada para SEO"} para: 
      Nombre: ${data.name}
      Categoría: ${data.category || 'No especificada'}
      Año: ${data.year || 'No especificado'}
      Especificaciones: ${data.specifications ? JSON.stringify(data.specifications) : 'No especificadas'}
      
      La descripción debe ser detallada, profesional y atractiva para potenciales compradores. Escribe en español y utiliza un tono profesional.`,
    0.7
  );
}
