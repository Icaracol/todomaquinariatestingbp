
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { getEnvVars } from '../config.ts';
import { callOpenRouterAPI } from '../ai-service.ts';

const { supabaseUrl, supabaseKey } = getEnvVars();
const supabase = createClient(supabaseUrl, supabaseKey);

export async function suggestBrand(data: { name: string, categoryId: string }) {
  const { data: categoryData, error: categoryError } = await supabase
    .from('categories')
    .select('name')
    .eq('id', data.categoryId)
    .single();
  
  if (categoryError) throw categoryError;
  
  const categoryName = categoryData?.name || '';
  
  return callOpenRouterAPI(
    'Eres un experto en marcas de maquinaria industrial y agrícola.',
    `Basado en este nombre de máquina: "${data.name}", y su categoría: "${categoryName}", ¿qué marca es la más probable? Responde SOLAMENTE con el nombre de la marca más apropiada.`,
    0.3
  );
}
