
import { callOpenRouterAPI } from '../ai-service.ts';

export async function improveMachineTitle(data: { name: string }) {
  return callOpenRouterAPI(
    'Eres un experto en maquinaria industrial y agrícola. Tu tarea es mejorar títulos de anuncios para hacerlos más atractivos y específicos.',
    `Necesito un título mejorado para este anuncio de maquinaria: "${data.name}". Proporciona SOLO el título mejorado, sin comentarios adicionales.`
  );
}
