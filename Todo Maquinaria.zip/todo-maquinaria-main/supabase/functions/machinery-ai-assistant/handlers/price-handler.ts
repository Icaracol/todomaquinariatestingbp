
import { callOpenRouterAPI } from '../ai-service.ts';

export async function suggestMarketPrice(data: { name: string, year: string, category: string }) {
  const priceText = await callOpenRouterAPI(
    'Eres un experto en valoración de maquinaria industrial y agrícola en el mercado argentino. Proporciona estimaciones realistas basadas en los datos del mercado actual.',
    `Estima un precio de mercado razonable en pesos argentinos (ARS) para: "${data.name}", año ${data.year || 'desconocido'}, categoría: ${data.category || 'desconocida'}. Responde SOLAMENTE con el valor numérico, sin símbolos ni texto adicional.`,
    0.5
  );
  
  const price = priceText.replace(/[^\d]/g, '');
  
  return {
    price: price,
    confidence: 0.75,
    message: `Precio de mercado estimado: ARS ${parseInt(price).toLocaleString('es-AR')}`
  };
}
