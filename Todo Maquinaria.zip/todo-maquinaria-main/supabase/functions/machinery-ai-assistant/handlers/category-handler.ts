
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { getEnvVars } from '../config.ts';
import { callOpenRouterAPI } from '../ai-service.ts';

const { supabaseUrl, supabaseKey } = getEnvVars();
const supabase = createClient(supabaseUrl, supabaseKey);

export async function suggestCategory(data: { name: string }) {
  const { data: categories, error } = await supabase
    .from('categories')
    .select('*')
    .is('parent_id', null);
  
  if (error) throw error;
  
  const categoryNames = categories.map(cat => cat.name).join(', ');
  
  const suggestedCategoryName = await callOpenRouterAPI(
    'Eres un experto en clasificación de maquinaria industrial y agrícola.',
    `Basado en este nombre de máquina: "${data.name}", ¿qué categoría es la más apropiada entre las siguientes opciones: ${categoryNames}? Responde SOLAMENTE con el nombre exacto de la categoría que corresponda mejor.`,
    0.3
  );
  
  const suggestedCategory = categories.find(cat => 
    cat.name.toLowerCase() === suggestedCategoryName.toLowerCase()
  );
  
  return {
    id: suggestedCategory?.id || null,
    name: suggestedCategoryName,
    confidence: suggestedCategory ? 0.9 : 0.5
  };
}

export async function suggestSubcategory(data: { name: string, mainCategoryId: string }) {
  const { data: subcategories, error } = await supabase
    .from('categories')
    .select('*')
    .eq('parent_id', data.mainCategoryId);
  
  if (error) throw error;
  
  if (subcategories.length === 0) {
    return { id: null, name: "No se encontraron subcategorías", confidence: 0 };
  }
  
  const subcategoryNames = subcategories.map(cat => cat.name).join(', ');
  
  const suggestedSubcategoryName = await callOpenRouterAPI(
    'Eres un experto en clasificación detallada de maquinaria industrial y agrícola.',
    `Basado en este nombre de máquina: "${data.name}", ¿qué subcategoría es la más apropiada entre las siguientes opciones: ${subcategoryNames}? Responde SOLAMENTE con el nombre exacto de la subcategoría que corresponda mejor.`,
    0.3
  );
  
  const suggestedSubcategory = subcategories.find(cat => 
    cat.name.toLowerCase() === suggestedSubcategoryName.toLowerCase()
  );
  
  return {
    id: suggestedSubcategory?.id || null,
    name: suggestedSubcategoryName,
    confidence: suggestedSubcategory ? 0.85 : 0.4
  };
}
