
interface ListingData {
  name: string;
  category: string;
  subcategory?: string;
  year?: string;
  price?: string;
  location?: string;
  description?: string;
}

function calculateListingScore(data: ListingData): number {
  let score = 0;
  const totalPoints = 100;
  
  score += data.name && data.name.length > 5 ? (Math.min(data.name.length, 30) / 30) * 20 : 0;
  score += data.category ? 15 : 0;
  score += data.subcategory ? 10 : 0;
  score += data.year ? 10 : 0;
  score += data.price ? 15 : 0;
  score += data.location ? 10 : 0;
  score += data.description ? Math.min(data.description.length, 300) / 300 * 20 : 0;
  
  return Math.min(Math.round(score), totalPoints);
}

export async function analyzeCompleteForm(data: ListingData) {
  const analysis = await callOpenRouterAPI(
    'Eres un experto en marketing de maquinaria industrial y agrícola. Tu tarea es analizar anuncios y proporcionar sugerencias concretas para mejorarlos y maximizar su impacto comercial.',
    `Analiza este anuncio de maquinaria y proporciona sugerencias específicas para mejorarlo:
      Nombre: ${data.name}
      Categoría: ${data.category || 'No especificada'}
      Subcategoría: ${data.subcategory || 'No especificada'}
      Año: ${data.year || 'No especificado'}
      Precio: ${data.price || 'No especificado'}
      Ubicación: ${data.location || 'No especificada'}
      Descripción: ${data.description || 'No especificada'}
      
      Proporciona un análisis BREVE con sugerencias específicas para mejorar el atractivo y efectividad del anuncio, con énfasis en los elementos faltantes o mejorables.`,
    0.7
  );
  
  return {
    analysis: analysis,
    score: calculateListingScore(data)
  };
}
