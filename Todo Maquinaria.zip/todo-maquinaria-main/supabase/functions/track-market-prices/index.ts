
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.38.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface MarketPrice {
  platform: string;
  price: number;
  currency: string;
  url: string;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { machineryId } = await req.json();

    // Initialize Supabase client
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Fetch machinery details
    const { data: machinery, error: machineryError } = await supabaseClient
      .from('machinery')
      .select('name, year, category_id')
      .eq('id', machineryId)
      .single();

    if (machineryError) throw machineryError;

    // Simulate fetching prices from different platforms
    // In a real implementation, you would make API calls to each platform
    const marketPrices: MarketPrice[] = [
      {
        platform: 'mercadolibre',
        price: 50000 + Math.random() * 10000,
        currency: 'USD',
        url: `https://mercadolibre.com/search?q=${encodeURIComponent(machinery.name)}`,
      },
      {
        platform: 'agrofy',
        price: 48000 + Math.random() * 12000,
        currency: 'USD',
        url: `https://agrofy.com/search?q=${encodeURIComponent(machinery.name)}`,
      },
    ];

    // Update prices in database
    for (const price of marketPrices) {
      const { error: updateError } = await supabaseClient
        .from('machinery_market_prices')
        .upsert({
          machinery_id: machineryId,
          platform: price.platform,
          price: price.price,
          currency: price.currency,
          external_url: price.url,
          last_checked: new Date().toISOString(),
        }, {
          onConflict: 'machinery_id,platform'
        });

      if (updateError) throw updateError;
    }

    return new Response(
      JSON.stringify({ success: true, prices: marketPrices }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      },
    );
  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      },
    );
  }
});
