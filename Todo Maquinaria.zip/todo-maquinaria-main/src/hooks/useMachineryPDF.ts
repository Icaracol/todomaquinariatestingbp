
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/lib/supabase";
import type { DbMachinery, MachinerySpec } from "@/types/machinery";
import { useUserLimits } from "./useUserLimits";

export function useMachineryPDF() {
  const { toast } = useToast();
  const { checkLimits, incrementCounter } = useUserLimits();

  const generatePDF = async (selectedMachines: DbMachinery[]) => {
    try {
      // Validación inicial
      if (!selectedMachines?.length) {
        throw new Error('No hay maquinaria seleccionada para generar el PDF');
      }

      // Verificar límites de usuario
      const limits = await checkLimits('download_pdf');
      
      if (!limits.allowed) {
        toast({
          title: "Límite alcanzado",
          description: `Has alcanzado el límite de descargas (${limits.currentUsage}/${limits.limitValue}). Actualiza tu plan para continuar.`,
          variant: "destructive"
        });
        return;
      }

      // Mostrar toast de proceso
      const loadingToast = toast({
        title: "Generando PDF",
        description: "Por favor espere mientras se genera el documento...",
      });

      // Verificar autenticación
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Usuario no autenticado');
      
      // Obtener configuración del PDF
      const { data: settingsData, error: settingsError } = await supabase
        .from('user_pdf_preferences')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (settingsError) {
        console.error('Error al obtener configuración del PDF:', settingsError);
      }

      // Obtener las especificaciones para cada máquina
      const machineSpecsPromises = selectedMachines.map(machine => 
        supabase
          .from('machinery_specs')
          .select('*')
          .eq('machinery_id', machine.id)
      );

      const specsResults = await Promise.all(machineSpecsPromises);
      const machineSpecs = new Map<string, MachinerySpec[]>();
      
      specsResults.forEach((result, index) => {
        if (!result.error && result.data) {
          machineSpecs.set(selectedMachines[index].id, result.data);
        }
      });

      // Preprocesar datos de maquinaria
      const machinesData = selectedMachines.map(m => ({
        id: m.id,
        name: m.name,
        description: m.description,
        price: m.price,
        year: m.year,
        location: m.location,
        imageUrl: m.images?.[0]?.url || null,
        specifications: machineSpecs.get(m.id) || []
      }));

      // Configuración por defecto si no hay preferencias guardadas
      const defaultSettings = {
        template_id: 'modern',
        primary_color: '#1a1a1a',
        secondary_color: '#4a4a4a',
        accent_color: '#0ea5e9'
      };

      console.log('Enviando datos para generar PDF:', {
        machines: machinesData,
        settings: settingsData || defaultSettings
      });

      // Generar PDF
      const response = await supabase.functions.invoke('generate-machinery-pdf', {
        body: { 
          machines: machinesData,
          settings: {
            templateId: settingsData?.template_id || defaultSettings.template_id,
            colors: {
              primary: settingsData?.primary_color || defaultSettings.primary_color,
              secondary: settingsData?.secondary_color || defaultSettings.secondary_color,
              accent: settingsData?.accent_color || defaultSettings.accent_color
            }
          }
        }
      });

      if (response.error) {
        console.error('Error en la generación del PDF:', response.error);
        throw new Error(response.error.message || 'Error al generar el PDF');
      }

      if (!response.data?.pdfContent) {
        throw new Error('No se recibió el contenido del PDF');
      }

      // Convertir y descargar PDF
      try {
        const pdfBlob = new Blob(
          [Uint8Array.from(atob(response.data.pdfContent), c => c.charCodeAt(0))], 
          { type: 'application/pdf' }
        );
        const url = URL.createObjectURL(pdfBlob);

        const link = document.createElement('a');
        link.href = url;
        link.download = `catalogo-maquinaria-${new Date().toISOString().split('T')[0]}.pdf`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        // Limpiar
        URL.revokeObjectURL(url);

        // Incrementar contador después de descarga exitosa
        await incrementCounter('download_pdf');

        // Cerrar toast de carga y mostrar éxito
        loadingToast.dismiss();
        toast({
          title: "PDF generado exitosamente",
          description: "El documento ha sido generado y descargado correctamente."
        });
      } catch (error) {
        console.error('Error en la descarga del PDF:', error);
        throw new Error('Error al descargar el PDF');
      }
    } catch (error: any) {
      console.error('Error al generar PDF:', error);
      toast({
        title: "Error al generar PDF",
        description: error.message || "No se pudo generar el PDF. Por favor intente nuevamente.",
        variant: "destructive"
      });
    }
  };

  return { generatePDF };
}
