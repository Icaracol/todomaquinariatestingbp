
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/lib/supabase";
import { MachineFormData } from "@/types/machinery";
import { createMachinery, getCategories } from "@/services/machinery";

const STORAGE_KEY = 'pendingMachinery';
const STEP_STORAGE_KEY = 'currentInventoryStep';

export const useInventoryForm = () => {
  const [formData, setFormData] = useState<MachineFormData>(() => {
    const savedData = localStorage.getItem(STORAGE_KEY);
    return savedData ? JSON.parse(savedData) : {
      nombre: "",
      categoria: "",
      descripcion: "",
      precio: "",
      ubicacion: "",
      año: "",
      estado: "available",
      tipo: "both",
      imagenes: [],
      category_id: "",
    };
  });

  const { toast } = useToast();
  const navigate = useNavigate();

  const { data: categories } = useQuery({
    queryKey: ['categories'],
    queryFn: getCategories
  });

  const mutation = useMutation({
    mutationFn: createMachinery,
    onSuccess: () => {
      toast({
        title: "¡Éxito!",
        description: "Tu maquinaria ha sido publicada correctamente",
      });
      localStorage.removeItem(STORAGE_KEY);
      localStorage.removeItem(STEP_STORAGE_KEY);
      navigate("/dashboard");
    },
    onError: (error: Error) => {
      console.error("Error en mutation:", error);
      
      if (error.message.includes("no autenticado") || error.message.includes("sesión expirada")) {
        localStorage.setItem('shouldPublishAfterLogin', 'true');
        localStorage.setItem('pendingMachinery', JSON.stringify(formData));
        
        toast({
          title: "Sesión expirada",
          description: "Tu sesión ha expirado. Por favor, inicia sesión nuevamente para publicar tu maquinaria.",
        });
        
        navigate("/login", { 
          state: { 
            returnTo: "/subir-inventario",
            message: "Por favor inicia sesión nuevamente para completar la publicación"
          } 
        });
      } else {
        toast({
          title: "Error al publicar",
          description: error.message || "Ocurrió un error al publicar tu maquinaria. Por favor intenta nuevamente.",
          variant: "destructive",
        });
      }
    },
  });

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData(prev => {
      const newData = {
        ...prev,
        [name]: value,
      };
      
      // Always save to localStorage when data changes
      localStorage.setItem(STORAGE_KEY, JSON.stringify(newData));
      console.log(`Form data updated for ${name}:`, value);
      return newData;
    });
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      setFormData(prev => {
        const newData = {
          ...prev,
          imagenes: files
        };
        // Store updated form data but exclude File objects
        localStorage.setItem(STORAGE_KEY, JSON.stringify({
          ...newData,
          imagenes: [] // Don't store File objects in localStorage
        }));
        return newData;
      });
    }
  };

  const handleSubmit = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        localStorage.setItem('shouldPublishAfterLogin', 'true');
        localStorage.setItem('pendingMachinery', JSON.stringify(formData));
        
        toast({
          title: "Sesión no iniciada",
          description: "Por favor inicia sesión para publicar tu maquinaria.",
        });
        
        navigate("/login", { 
          state: { 
            returnTo: "/subir-inventario",
            message: "Inicia sesión para publicar tu maquinaria"
          } 
        });
        return;
      }

      if (!formData.nombre || !formData.precio || !formData.ubicacion) {
        toast({
          title: "Datos incompletos",
          description: "Por favor completa todos los campos obligatorios antes de publicar.",
          variant: "destructive",
        });
        return;
      }

      await mutation.mutateAsync(formData);
    } catch (error) {
      console.error("Error en el proceso de publicación:", error);
      toast({
        title: "Error inesperado",
        description: "Ocurrió un error al procesar tu solicitud. Por favor intenta nuevamente.",
        variant: "destructive",
      });
    }
  };

  useEffect(() => {
    // Load saved data on component mount
    const savedData = localStorage.getItem(STORAGE_KEY);
    if (savedData) {
      try {
        const parsedData = JSON.parse(savedData);
        console.log("Loaded saved form data from localStorage:", parsedData);
        setFormData(prev => ({
          ...prev,
          ...parsedData,
          imagenes: prev.imagenes // Keep current File objects
        }));
      } catch (error) {
        console.error("Error parsing saved form data:", error);
      }
    }
  }, []);

  return {
    formData,
    categories,
    handleImageUpload,
    handleInputChange,
    handleSubmit,
    mutation
  };
};
