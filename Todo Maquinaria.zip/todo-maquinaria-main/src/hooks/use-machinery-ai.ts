
import { useState } from "react";
import { supabase } from "@/lib/supabase";
import { useToast } from "@/hooks/use-toast";

export const useMachineryAI = () => {
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const callMachineryAI = async (action: string, data: any) => {
    setIsLoading(true);
    try {
      console.log(`Calling machinery-ai-assistant with action: ${action}`);
      const response = await supabase.functions.invoke('machinery-ai-assistant', {
        body: { action, data }
      });

      if (response.error) {
        console.error(`Error in ${action}:`, response.error);
        throw new Error(response.error.message || 'Error al procesar la solicitud');
      }

      console.log(`Successful response for ${action}:`, response.data);
      return response.data.result;
    } catch (error) {
      console.error(`Error in ${action}:`, error);
      toast({
        title: "Error del asistente AI",
        description: error instanceof Error ? error.message : "Ocurrió un error inesperado",
        variant: "destructive"
      });
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const improveMachineTitle = async (name: string) => {
    return callMachineryAI('improveTitle', { name });
  };

  const suggestCategory = async (name: string) => {
    return callMachineryAI('suggestCategory', { name });
  };

  const suggestSubcategory = async (name: string, mainCategoryId: string) => {
    return callMachineryAI('suggestSubcategory', { name, mainCategoryId });
  };

  const suggestMarketPrice = async (name: string, year: string, category: string) => {
    return callMachineryAI('suggestMarketPrice', { name, year, category });
  };

  const generateDescription = async (
    name: string,
    category?: string,
    year?: string,
    specifications?: Record<string, string>,
    type: "technical" | "commercial" | "seo" = "commercial"
  ) => {
    return callMachineryAI('generateDescription', { name, category, year, specifications, type });
  };

  const analyzeCompleteForm = async (formData: {
    name: string,
    category: string,
    subcategory?: string,
    year?: string,
    price?: string,
    location?: string,
    description?: string
  }) => {
    return callMachineryAI('analyzeCompleteForm', formData);
  };

  // Implementación del método suggestBrand
  const suggestBrand = async (name: string, categoryId: string) => {
    return callMachineryAI('suggestBrand', { name, categoryId });
  };

  return {
    isLoading,
    improveMachineTitle,
    suggestCategory,
    suggestSubcategory,
    suggestMarketPrice,
    generateDescription,
    analyzeCompleteForm,
    suggestBrand
  };
};
