
import { useState } from 'react';
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/lib/supabase";
import type { UserRole, UserAdminData } from "@/types/admin";

export function useAdmin() {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const isAdmin = async (): Promise<boolean> => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        console.log('No user found');
        return false;
      }

      console.log('Checking admin status for user:', user.email);

      const { data, error } = await supabase
        .rpc('is_admin', { user_id: user.id });

      if (error) {
        console.error('Error checking admin role:', error);
        return false;
      }

      console.log('Admin role check result:', data);
      return data ?? false;
    } catch (error) {
      console.error('Error checking admin status:', error);
      return false;
    }
  };

  const getUserList = async (): Promise<UserAdminData[]> => {
    try {
      setLoading(true);
      
      // Verificar primero si el usuario es admin
      const adminStatus = await isAdmin();
      if (!adminStatus) {
        toast({
          title: "Acceso denegado",
          description: "No tienes permisos para ver esta información",
          variant: "destructive"
        });
        return [];
      }

      const { data, error } = await supabase
        .from('admin_user_stats')
        .select('*');

      if (error) {
        // Manejar específicamente el error de acceso denegado
        if (error.message.includes('Access denied')) {
          toast({
            title: "Acceso denegado",
            description: "No tienes permisos para ver esta información",
            variant: "destructive"
          });
        } else {
          toast({
            title: "Error",
            description: "No se pudo obtener la lista de usuarios",
            variant: "destructive"
          });
        }
        console.error('Error fetching users:', error);
        return [];
      }

      if (!data) {
        return [];
      }

      return data;
    } catch (error) {
      console.error('Error fetching users:', error);
      toast({
        title: "Error",
        description: "No se pudo obtener la lista de usuarios",
        variant: "destructive"
      });
      return [];
    } finally {
      setLoading(false);
    }
  };

  const updateUserRole = async (userId: string, role: UserRole): Promise<boolean> => {
    try {
      const adminStatus = await isAdmin();
      if (!adminStatus) {
        toast({
          title: "Acceso denegado",
          description: "No tienes permisos para realizar esta acción",
          variant: "destructive"
        });
        return false;
      }

      const { error } = await supabase
        .from('user_limits')
        .update({ 
          subscription_tier: role,
          updated_at: new Date().toISOString()
        })
        .eq('user_id', userId);

      if (error) throw error;

      toast({
        title: "Role actualizado",
        description: `El usuario ha sido actualizado a ${role}`
      });
      
      return true;
    } catch (error) {
      console.error('Error updating user role:', error);
      toast({
        title: "Error",
        description: "No se pudo actualizar el rol del usuario",
        variant: "destructive"
      });
      return false;
    }
  };

  const resetUserLimits = async (userId: string): Promise<boolean> => {
    try {
      const adminStatus = await isAdmin();
      if (!adminStatus) {
        toast({
          title: "Acceso denegado",
          description: "No tienes permisos para realizar esta acción",
          variant: "destructive"
        });
        return false;
      }

      const { error } = await supabase
        .from('user_limits')
        .update({ 
          machinery_count: 0,
          downloads_count: 0,
          downloads_reset_date: new Date().toISOString(),
          updated_at: new Date().toISOString()
        })
        .eq('user_id', userId);

      if (error) throw error;

      toast({
        title: "Límites reseteados",
        description: "Los límites del usuario han sido reseteados exitosamente"
      });
      
      return true;
    } catch (error) {
      console.error('Error resetting user limits:', error);
      toast({
        title: "Error",
        description: "No se pudieron resetear los límites del usuario",
        variant: "destructive"
      });
      return false;
    }
  };

  return {
    isAdmin,
    loading,
    getUserList,
    updateUserRole,
    resetUserLimits
  };
}
