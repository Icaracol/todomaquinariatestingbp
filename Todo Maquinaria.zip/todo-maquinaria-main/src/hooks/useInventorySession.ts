
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/lib/supabase";
import { MachineFormData } from "@/types/machinery";

export const useInventorySession = (formData: MachineFormData) => {
  const navigate = useNavigate();
  
  useEffect(() => {
    const checkSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        localStorage.setItem('pendingMachinery', JSON.stringify(formData));
        localStorage.setItem('shouldPublishAfterLogin', 'true');
        navigate("/login", { 
          state: { 
            returnTo: "/subir-inventario",
            message: "Por favor inicia sesión para publicar tu maquinaria"
          }
        });
      }
    };
    
    checkSession();
  }, []);

  useEffect(() => {
    const checkLoginReturn = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      const shouldPublish = localStorage.getItem('shouldPublishAfterLogin') === 'true';
      
      if (session && shouldPublish) {
        localStorage.removeItem('shouldPublishAfterLogin');
        return true;
      }
      return false;
    };
    
    checkLoginReturn();
  }, []);
};
