
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/lib/supabase";
import { useAdmin } from "@/hooks/useAdmin";

export type UserLimits = {
  allowed: boolean;
  currentUsage: number;
  limitValue: number;
  resetDate: Date | null;
};

export function useUserLimits() {
  const { toast } = useToast();
  const { isAdmin } = useAdmin();

  const checkLimits = async (action: 'upload_machinery' | 'download_pdf'): Promise<UserLimits> => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      // Verificar si el usuario es administrador
      const adminStatus = await isAdmin();
      if (adminStatus) {
        // Los administradores tienen acceso ilimitado
        return {
          allowed: true,
          currentUsage: 0,
          limitValue: Infinity,
          resetDate: null
        };
      }

      const { data, error } = await supabase.rpc(
        'check_user_limits_extended',
        { 
          p_user_id: user.id,
          p_action: action
        }
      );

      if (error) throw error;

      const limits = data[0];
      return {
        allowed: limits.allowed,
        currentUsage: limits.current_usage,
        limitValue: limits.limit_value,
        resetDate: limits.reset_date ? new Date(limits.reset_date) : null
      };
    } catch (error) {
      console.error('Error checking limits:', error);
      toast({
        title: "Error",
        description: "No se pudieron verificar los límites de usuario",
        variant: "destructive"
      });
      return {
        allowed: false,
        currentUsage: 0,
        limitValue: 0,
        resetDate: null
      };
    }
  };

  const incrementCounter = async (action: 'upload_machinery' | 'download_pdf'): Promise<void> => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      // Los administradores no incrementan sus contadores
      const adminStatus = await isAdmin();
      if (adminStatus) {
        return;
      }

      const { error } = await supabase.rpc(
        'increment_user_counter',
        { 
          p_user_id: user.id,
          p_action: action
        }
      );

      if (error) throw error;
    } catch (error) {
      console.error('Error incrementing counter:', error);
      toast({
        title: "Error",
        description: "No se pudo actualizar el contador de uso",
        variant: "destructive"
      });
    }
  };

  return {
    checkLimits,
    incrementCounter
  };
}
