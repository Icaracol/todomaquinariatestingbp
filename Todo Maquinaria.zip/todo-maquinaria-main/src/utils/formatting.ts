
export const formatPrice = (price: number | null) => {
  if (!price) return 'Precio a consultar';
  return new Intl.NumberFormat('es-AR', {
    style: 'currency',
    currency: 'ARS'
  }).format(price);
};
