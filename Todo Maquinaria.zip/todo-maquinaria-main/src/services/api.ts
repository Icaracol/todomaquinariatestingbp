import { Maquinaria, Lead } from '../types';

// Simulación de API - En una implementación real, estas funciones harían llamadas a un backend
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Maquinaria
export const getMaquinaria = async (): Promise<Maquinaria[]> => {
  await delay(500);
  const maquinaria = localStorage.getItem('maquinaria');
  return maquinaria ? JSON.parse(maquinaria) : [];
};

export const agregarMaquinaria = async (maquinaria: Omit<Maquinaria, 'id'>): Promise<Maquinaria> => {
  await delay(500);
  const nuevaMaquinaria = {
    ...maquinaria,
    id: Date.now().toString(),
    vistas: 0,
  };
  
  const maquinariaActual = await getMaquinaria();
  localStorage.setItem('maquinaria', JSON.stringify([...maquinariaActual, nuevaMaquinaria]));
  
  return nuevaMaquinaria;
};

// Leads
export const getLeads = async (): Promise<Lead[]> => {
  await delay(500);
  const leads = localStorage.getItem('leads');
  return leads ? JSON.parse(leads) : [];
};

export const agregarLead = async (lead: Omit<Lead, 'id' | 'fechaCreacion' | 'ultimoContacto'>): Promise<Lead> => {
  await delay(500);
  const nuevoLead = {
    ...lead,
    id: Date.now().toString(),
    fechaCreacion: new Date().toISOString(),
    ultimoContacto: new Date().toISOString(),
  };
  
  const leadsActuales = await getLeads();
  localStorage.setItem('leads', JSON.stringify([...leadsActuales, nuevoLead]));
  
  return nuevoLead;
};

export const actualizarLead = async (id: string, datos: Partial<Lead>): Promise<Lead> => {
  await delay(500);
  const leads = await getLeads();
  const leadIndex = leads.findIndex(l => l.id === id);
  
  if (leadIndex === -1) {
    throw new Error('Lead no encontrado');
  }
  
  const leadActualizado = {
    ...leads[leadIndex],
    ...datos,
    ultimoContacto: new Date().toISOString(),
  };
  
  leads[leadIndex] = leadActualizado;
  localStorage.setItem('leads', JSON.stringify(leads));
  
  return leadActualizado;
};