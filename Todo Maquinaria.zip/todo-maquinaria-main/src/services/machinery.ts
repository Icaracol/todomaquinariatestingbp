
import { supabase } from "@/lib/supabase";
import { MachineFormData, DbMachinery } from "@/types/machinery";

export const uploadImages = async (files: File[], machineId: string): Promise<string[]> => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error("Usuario no autenticado");

    const uploadPromises = files.map(async (file, index) => {
      const fileExt = file.name.split('.').pop();
      const fileName = `${user.id}/${machineId}/${crypto.randomUUID()}.${fileExt}`;
      
      const { data: uploadResult, error: uploadError } = await supabase.storage
        .from('machinery')
        .upload(fileName, file);

      if (uploadError) {
        console.error("Error uploading image:", uploadError);
        throw new Error(`Error al subir la imagen ${index + 1}: ${uploadError.message}`);
      }

      const { data } = supabase.storage
        .from('machinery')
        .getPublicUrl(fileName);

      const { error: imageError } = await supabase
        .from('machinery_images')
        .insert({
          machinery_id: machineId,
          url: data.publicUrl,
          is_primary: index === 0
        });

      if (imageError) {
        console.error("Error saving image record:", imageError);
        throw new Error(`Error al guardar el registro de la imagen ${index + 1}: ${imageError.message}`);
      }

      return data.publicUrl;
    });

    return Promise.all(uploadPromises);
  } catch (error) {
    console.error("Error in uploadImages:", error);
    throw error;
  }
};

export const createMachinery = async (formData: MachineFormData): Promise<DbMachinery> => {
  const { imagenes, ...data } = formData;
  
  const { data: { session }, error: sessionError } = await supabase.auth.getSession();
  
  if (sessionError || !session?.user?.id) {
    console.error("Error getting user session:", sessionError);
    throw new Error("Usuario no autenticado o sesión expirada");
  }

  console.log("Creating machinery for user:", session.user.id);

  try {
    const { data: machinery, error: machineryError } = await supabase
      .from('machinery')
      .insert({
        name: data.nombre,
        description: data.descripcion,
        price: parseFloat(data.precio),
        year: parseInt(data.año),
        location: data.ubicacion,
        status: data.estado,
        type: data.tipo || 'both',
        category_id: data.categoria || null,
        user_id: session.user.id,
        is_public: true, // Por defecto las máquinas son públicas
        meta_title: data.nombre,
        meta_description: data.descripcion?.substring(0, 160) || `${data.nombre} - Maquinaria Industrial`,
        seo_keywords: [`${data.tipo}`, 'maquinaria', 'industrial']
      })
      .select()
      .single();

    if (machineryError) {
      console.error("Error creating machinery:", machineryError);
      throw new Error(`Error al crear la maquinaria: ${machineryError.message}`);
    }

    if (!machinery) {
      throw new Error("No se pudo crear el registro de la maquinaria");
    }

    if (imagenes && imagenes.length > 0) {
      try {
        await uploadImages(imagenes, machinery.id);
      } catch (error) {
        console.error("Error uploading images:", error);
        // Clean up the machinery record if image upload fails
        await supabase
          .from('machinery')
          .delete()
          .match({ id: machinery.id });
        throw new Error("Error al subir las imágenes");
      }
    }

    return machinery;
  } catch (error) {
    console.error("Error in createMachinery:", error);
    throw error;
  }
};

export const getCategories = async () => {
  const { data, error } = await supabase
    .from('categories')
    .select('*')
    .order('name');

  if (error) {
    console.error("Error fetching categories:", error);
    throw error;
  }
  
  return data;
};

export const toggleMachineryVisibility = async (machineId: string, isPublic: boolean) => {
  const { error } = await supabase
    .from('machinery')
    .update({ is_public: isPublic })
    .match({ id: machineId });

  if (error) {
    console.error("Error toggling machinery visibility:", error);
    throw error;
  }
};

export const initializeCategories = async () => {
  const mainCategories = [
    { name: 'Maquinaria Pesada', icon: 'truck' },
    { name: 'Maquinaria Agrícola', icon: 'tractor' },
    { name: 'Maquinaria de Plástico', icon: 'factory' },
  ];

  const subCategories = {
    'Maquinaria Pesada': [
      'Excavadoras',
      'Grúas',
      'Retroexcavadoras',
      'Compactadoras',
    ],
    'Maquinaria Agrícola': [
      'Tractores',
      'Cosechadoras',
      'Sembradoras',
      'Fumigadoras',
    ],
    'Maquinaria de Plástico': [
      'Inyectoras',
      'Extrusoras',
      'Moldeadoras',
      'Sopladoras',
    ],
  };

  try {
    // Insertar categorías principales
    for (const category of mainCategories) {
      const { data: mainCat, error } = await supabase
        .from('categories')
        .insert({ name: category.name, icon: category.icon })
        .select()
        .single();

      if (error) throw error;

      // Insertar subcategorías
      if (mainCat) {
        const subCatsForMain = subCategories[category.name as keyof typeof subCategories];
        for (const subCatName of subCatsForMain) {
          const { error: subError } = await supabase
            .from('categories')
            .insert({
              name: subCatName,
              parent_id: mainCat.id,
            });

          if (subError) throw subError;
        }
      }
    }
  } catch (error) {
    console.error("Error initializing categories:", error);
    throw error;
  }
};
