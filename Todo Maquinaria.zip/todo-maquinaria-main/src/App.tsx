import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { Session } from "@supabase/supabase-js";
import Index from "@/pages/Index";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import NotFound from "@/pages/NotFound";
import BusinessVerification from "@/pages/BusinessVerification";
import AuthCallback from "@/pages/auth/callback";
import Dashboard from "@/pages/Dashboard";
import AdminPanel from "@/pages/AdminPanel";
import SubirInventario from "@/pages/SubirInventario";
import MachineryDetails from "@/pages/MachineryDetails";
import EditMachinery from "@/pages/EditMachinery";
import Catalogo from "@/pages/Catalogo";
import Pricing from "@/pages/Pricing";
import { Toaster } from "@/components/ui/toaster";
import "@/App.css";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 60 * 1000,
      retry: 1,
    },
  },
});

function App() {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setLoading(false);
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });

    return () => subscription.unsubscribe();
  }, []);

  const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
    if (loading) {
      return <div>Loading...</div>;
    }
    
    if (!session) {
      return <Navigate to="/login" />;
    }

    return children;
  };

  const AuthRoute = ({ children }: { children: React.ReactNode }) => {
    if (loading) {
      return <div>Loading...</div>;
    }

    if (session) {
      return <Navigate to="/dashboard" />;
    }

    return children;
  };

  return (
    <React.StrictMode>
      <QueryClientProvider client={queryClient}>
        <Router>
          <Routes>
            {/* Rutas públicas */}
            <Route path="/" element={<Index />} />
            <Route path="/catalogo" element={<Catalogo />} />
            <Route path="/maquinaria/:id" element={<MachineryDetails />} />
            <Route path="/pricing" element={<Pricing />} />

            {/* Rutas de autenticación */}
            <Route
              path="/login"
              element={
                <AuthRoute>
                  <Login />
                </AuthRoute>
              }
            />
            <Route
              path="/register"
              element={
                <AuthRoute>
                  <Register />
                </AuthRoute>
              }
            />
            <Route path="/auth/callback" element={<AuthCallback />} />

            {/* Rutas protegidas */}
            <Route
              path="/dashboard"
              element={
                <ProtectedRoute>
                  <Dashboard />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin"
              element={
                <ProtectedRoute>
                  <AdminPanel />
                </ProtectedRoute>
              }
            />
            <Route
              path="/dashboard/maquinaria/:id"
              element={
                <ProtectedRoute>
                  <MachineryDetails isSellerView={true} />
                </ProtectedRoute>
              }
            />
            <Route
              path="/dashboard/maquinaria/:id/editar"
              element={
                <ProtectedRoute>
                  <EditMachinery />
                </ProtectedRoute>
              }
            />
            <Route
              path="/subir-inventario"
              element={
                <ProtectedRoute>
                  <SubirInventario />
                </ProtectedRoute>
              }
            />
            <Route
              path="/verificacion"
              element={
                <ProtectedRoute>
                  <BusinessVerification />
                </ProtectedRoute>
              }
            />
            <Route path="*" element={<NotFound />} />
          </Routes>
          <Toaster />
        </Router>
      </QueryClientProvider>
    </React.StrictMode>
  );
}

export default App;
