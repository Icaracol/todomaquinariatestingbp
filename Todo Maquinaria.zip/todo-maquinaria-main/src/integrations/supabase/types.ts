export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      admin_roles: {
        Row: {
          created_at: string
          is_admin: boolean | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          is_admin?: boolean | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          is_admin?: boolean | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      business_profiles: {
        Row: {
          address: Json | null
          business_type: string | null
          company_name: string
          created_at: string
          id: string
          tax_id: string | null
          updated_at: string
          user_id: string
          verification_documents: string[] | null
          verification_notes: string | null
          verification_status: string | null
          website: string | null
        }
        Insert: {
          address?: Json | null
          business_type?: string | null
          company_name: string
          created_at?: string
          id?: string
          tax_id?: string | null
          updated_at?: string
          user_id: string
          verification_documents?: string[] | null
          verification_notes?: string | null
          verification_status?: string | null
          website?: string | null
        }
        Update: {
          address?: Json | null
          business_type?: string | null
          company_name?: string
          created_at?: string
          id?: string
          tax_id?: string | null
          updated_at?: string
          user_id?: string
          verification_documents?: string[] | null
          verification_notes?: string | null
          verification_status?: string | null
          website?: string | null
        }
        Relationships: []
      }
      categories: {
        Row: {
          created_at: string
          description: string | null
          icon: string | null
          id: string
          name: string
          parent_id: string | null
          seo_keywords: string[] | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          icon?: string | null
          id?: string
          name: string
          parent_id?: string | null
          seo_keywords?: string[] | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          icon?: string | null
          id?: string
          name?: string
          parent_id?: string | null
          seo_keywords?: string[] | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "categories_parent_id_fkey"
            columns: ["parent_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      categories_backup: {
        Row: {
          created_at: string | null
          description: string | null
          icon: string | null
          id: string | null
          name: string | null
          parent_id: string | null
          seo_keywords: string[] | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          icon?: string | null
          id?: string | null
          name?: string | null
          parent_id?: string | null
          seo_keywords?: string[] | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          description?: string | null
          icon?: string | null
          id?: string | null
          name?: string | null
          parent_id?: string | null
          seo_keywords?: string[] | null
          updated_at?: string | null
        }
        Relationships: []
      }
      conversations: {
        Row: {
          created_at: string
          id: string
          last_message_at: string
          machinery_id: string | null
          updated_at: string
          user1_id: string | null
          user2_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          last_message_at?: string
          machinery_id?: string | null
          updated_at?: string
          user1_id?: string | null
          user2_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          last_message_at?: string
          machinery_id?: string | null
          updated_at?: string
          user1_id?: string | null
          user2_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "conversations_machinery_id_fkey"
            columns: ["machinery_id"]
            isOneToOne: false
            referencedRelation: "machinery"
            referencedColumns: ["id"]
          },
        ]
      }
      leads: {
        Row: {
          created_at: string
          email: string | null
          id: string
          interest: string | null
          last_contact: string | null
          machinery_id: string
          message: string | null
          name: string
          notes: string[] | null
          phone: string | null
          seller_id: string
          source: string | null
          status: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          email?: string | null
          id?: string
          interest?: string | null
          last_contact?: string | null
          machinery_id: string
          message?: string | null
          name: string
          notes?: string[] | null
          phone?: string | null
          seller_id: string
          source?: string | null
          status?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          email?: string | null
          id?: string
          interest?: string | null
          last_contact?: string | null
          machinery_id?: string
          message?: string | null
          name?: string
          notes?: string[] | null
          phone?: string | null
          seller_id?: string
          source?: string | null
          status?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "leads_machinery_id_fkey"
            columns: ["machinery_id"]
            isOneToOne: false
            referencedRelation: "machinery"
            referencedColumns: ["id"]
          },
        ]
      }
      machinery: {
        Row: {
          category_id: string | null
          created_at: string
          custom_tags: string[] | null
          description: string | null
          id: string
          is_public: boolean | null
          location: string | null
          meta_description: string | null
          meta_title: string | null
          metadata: Json | null
          name: string
          price: number | null
          seo_description: string | null
          seo_keywords: string[] | null
          share_token: string | null
          slug: string | null
          status: string | null
          type: Database["public"]["Enums"]["machinery_type"] | null
          updated_at: string
          user_id: string
          views: number | null
          year: number | null
        }
        Insert: {
          category_id?: string | null
          created_at?: string
          custom_tags?: string[] | null
          description?: string | null
          id?: string
          is_public?: boolean | null
          location?: string | null
          meta_description?: string | null
          meta_title?: string | null
          metadata?: Json | null
          name: string
          price?: number | null
          seo_description?: string | null
          seo_keywords?: string[] | null
          share_token?: string | null
          slug?: string | null
          status?: string | null
          type?: Database["public"]["Enums"]["machinery_type"] | null
          updated_at?: string
          user_id: string
          views?: number | null
          year?: number | null
        }
        Update: {
          category_id?: string | null
          created_at?: string
          custom_tags?: string[] | null
          description?: string | null
          id?: string
          is_public?: boolean | null
          location?: string | null
          meta_description?: string | null
          meta_title?: string | null
          metadata?: Json | null
          name?: string
          price?: number | null
          seo_description?: string | null
          seo_keywords?: string[] | null
          share_token?: string | null
          slug?: string | null
          status?: string | null
          type?: Database["public"]["Enums"]["machinery_type"] | null
          updated_at?: string
          user_id?: string
          views?: number | null
          year?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "machinery_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      machinery_embeddings: {
        Row: {
          created_at: string | null
          embedding: string | null
          id: string
          machinery_id: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          embedding?: string | null
          id?: string
          machinery_id?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          embedding?: string | null
          id?: string
          machinery_id?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "machinery_embeddings_machinery_id_fkey"
            columns: ["machinery_id"]
            isOneToOne: false
            referencedRelation: "machinery"
            referencedColumns: ["id"]
          },
        ]
      }
      machinery_images: {
        Row: {
          created_at: string
          id: string
          is_primary: boolean | null
          machinery_id: string
          metadata: Json | null
          url: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_primary?: boolean | null
          machinery_id: string
          metadata?: Json | null
          url: string
        }
        Update: {
          created_at?: string
          id?: string
          is_primary?: boolean | null
          machinery_id?: string
          metadata?: Json | null
          url?: string
        }
        Relationships: [
          {
            foreignKeyName: "machinery_images_machinery_id_fkey"
            columns: ["machinery_id"]
            isOneToOne: false
            referencedRelation: "machinery"
            referencedColumns: ["id"]
          },
        ]
      }
      machinery_market_prices: {
        Row: {
          created_at: string | null
          currency: string | null
          external_url: string | null
          id: string
          last_checked: string | null
          machinery_id: string | null
          platform: string
          price: number | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          currency?: string | null
          external_url?: string | null
          id?: string
          last_checked?: string | null
          machinery_id?: string | null
          platform: string
          price?: number | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          currency?: string | null
          external_url?: string | null
          id?: string
          last_checked?: string | null
          machinery_id?: string | null
          platform?: string
          price?: number | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "machinery_market_prices_machinery_id_fkey"
            columns: ["machinery_id"]
            isOneToOne: false
            referencedRelation: "machinery"
            referencedColumns: ["id"]
          },
        ]
      }
      machinery_shares: {
        Row: {
          created_at: string | null
          id: string
          machinery_id: string | null
          platform: string
          share_count: number | null
          share_url: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          machinery_id?: string | null
          platform: string
          share_count?: number | null
          share_url?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          machinery_id?: string | null
          platform?: string
          share_count?: number | null
          share_url?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "machinery_shares_machinery_id_fkey"
            columns: ["machinery_id"]
            isOneToOne: false
            referencedRelation: "machinery"
            referencedColumns: ["id"]
          },
        ]
      }
      machinery_specs: {
        Row: {
          created_at: string
          id: string
          machinery_id: string | null
          spec_key: string
          spec_value: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          machinery_id?: string | null
          spec_key: string
          spec_value: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          machinery_id?: string | null
          spec_key?: string
          spec_value?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "machinery_specs_machinery_id_fkey"
            columns: ["machinery_id"]
            isOneToOne: false
            referencedRelation: "machinery"
            referencedColumns: ["id"]
          },
        ]
      }
      messages: {
        Row: {
          content: string
          created_at: string
          id: string
          machinery_id: string | null
          read: boolean | null
          recipient_id: string | null
          sender_id: string | null
          updated_at: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          machinery_id?: string | null
          read?: boolean | null
          recipient_id?: string | null
          sender_id?: string | null
          updated_at?: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          machinery_id?: string | null
          read?: boolean | null
          recipient_id?: string | null
          sender_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "messages_machinery_id_fkey"
            columns: ["machinery_id"]
            isOneToOne: false
            referencedRelation: "machinery"
            referencedColumns: ["id"]
          },
        ]
      }
      page_blocks: {
        Row: {
          content: Json | null
          created_at: string
          id: string
          page_id: string | null
          position: number
          type: Database["public"]["Enums"]["block_type"]
          updated_at: string
        }
        Insert: {
          content?: Json | null
          created_at?: string
          id?: string
          page_id?: string | null
          position: number
          type: Database["public"]["Enums"]["block_type"]
          updated_at?: string
        }
        Update: {
          content?: Json | null
          created_at?: string
          id?: string
          page_id?: string | null
          position?: number
          type?: Database["public"]["Enums"]["block_type"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "page_blocks_page_id_fkey"
            columns: ["page_id"]
            isOneToOne: false
            referencedRelation: "pages"
            referencedColumns: ["id"]
          },
        ]
      }
      pages: {
        Row: {
          created_at: string
          id: string
          meta: Json | null
          slug: string
          title: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          meta?: Json | null
          slug: string
          title: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          meta?: Json | null
          slug?: string
          title?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      pdf_generation_logs: {
        Row: {
          error_message: string | null
          generated_at: string
          id: string
          machinery_count: number
          metadata: Json | null
          success: boolean | null
          template_id: string
          user_id: string | null
        }
        Insert: {
          error_message?: string | null
          generated_at?: string
          id?: string
          machinery_count: number
          metadata?: Json | null
          success?: boolean | null
          template_id: string
          user_id?: string | null
        }
        Update: {
          error_message?: string | null
          generated_at?: string
          id?: string
          machinery_count?: number
          metadata?: Json | null
          success?: boolean | null
          template_id?: string
          user_id?: string | null
        }
        Relationships: []
      }
      pdf_settings: {
        Row: {
          created_at: string
          id: string
          settings: Json
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          settings?: Json
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          settings?: Json
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      pdf_template_categories: {
        Row: {
          created_at: string | null
          description: string | null
          id: string
          name: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          id?: string
          name: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          description?: string | null
          id?: string
          name?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      pdf_templates: {
        Row: {
          category_id: string | null
          created_at: string | null
          css_template: string | null
          default_config: Json | null
          description: string | null
          html_template: string
          id: string
          is_public: boolean | null
          name: string
          thumbnail_url: string | null
          updated_at: string | null
        }
        Insert: {
          category_id?: string | null
          created_at?: string | null
          css_template?: string | null
          default_config?: Json | null
          description?: string | null
          html_template: string
          id?: string
          is_public?: boolean | null
          name: string
          thumbnail_url?: string | null
          updated_at?: string | null
        }
        Update: {
          category_id?: string | null
          created_at?: string | null
          css_template?: string | null
          default_config?: Json | null
          description?: string | null
          html_template?: string
          id?: string
          is_public?: boolean | null
          name?: string
          thumbnail_url?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "pdf_templates_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "pdf_template_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          id: string
          updated_at: string
          whatsapp: string | null
        }
        Insert: {
          id: string
          updated_at?: string
          whatsapp?: string | null
        }
        Update: {
          id?: string
          updated_at?: string
          whatsapp?: string | null
        }
        Relationships: []
      }
      specification_types: {
        Row: {
          category_id: string | null
          created_at: string
          id: string
          name: string
          options: Json | null
          type: string
          unit: string | null
          updated_at: string
        }
        Insert: {
          category_id?: string | null
          created_at?: string
          id?: string
          name: string
          options?: Json | null
          type: string
          unit?: string | null
          updated_at?: string
        }
        Update: {
          category_id?: string | null
          created_at?: string
          id?: string
          name?: string
          options?: Json | null
          type?: string
          unit?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "specification_types_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
        ]
      }
      user_limits: {
        Row: {
          created_at: string
          downloads_count: number | null
          downloads_reset_date: string | null
          machinery_count: number | null
          subscription_tier: Database["public"]["Enums"]["subscription_tier"]
          trial_end_date: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          downloads_count?: number | null
          downloads_reset_date?: string | null
          machinery_count?: number | null
          subscription_tier?: Database["public"]["Enums"]["subscription_tier"]
          trial_end_date?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          downloads_count?: number | null
          downloads_reset_date?: string | null
          machinery_count?: number | null
          subscription_tier?: Database["public"]["Enums"]["subscription_tier"]
          trial_end_date?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_pdf_preferences: {
        Row: {
          accent_color: string | null
          company_logo_url: string | null
          company_name: string | null
          created_at: string
          custom_css: string | null
          font_family: string | null
          footer_text: string | null
          header_style: Json | null
          primary_color: string | null
          secondary_color: string | null
          template_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          accent_color?: string | null
          company_logo_url?: string | null
          company_name?: string | null
          created_at?: string
          custom_css?: string | null
          font_family?: string | null
          footer_text?: string | null
          header_style?: Json | null
          primary_color?: string | null
          secondary_color?: string | null
          template_id?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          accent_color?: string | null
          company_logo_url?: string | null
          company_name?: string | null
          created_at?: string
          custom_css?: string | null
          font_family?: string | null
          footer_text?: string | null
          header_style?: Json | null
          primary_color?: string | null
          secondary_color?: string | null
          template_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_template_presets: {
        Row: {
          created_at: string
          id: string
          is_default: boolean | null
          name: string
          settings: Json
          template_id: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          is_default?: boolean | null
          name: string
          settings: Json
          template_id: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          is_default?: boolean | null
          name?: string
          settings?: Json
          template_id?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      admin_user_stats: {
        Row: {
          created_at: string | null
          downloads_count: number | null
          downloads_reset_date: string | null
          email: string | null
          id: string | null
          machinery_count: number | null
          subscription_tier:
            | Database["public"]["Enums"]["subscription_tier"]
            | null
          updated_at: string | null
        }
        Relationships: []
      }
    }
    Functions: {
      binary_quantize:
        | {
            Args: {
              "": string
            }
            Returns: unknown
          }
        | {
            Args: {
              "": unknown
            }
            Returns: unknown
          }
      check_user_limits: {
        Args: {
          p_user_id: string
          p_action: string
        }
        Returns: boolean
      }
      check_user_limits_extended: {
        Args: {
          p_user_id: string
          p_action: string
          p_metadata?: Json
        }
        Returns: {
          allowed: boolean
          current_usage: number
          limit_value: number
          reset_date: string
        }[]
      }
      get_admin_user_stats: {
        Args: Record<PropertyKey, never>
        Returns: {
          id: string
          email: string
          subscription_tier: Database["public"]["Enums"]["subscription_tier"]
          machinery_count: number
          downloads_count: number
          downloads_reset_date: string
          created_at: string
          updated_at: string
        }[]
      }
      halfvec_avg: {
        Args: {
          "": number[]
        }
        Returns: unknown
      }
      halfvec_out: {
        Args: {
          "": unknown
        }
        Returns: unknown
      }
      halfvec_send: {
        Args: {
          "": unknown
        }
        Returns: string
      }
      halfvec_typmod_in: {
        Args: {
          "": unknown[]
        }
        Returns: number
      }
      hnsw_bit_support: {
        Args: {
          "": unknown
        }
        Returns: unknown
      }
      hnsw_halfvec_support: {
        Args: {
          "": unknown
        }
        Returns: unknown
      }
      hnsw_sparsevec_support: {
        Args: {
          "": unknown
        }
        Returns: unknown
      }
      hnswhandler: {
        Args: {
          "": unknown
        }
        Returns: unknown
      }
      increment_user_counter: {
        Args: {
          p_user_id: string
          p_action: string
        }
        Returns: undefined
      }
      is_admin: {
        Args: {
          user_id: string
        }
        Returns: boolean
      }
      ivfflat_bit_support: {
        Args: {
          "": unknown
        }
        Returns: unknown
      }
      ivfflat_halfvec_support: {
        Args: {
          "": unknown
        }
        Returns: unknown
      }
      ivfflathandler: {
        Args: {
          "": unknown
        }
        Returns: unknown
      }
      l2_norm:
        | {
            Args: {
              "": unknown
            }
            Returns: number
          }
        | {
            Args: {
              "": unknown
            }
            Returns: number
          }
      l2_normalize:
        | {
            Args: {
              "": string
            }
            Returns: string
          }
        | {
            Args: {
              "": unknown
            }
            Returns: unknown
          }
        | {
            Args: {
              "": unknown
            }
            Returns: unknown
          }
      sparsevec_out: {
        Args: {
          "": unknown
        }
        Returns: unknown
      }
      sparsevec_send: {
        Args: {
          "": unknown
        }
        Returns: string
      }
      sparsevec_typmod_in: {
        Args: {
          "": unknown[]
        }
        Returns: number
      }
      vector_avg: {
        Args: {
          "": number[]
        }
        Returns: string
      }
      vector_dims:
        | {
            Args: {
              "": string
            }
            Returns: number
          }
        | {
            Args: {
              "": unknown
            }
            Returns: number
          }
      vector_norm: {
        Args: {
          "": string
        }
        Returns: number
      }
      vector_out: {
        Args: {
          "": string
        }
        Returns: unknown
      }
      vector_send: {
        Args: {
          "": string
        }
        Returns: string
      }
      vector_typmod_in: {
        Args: {
          "": unknown[]
        }
        Returns: number
      }
    }
    Enums: {
      block_type: "hero" | "features" | "pricing" | "cta" | "text" | "image"
      machinery_type: "b2b" | "b2c" | "both"
      subscription_tier: "free" | "premium" | "super_premium"
      verification_status: "pending" | "approved" | "rejected"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type PublicSchema = Database[Extract<keyof Database, "public">]

export type Tables<
  PublicTableNameOrOptions extends
    | keyof (PublicSchema["Tables"] & PublicSchema["Views"])
    | { schema: keyof Database },
  TableName extends PublicTableNameOrOptions extends { schema: keyof Database }
    ? keyof (Database[PublicTableNameOrOptions["schema"]]["Tables"] &
        Database[PublicTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = PublicTableNameOrOptions extends { schema: keyof Database }
  ? (Database[PublicTableNameOrOptions["schema"]]["Tables"] &
      Database[PublicTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : PublicTableNameOrOptions extends keyof (PublicSchema["Tables"] &
        PublicSchema["Views"])
    ? (PublicSchema["Tables"] &
        PublicSchema["Views"])[PublicTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  PublicTableNameOrOptions extends
    | keyof PublicSchema["Tables"]
    | { schema: keyof Database },
  TableName extends PublicTableNameOrOptions extends { schema: keyof Database }
    ? keyof Database[PublicTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = PublicTableNameOrOptions extends { schema: keyof Database }
  ? Database[PublicTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : PublicTableNameOrOptions extends keyof PublicSchema["Tables"]
    ? PublicSchema["Tables"][PublicTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  PublicTableNameOrOptions extends
    | keyof PublicSchema["Tables"]
    | { schema: keyof Database },
  TableName extends PublicTableNameOrOptions extends { schema: keyof Database }
    ? keyof Database[PublicTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = PublicTableNameOrOptions extends { schema: keyof Database }
  ? Database[PublicTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : PublicTableNameOrOptions extends keyof PublicSchema["Tables"]
    ? PublicSchema["Tables"][PublicTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  PublicEnumNameOrOptions extends
    | keyof PublicSchema["Enums"]
    | { schema: keyof Database },
  EnumName extends PublicEnumNameOrOptions extends { schema: keyof Database }
    ? keyof Database[PublicEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = PublicEnumNameOrOptions extends { schema: keyof Database }
  ? Database[PublicEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : PublicEnumNameOrOptions extends keyof PublicSchema["Enums"]
    ? PublicSchema["Enums"][PublicEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof PublicSchema["CompositeTypes"]
    | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof PublicSchema["CompositeTypes"]
    ? PublicSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never
