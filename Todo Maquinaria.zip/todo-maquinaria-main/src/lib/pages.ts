
import { supabase } from '@/lib/supabase';
import type { Block } from '@/types/editor';

export interface Page {
  id: string;
  title: string;
  slug: string;
  meta: {
    description?: string;
    keywords?: string[];
  };
  blocks?: Block[];
}

export async function createPage(page: Omit<Page, 'id'>) {
  const { data, error } = await supabase
    .from('pages')
    .insert([{
      title: page.title,
      slug: page.slug,
      meta: page.meta
    }])
    .select()
    .single();

  if (error) throw error;

  if (page.blocks) {
    const { error: blocksError } = await supabase
      .from('page_blocks')
      .insert(
        page.blocks.map((block, index) => ({
          page_id: data.id,
          type: block.type,
          content: block.content,
          position: index
        }))
      );

    if (blocksError) throw blocksError;
  }

  return data;
}

export async function updatePage(id: string, updates: Partial<Page>) {
  const { error } = await supabase
    .from('pages')
    .update({
      title: updates.title,
      slug: updates.slug,
      meta: updates.meta
    })
    .eq('id', id);

  if (error) throw error;

  if (updates.blocks) {
    // Primero eliminamos los bloques existentes
    const { error: deleteError } = await supabase
      .from('page_blocks')
      .delete()
      .eq('page_id', id);

    if (deleteError) throw deleteError;

    // Luego insertamos los nuevos bloques
    const { error: blocksError } = await supabase
      .from('page_blocks')
      .insert(
        updates.blocks.map((block, index) => ({
          page_id: id,
          type: block.type,
          content: block.content,
          position: index
        }))
      );

    if (blocksError) throw blocksError;
  }
}

export async function deletePage(id: string) {
  const { error } = await supabase
    .from('pages')
    .delete()
    .eq('id', id);

  if (error) throw error;
}

export async function getPage(id: string): Promise<Page> {
  const { data: page, error } = await supabase
    .from('pages')
    .select('*')
    .eq('id', id)
    .single();

  if (error) throw error;

  const { data: blocks, error: blocksError } = await supabase
    .from('page_blocks')
    .select('*')
    .eq('page_id', id)
    .order('position');

  if (blocksError) throw blocksError;

  return {
    ...page,
    blocks: blocks?.map(block => ({
      id: block.id,
      type: block.type,
      content: block.content
    }))
  };
}

export async function getPages(): Promise<Page[]> {
  const { data, error } = await supabase
    .from('pages')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data;
}
