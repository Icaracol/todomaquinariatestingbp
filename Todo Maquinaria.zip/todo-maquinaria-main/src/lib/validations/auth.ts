
import * as z from "zod";

export const basicRegisterSchema = z.object({
  email: z.string().email("Correo electrónico inválido"),
  password: z.string().min(6, "La contraseña debe tener al menos 6 caracteres"),
});

export const businessRegisterSchema = z.object({
  companyName: z.string().min(2, "El nombre de la empresa es requerido"),
  taxId: z.string().min(12, "El RFC debe tener al menos 12 caracteres").max(13, "El RFC no puede tener más de 13 caracteres"),
  website: z.string().url("URL inválida").optional().or(z.literal("")),
});

export const loginSchema = z.object({
  email: z.string().email("Correo electrónico inválido"),
  password: z.string().min(1, "La contraseña es requerida"),
});

export type BasicRegisterForm = z.infer<typeof basicRegisterSchema>;
export type BusinessRegisterForm = z.infer<typeof businessRegisterSchema>;
export type LoginForm = z.infer<typeof loginSchema>;
