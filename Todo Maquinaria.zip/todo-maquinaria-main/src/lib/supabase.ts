
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://qlghltizhldsbuubqucs.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFsZ2hsdGl6aGxkc2J1dWJxdWNzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Mzk4MTUxMTksImV4cCI6MjA1NTM5MTExOX0.A0wRFgKRlteLcuJB4zNg21onUaCqaBUokE1vHMdpAGE';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
