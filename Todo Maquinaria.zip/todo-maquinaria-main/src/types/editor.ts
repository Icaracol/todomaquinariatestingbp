
export type BlockType = 'hero' | 'features' | 'pricing' | 'cta' | 'text' | 'image';

export interface Block {
  id: string;
  type: BlockType;
  content: any;
}

export interface PageData {
  id: string;
  title: string;
  slug: string;
  blocks: Block[];
  meta: {
    description?: string;
    keywords?: string[];
  };
}
