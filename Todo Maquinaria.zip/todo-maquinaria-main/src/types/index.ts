export interface Maquinaria {
  id: string;
  nombre: string;
  categoria: string;
  precio: number;
  año: number;
  ubicacion: string;
  imagen: string;
  estado: 'disponible' | 'vendido' | 'reservado';
  vistas: number;
}

export interface Lead {
  id: string;
  nombre: string;
  email: string;
  telefono: string;
  interes: string;
  estado: 'nuevo' | 'contactado' | 'seguimiento' | 'convertido';
  fechaCreacion: string;
  ultimoContacto: string;
}

export interface Usuario {
  id: string;
  nombre: string;
  email: string;
  empresa: string;
  rol: 'admin' | 'vendedor';
}