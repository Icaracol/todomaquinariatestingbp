
export interface Message {
  id: string;
  machinery_id: string | null;
  sender_id: string;
  recipient_id: string;
  content: string;
  read: boolean;
  created_at: string;
  updated_at: string;
}

export interface Conversation {
  id: string;
  machinery_id: string | null;
  user1_id: string;
  user2_id: string;
  last_message_at: string;
  created_at: string;
  updated_at: string;
  lastMessage?: Message;
  otherUser?: {
    id: string;
    email?: string;
  };
  machinery?: {
    id: string;
    name: string;
  };
}
