
export interface PDFPreferences {
  templateId: string;
  companyName: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  logoUrl?: string;
  fontFamily?: string;
  headerStyle?: {
    alignment: 'left' | 'center' | 'right';
    spacing: 'compact' | 'normal' | 'wide';
  };
  footerText?: string;
  customCss?: string;
}

export interface PDFTemplate {
  id: string;
  name: string;
  preview: string;
}

export interface PDFGenerationOptions {
  preferences: PDFPreferences;
  machines: any[];
  template: PDFTemplate;
}
