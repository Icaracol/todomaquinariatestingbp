
export type UserRole = 'basic' | 'professional' | 'enterprise' | 'partner';

export interface UserAdminData {
  id: string;
  email: string;
  role: UserRole;
  machineryCount: number;
  downloadsCount: number;
  downloadsResetDate: string | null;
  createdAt: string;
  updatedAt: string;
}
