
export type MachineryStatus = 'available' | 'sold' | 'reserved';
export type MachineryType = 'b2b' | 'b2c' | 'both';

export interface MachineFormData {
  nombre: string;
  descripcion: string;
  precio: string;
  año: string;
  ubicacion: string;
  categoria: string;
  estado: MachineryStatus;
  tipo: MachineryType;
  imagenes: File[];
  // Campos nuevos
  name: string;
  description: string;
  category_id: string;
  year: string;
  price: string;
  location: string;
  is_public?: boolean;
  specifications: Record<string, string>;
  share_token?: string;
}

export interface MachineryImage {
  id: string;
  machinery_id: string;
  url: string;
  is_primary: boolean;
  created_at: string;
}

export interface DbMachinery {
  id: string;
  user_id: string;
  name: string;
  description: string;
  price: number;
  year: number;
  location: string;
  status: MachineryStatus;
  type: MachineryType;
  category_id: string | null;
  views: number;
  created_at: string;
  updated_at: string;
  metadata: Record<string, any>;
  is_public: boolean;
  seo_description: string | null;
  seo_keywords: string[] | null;
  custom_tags: string[] | null;
  share_token?: string;
  share_url?: string;
  images?: MachineryImage[];
}

export interface MachinerySpec {
  id: string;
  machinery_id: string;
  spec_key: string;
  spec_value: string;
  created_at: string;
}

export interface DetailedMachinery extends DbMachinery {
  images: MachineryImage[];
  specs: MachinerySpec[];
  category?: {
    id: string;
    name: string;
  };
}

export interface MachineryMetrics {
  daily_views: number;
  total_views: number;
  contact_rate: number;
  last_7_days_views: number[];
  popular_hours: { hour: number; views: number }[];
}

export interface MachinerySearchParams {
  query?: string;
  category?: string;
  minPrice?: number;
  maxPrice?: number;
  year?: number;
  location?: string;
  limit?: number;
}

export interface MachineryMarketPrice {
  id: string;
  machinery_id: string;
  platform: string;
  external_url: string | null;
  price: number;
  currency: string;
  last_checked: string;
}

export interface MachineryShare {
  id: string;
  machinery_id: string;
  platform: string;
  share_url: string | null;
  share_count: number;
}

export interface MachineryWithMetadata extends DbMachinery {
  market_prices?: MachineryMarketPrice[];
  shares?: MachineryShare[];
  similar_machines?: DbMachinery[];
}
