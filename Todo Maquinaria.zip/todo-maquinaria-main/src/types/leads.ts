
export type LeadStatus = "nuevo" | "seguimiento" | "convertido" | "cerrado";

export interface Lead {
  id: string;
  seller_id: string;
  name: string;
  email?: string;
  phone?: string;
  whatsapp?: string;
  interest: string;
  status: LeadStatus;
  notes?: string[];
  created_at: string;
  machinery_id: string;
}
