
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/lib/supabase";

interface PDFCustomizerProps {
  onClose: () => void;
  selectedMachines: any[];
  onGeneratePDF: () => void;
}

export function PDFCustomizer({ onClose, selectedMachines, onGeneratePDF }: PDFCustomizerProps) {
  const { toast } = useToast();
  const [loading, setLoading] = React.useState(false);
  const [preferences, setPreferences] = React.useState({
    templateId: 'modern',
    companyName: '',
    primaryColor: '#333333',
    secondaryColor: '#666666',
    accentColor: '#e74c3c'
  });

  React.useEffect(() => {
    loadUserPreferences();
  }, []);

  const loadUserPreferences = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('user_pdf_preferences')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (error) {
        if (error.code !== 'PGRST116') { // No data found
          throw error;
        }
        return;
      }

      if (data) {
        setPreferences({
          templateId: data.template_id,
          companyName: data.company_name || '',
          primaryColor: data.primary_color,
          secondaryColor: data.secondary_color,
          accentColor: data.accent_color
        });
      }
    } catch (error) {
      console.error('Error loading preferences:', error);
      toast({
        title: "Error",
        description: "No se pudieron cargar las preferencias",
        variant: "destructive"
      });
    }
  };

  const savePreferences = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No user found');

      const { error } = await supabase
        .from('user_pdf_preferences')
        .upsert({
          user_id: user.id,
          template_id: preferences.templateId,
          company_name: preferences.companyName,
          primary_color: preferences.primaryColor,
          secondary_color: preferences.secondaryColor,
          accent_color: preferences.accentColor
        });

      if (error) throw error;

      toast({
        title: "Preferencias guardadas",
        description: "Tus preferencias han sido guardadas correctamente"
      });
    } catch (error) {
      console.error('Error saving preferences:', error);
      toast({
        title: "Error",
        description: "No se pudieron guardar las preferencias",
        variant: "destructive"
      });
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Personalizar Catálogo PDF</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div className="space-y-2">
            <Label>Diseño de Plantilla</Label>
            <Select 
              value={preferences.templateId}
              onValueChange={(value) => setPreferences(prev => ({ ...prev, templateId: value }))}
            >
              <SelectTrigger>
                <SelectValue placeholder="Selecciona un diseño" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  <SelectItem value="classic">Clásico</SelectItem>
                  <SelectItem value="minimalist">Minimalista</SelectItem>
                  <SelectItem value="modern">Moderno</SelectItem>
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Nombre de la Empresa</Label>
            <Input
              value={preferences.companyName}
              onChange={(e) => setPreferences(prev => ({ ...prev, companyName: e.target.value }))}
              placeholder="Nombre de tu empresa"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>Color Principal</Label>
              <Input
                type="color"
                value={preferences.primaryColor}
                onChange={(e) => setPreferences(prev => ({ ...prev, primaryColor: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label>Color Secundario</Label>
              <Input
                type="color"
                value={preferences.secondaryColor}
                onChange={(e) => setPreferences(prev => ({ ...prev, secondaryColor: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label>Color de Acento</Label>
              <Input
                type="color"
                value={preferences.accentColor}
                onChange={(e) => setPreferences(prev => ({ ...prev, accentColor: e.target.value }))}
              />
            </div>
          </div>

          <div className="flex justify-end space-x-4 pt-4">
            <Button variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button variant="secondary" onClick={savePreferences}>
              Guardar Preferencias
            </Button>
            <Button 
              onClick={onGeneratePDF}
              disabled={loading || selectedMachines.length === 0}
            >
              {loading ? "Generando..." : "Generar PDF"}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
