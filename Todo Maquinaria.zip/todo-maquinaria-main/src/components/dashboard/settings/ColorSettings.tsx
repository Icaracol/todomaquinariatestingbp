
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";

interface ColorSettingsProps {
  colors: {
    primary: string;
    secondary: string;
    accent: string;
  };
  onColorChange: (key: 'primary' | 'secondary' | 'accent', value: string) => void;
}

export function ColorSettings({ colors, onColorChange }: ColorSettingsProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div className="space-y-2">
        <Label>Color primario</Label>
        <Input
          type="color"
          value={colors.primary}
          onChange={e => onColorChange('primary', e.target.value)}
        />
      </div>
      <div className="space-y-2">
        <Label>Color secundario</Label>
        <Input
          type="color"
          value={colors.secondary}
          onChange={e => onColorChange('secondary', e.target.value)}
        />
      </div>
      <div className="space-y-2">
        <Label>Color de acento</Label>
        <Input
          type="color"
          value={colors.accent}
          onChange={e => onColorChange('accent', e.target.value)}
        />
      </div>
    </div>
  );
}
