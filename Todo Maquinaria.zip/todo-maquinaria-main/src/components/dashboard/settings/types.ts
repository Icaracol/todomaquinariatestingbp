
export interface PDFSettings {
  templateId: string;
  companyLogo?: string;
  companyName?: string;
  colors: {
    primary: string;
    secondary: string;
    accent: string;
  };
  layout?: {
    spacing: 'compact' | 'normal' | 'wide';
    headerAlignment: 'left' | 'center' | 'right';
  };
  fonts?: {
    titleFont: string;
    bodyFont: string;
  };
  footer?: {
    text?: string;
    showLogo?: boolean;
  };
}

export interface PDFTemplate {
  id: string;
  name: string;
  description: string;
  preview: string;
}
