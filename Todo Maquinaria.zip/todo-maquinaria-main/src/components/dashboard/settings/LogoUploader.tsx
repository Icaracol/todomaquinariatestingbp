
import { useState } from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/lib/supabase";
import { ImagePlus } from "lucide-react";

interface LogoUploaderProps {
  logo?: string;
  onLogoChange: (url: string) => void;
}

export function LogoUploader({ logo, onLogoChange }: LogoUploaderProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setLoading(true);
      const { data, error } = await supabase.storage
        .from('logos')
        .upload(`company-logos/${Date.now()}-${file.name}`, file);

      if (error) throw error;

      const { data: { publicUrl } } = supabase.storage
        .from('logos')
        .getPublicUrl(data.path);

      onLogoChange(publicUrl);

      toast({
        title: "Logo actualizado",
        description: "El logo se ha actualizado correctamente"
      });
    } catch (error) {
      console.error('Error uploading logo:', error);
      toast({
        title: "Error",
        description: "No se pudo cargar el logo",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <Label>Logo de la empresa</Label>
      {logo ? (
        <div className="relative w-48 h-24 border rounded-lg overflow-hidden">
          <img 
            src={logo} 
            alt="Logo de la empresa" 
            className="w-full h-full object-contain"
          />
          <div className="absolute inset-0 bg-black/50 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center">
            <Button 
              variant="secondary" 
              size="sm"
              onClick={() => document.getElementById('logo-upload')?.click()}
            >
              Cambiar logo
            </Button>
          </div>
        </div>
      ) : (
        <div 
          className="w-48 h-24 border-2 border-dashed rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-primary transition-colors"
          onClick={() => document.getElementById('logo-upload')?.click()}
        >
          <ImagePlus className="h-8 w-8 text-muted-foreground mb-2" />
          <span className="text-sm text-muted-foreground">
            {loading ? "Subiendo..." : "Subir logo"}
          </span>
        </div>
      )}
      <Input
        id="logo-upload"
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleLogoUpload}
        disabled={loading}
      />
    </div>
  );
}
