
import { Card } from "@/components/ui/card";

interface TemplateSelectorProps {
  value: string;
  onChange: (value: string) => void;
}

export function TemplateSelector({ value, onChange }: TemplateSelectorProps) {
  const templates = [
    {
      id: "modern",
      name: "Moderno",
      preview: "/templates/modern-preview.jpg",
      description: "Diseño moderno con barra lateral de color"
    },
    {
      id: "classic",
      name: "Clásico",
      preview: "/templates/classic-preview.jpg",
      description: "Diseño tradicional con encabezado de color"
    },
    {
      id: "minimal",
      name: "Minimalista",
      preview: "/templates/minimal-preview.jpg",
      description: "Diseño limpio con acentos sutiles"
    }
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
      {templates.map((template) => (
        <Card
          key={template.id}
          className={`p-4 cursor-pointer transition-all hover:shadow-md ${
            value === template.id ? 'ring-2 ring-primary' : ''
          }`}
          onClick={() => onChange(template.id)}
        >
          <div className="aspect-[4/3] bg-muted mb-3 rounded overflow-hidden">
            <img
              src={template.preview}
              alt={`Preview de ${template.name}`}
              className="w-full h-full object-cover"
            />
          </div>
          <div className="space-y-1">
            <h4 className="font-semibold">{template.name}</h4>
            <p className="text-sm text-muted-foreground">
              {template.description}
            </p>
          </div>
        </Card>
      ))}
    </div>
  );
}
