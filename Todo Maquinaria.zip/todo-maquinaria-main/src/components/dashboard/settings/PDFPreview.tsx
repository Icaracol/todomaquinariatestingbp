
import { Card } from "@/components/ui/card";
import type { PDFSettings } from "./types";
import type { DbMachinery } from "@/types/machinery";
import { cn } from "@/lib/utils";
import { ImageIcon } from "lucide-react";

interface PDFPreviewProps {
  settings: PDFSettings;
  selectedMachines?: DbMachinery[];
  previewMachine?: Partial<DbMachinery>;
}

export function PDFPreview({ settings, selectedMachines = [], previewMachine }: PDFPreviewProps) {
  const machineToPreview = selectedMachines?.[0] || previewMachine;
  
  const getTemplateStyle = () => {
    switch (settings.templateId) {
      case 'modern':
        return {
          header: `border-l-[8px] border-[${settings.colors.primary}]`,
          accent: `bg-[${settings.colors.accent}]`,
          container: 'pl-8'
        };
      case 'classic':
        return {
          header: `border-t-[8px] border-[${settings.colors.primary}]`,
          accent: `text-[${settings.colors.accent}]`,
          container: ''
        };
      case 'minimal':
        return {
          header: 'border-none',
          accent: `border-b-2 border-[${settings.colors.accent}]`,
          container: ''
        };
      default:
        return {
          header: '',
          accent: '',
          container: ''
        };
    }
  };

  const style = getTemplateStyle();
  const headerAlignment = settings.layout?.headerAlignment || 'left';
  const spacing = settings.layout?.spacing || 'normal';

  const spacingClasses = {
    compact: 'space-y-4',
    normal: 'space-y-6',
    wide: 'space-y-8'
  };

  if (!machineToPreview) {
    return (
      <div className="text-center p-8 bg-gray-50 rounded-lg">
        <p className="text-gray-500">
          Selecciona maquinaria de tu inventario para previsualizar el PDF
        </p>
      </div>
    );
  }

  return (
    <Card 
      className={cn(
        "w-full max-w-[600px] mx-auto bg-white shadow-sm transition-all duration-300",
        style.header
      )}
    >
      <div className={cn("p-6", spacingClasses[spacing], style.container)}>
        {/* Header con logo y nombre de la empresa */}
        <div className={cn(
          "flex items-start gap-4",
          {
            'justify-start': headerAlignment === 'left',
            'justify-center': headerAlignment === 'center',
            'justify-end': headerAlignment === 'right'
          }
        )}>
          {settings.companyLogo && (
            <img 
              src={settings.companyLogo} 
              alt="Logo" 
              className="h-12 object-contain"
            />
          )}
          {settings.companyName && (
            <h1 className="text-lg font-semibold text-gray-900">
              {settings.companyName}
            </h1>
          )}
        </div>

        {/* Contenido de la maquinaria */}
        <div className="space-y-4">
          <h2 className={cn("text-2xl font-bold", style.accent)}>
            {machineToPreview.name || "Nombre de la máquina"}
          </h2>
          
          {machineToPreview.images?.[0]?.url ? (
            <img
              src={machineToPreview.images[0].url}
              alt={machineToPreview.name}
              className="w-full aspect-video object-cover rounded-lg"
            />
          ) : (
            <div className="w-full aspect-video bg-gray-100 rounded-lg flex items-center justify-center">
              <ImageIcon className="h-12 w-12 text-gray-400" />
            </div>
          )}
          
          <p className="text-gray-600">
            {machineToPreview.description || "Descripción de la máquina..."}
          </p>
          
          <div className="grid grid-cols-2 gap-4 pt-4">
            <div>
              <p className="text-sm text-gray-500">Año</p>
              <p className="font-medium">{machineToPreview.year || "2024"}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Precio</p>
              <p className="font-medium">
                ${(machineToPreview.price || 0).toLocaleString()}
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        {settings.footer?.text && (
          <div className="pt-6 mt-6 border-t border-gray-200">
            <p className="text-sm text-gray-500 text-center">
              {settings.footer.text}
            </p>
            {settings.footer.showLogo && settings.companyLogo && (
              <img 
                src={settings.companyLogo} 
                alt="Logo" 
                className="h-8 object-contain mx-auto mt-2"
              />
            )}
          </div>
        )}
      </div>
    </Card>
  );
}
