
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Input } from "@/components/ui/input";
import { LogoUploader } from "../LogoUploader";
import type { PDFSettings } from "../types";

interface HeaderSettingsProps {
  settings: PDFSettings;
  onSettingsChange: (newSettings: PDFSettings) => void;
}

export function HeaderSettings({ settings, onSettingsChange }: HeaderSettingsProps) {
  const handleAlignmentChange = (value: string) => {
    onSettingsChange({
      ...settings,
      layout: {
        ...settings.layout,
        headerAlignment: value as 'left' | 'center' | 'right'
      }
    });
  };

  const handleCompanyNameChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onSettingsChange({
      ...settings,
      companyName: event.target.value
    });
  };

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label>Alineación del encabezado</Label>
        <RadioGroup
          value={settings.layout?.headerAlignment || 'left'}
          onValueChange={handleAlignmentChange}
          className="flex gap-4"
        >
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="left" id="left" />
            <Label htmlFor="left">Izquierda</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="center" id="center" />
            <Label htmlFor="center">Centro</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="right" id="right" />
            <Label htmlFor="right">Derecha</Label>
          </div>
        </RadioGroup>
      </div>

      <div className="space-y-2">
        <Label>Nombre de la empresa</Label>
        <Input
          value={settings.companyName || ''}
          onChange={handleCompanyNameChange}
          placeholder="Nombre de tu empresa"
        />
      </div>

      <div className="space-y-2">
        <Label>Logo de la empresa</Label>
        <LogoUploader
          logo={settings.companyLogo}
          onLogoChange={(url) => onSettingsChange({
            ...settings,
            companyLogo: url
          })}
        />
      </div>
    </div>
  );
}
