
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import type { PDFSettings } from "../types";

interface FooterSettingsProps {
  settings: PDFSettings;
  onSettingsChange: (newSettings: PDFSettings) => void;
}

export function FooterSettings({ settings, onSettingsChange }: FooterSettingsProps) {
  const handleFooterTextChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    onSettingsChange({
      ...settings,
      footer: {
        ...settings.footer,
        text: event.target.value
      }
    });
  };

  const handleShowLogoChange = (checked: boolean) => {
    onSettingsChange({
      ...settings,
      footer: {
        ...settings.footer,
        showLogo: checked
      }
    });
  };

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label>Texto del pie de página</Label>
        <Input
          value={settings.footer?.text || ''}
          onChange={handleFooterTextChange}
          placeholder="Ej: Contacta con nosotros para más información"
        />
      </div>

      <div className="flex items-center justify-between">
        <Label>Mostrar logo en el pie de página</Label>
        <Switch
          checked={settings.footer?.showLogo || false}
          onCheckedChange={handleShowLogoChange}
        />
      </div>
    </div>
  );
}
