
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { PDFPreview } from "../PDFPreview";
import type { PDFSettings } from "../types";
import type { DbMachinery } from "@/types/machinery";

interface PDFPreviewSectionProps {
  settings: PDFSettings;
  previewMachine: Partial<DbMachinery>;
}

export function PDFPreviewSection({ settings, previewMachine }: PDFPreviewSectionProps) {
  return (
    <Card className="bg-white/50 backdrop-blur sticky top-6">
      <CardHeader>
        <CardTitle>Vista previa en tiempo real</CardTitle>
        <CardDescription>
          Así se verán tus PDFs generados
        </CardDescription>
      </CardHeader>
      <CardContent className="relative">
        <div className="transition-all duration-300 ease-in-out">
          <PDFPreview 
            settings={settings}
            previewMachine={previewMachine}
          />
        </div>
        <div className="absolute inset-0 pointer-events-none bg-gradient-to-b from-transparent to-white/10"></div>
      </CardContent>
    </Card>
  );
}
