
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Save, Loader2 } from "lucide-react";
import { TemplateSelector } from "../TemplateSelector";
import { HeaderSettings } from "./HeaderSettings";
import { FooterSettings } from "./FooterSettings";
import { ColorSettings } from "../ColorSettings";
import type { PDFSettings } from "../types";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface PDFSettingsFormProps {
  settings: PDFSettings;
  isActive: boolean;
  isSaving: boolean;
  onSettingsChange: (settings: PDFSettings) => void;
  onActiveChange: (active: boolean) => void;
  onSave: () => void;
}

export function PDFSettingsForm({
  settings,
  isActive,
  isSaving,
  onSettingsChange,
  onActiveChange,
  onSave
}: PDFSettingsFormProps) {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Plantillas de PDF</CardTitle>
          <CardDescription>
            Selecciona una plantilla para tu catálogo
          </CardDescription>
        </CardHeader>
        <CardContent className="grid gap-6">
          <TemplateSelector
            value={settings.templateId}
            onChange={(value) => onSettingsChange({ ...settings, templateId: value })}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Personalización</CardTitle>
          <CardDescription>
            Configura el aspecto de tus PDFs
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="header" className="space-y-4">
            <TabsList>
              <TabsTrigger value="header">Encabezado</TabsTrigger>
              <TabsTrigger value="colors">Colores</TabsTrigger>
              <TabsTrigger value="footer">Pie de página</TabsTrigger>
            </TabsList>
            <TabsContent value="header">
              <HeaderSettings 
                settings={settings} 
                onSettingsChange={onSettingsChange}
              />
            </TabsContent>
            <TabsContent value="colors">
              <ColorSettings 
                colors={settings.colors}
                onColorChange={(key, value) => onSettingsChange({
                  ...settings,
                  colors: { ...settings.colors, [key]: value }
                })}
              />
            </TabsContent>
            <TabsContent value="footer">
              <FooterSettings 
                settings={settings} 
                onSettingsChange={onSettingsChange}
              />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="flex flex-col gap-4 pt-6">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <h4 className="font-medium">Mantener activa esta configuración</h4>
              <p className="text-sm text-muted-foreground">
                Esta configuración se aplicará a todos los PDFs generados
              </p>
            </div>
            <Switch
              checked={isActive}
              onCheckedChange={onActiveChange}
              className="data-[state=checked]:bg-green-500"
            />
          </div>

          <Button 
            onClick={onSave} 
            disabled={isSaving}
            className="w-full"
          >
            {isSaving ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Guardando...
              </>
            ) : (
              <>
                <Save className="mr-2 h-4 w-4" />
                Guardar configuración
              </>
            )}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
