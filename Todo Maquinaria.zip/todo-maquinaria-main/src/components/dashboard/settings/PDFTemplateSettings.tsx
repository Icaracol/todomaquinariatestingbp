
import { useState, useEffect } from "react";
import { PDFSettingsForm } from "./components/PDFSettingsForm";
import { PDFPreviewSection } from "./components/PDFPreviewSection";
import type { PDFSettings } from "./types";
import type { DbMachinery } from "@/types/machinery";
import { useDashboard } from "../useDashboard";
import { supabase } from "@/lib/supabase";
import { useToast } from "@/hooks/use-toast";

const defaultSettings: PDFSettings = {
  templateId: 'modern',
  colors: {
    primary: '#10B981',
    secondary: '#374151',
    accent: '#059669'
  },
  layout: {
    spacing: 'normal',
    headerAlignment: 'left'
  }
};

export function PDFTemplateSettings() {
  // Usar localStorage para persistencia inicial
  const [settings, setSettings] = useState<PDFSettings>(() => {
    try {
      const savedSettings = localStorage.getItem('pdfSettings');
      return savedSettings ? JSON.parse(savedSettings) : defaultSettings;
    } catch (e) {
      console.error('Error parsing saved settings:', e);
      return defaultSettings;
    }
  });
  
  const [isActive, setIsActive] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const { machinery } = useDashboard();
  const [selectedMachineIds, setSelectedMachineIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('selectedMachineIds');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });
  const [previewMachine, setPreviewMachine] = useState<Partial<DbMachinery>>();
  const { toast } = useToast();

  // Sincronizar selección de maquinaria con localStorage
  useEffect(() => {
    localStorage.setItem('selectedMachineIds', JSON.stringify(selectedMachineIds));
  }, [selectedMachineIds]);

  // Cargar configuraciones de Supabase
  useEffect(() => {
    const loadSettings = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (!session?.user?.id) return;

        const { data, error } = await supabase
          .from('pdf_settings')
          .select('settings')
          .eq('user_id', session.user.id)
          .maybeSingle();

        if (error && error.code !== 'PGRST116') {
          console.error('Error loading PDF settings:', error);
          return;
        }

        if (data?.settings) {
          setSettings(data.settings);
          localStorage.setItem('pdfSettings', JSON.stringify(data.settings));
        }
      } catch (error) {
        console.error('Error loading settings:', error);
      }
    };

    loadSettings();
  }, []);

  // Actualizar preview cuando cambia la maquinaria seleccionada
  useEffect(() => {
    if (machinery && machinery.length > 0) {
      const machineWithImages = machinery.filter(m => m.images && m.images.length > 0);
      if (machineWithImages.length > 0) {
        setPreviewMachine(machineWithImages[0]);
      } else {
        setPreviewMachine(machinery[0]);
      }
    }
  }, [machinery]);

  const handleSettingsChange = (newSettings: PDFSettings) => {
    setSettings(newSettings);
    localStorage.setItem('pdfSettings', JSON.stringify(newSettings));
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user?.id) throw new Error('No session found');

      const { error } = await supabase
        .from('pdf_settings')
        .upsert({
          user_id: session.user.id,
          settings
        });

      if (error) throw error;

      toast({
        title: "Configuración guardada",
        description: "Tus preferencias de PDF han sido actualizadas"
      });
    } catch (error) {
      console.error('Error saving PDF settings:', error);
      toast({
        title: "Error",
        description: "No se pudieron guardar las configuraciones",
        variant: "destructive"
      });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div>
        <PDFSettingsForm
          settings={settings}
          isActive={isActive}
          isSaving={isSaving}
          onSettingsChange={handleSettingsChange}
          onActiveChange={setIsActive}
          onSave={handleSave}
        />
      </div>
      <div>
        <PDFPreviewSection
          settings={settings}
          previewMachine={previewMachine || {
            name: "Ejemplo de máquina",
            description: "Esta es una vista previa de cómo se verá tu maquinaria en el PDF.",
            year: 2024,
            price: 100000,
            images: []
          }}
        />
      </div>
    </div>
  );
}
