import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Mail, Phone, MessageCircle, PenSquare } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { LeadStatus, Lead } from "@/types/leads";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { useToast } from "@/hooks/use-toast";

interface LeadListProps {
  leads: Lead[];
  onStatusChange: (leadId: string, newStatus: LeadStatus) => void;
  onAddNote: (leadId: string) => void;
  onUpdateLead: (leadId: string, updates: Partial<Lead>) => void;
}

const statusColors = {
  nuevo: "bg-blue-500",
  seguimiento: "bg-yellow-500",
  convertido: "bg-green-500",
  cerrado: "bg-gray-500"
} as const;

export function LeadList({
  leads,
  onStatusChange,
  onAddNote,
  onUpdateLead
}: LeadListProps) {
  const [editingLead, setEditingLead] = useState<Lead | null>(null);
  const [updatedData, setUpdatedData] = useState<Partial<Lead>>({});
  const { toast } = useToast();

  const getNextStatus = (currentStatus: LeadStatus): LeadStatus => {
    const statusFlow: Record<LeadStatus, LeadStatus> = {
      nuevo: "seguimiento",
      seguimiento: "convertido",
      convertido: "cerrado",
      cerrado: "nuevo"
    };
    return statusFlow[currentStatus];
  };

  const handleWhatsAppClick = (phone: string) => {
    if (!phone) return;
    const formattedPhone = phone.replace(/\D/g, '');
    window.open(`https://wa.me/${formattedPhone}`, '_blank');
  };

  const handleSaveUpdates = () => {
    if (editingLead && Object.keys(updatedData).length > 0) {
      if (updatedData.phone && updatedData.whatsapp && updatedData.phone === updatedData.whatsapp) {
        toast({
          title: "Error",
          description: "El número de teléfono y WhatsApp no pueden ser iguales",
          variant: "destructive"
        });
        return;
      }
      onUpdateLead(editingLead.id, updatedData);
      setEditingLead(null);
      setUpdatedData({});
      
      toast({
        title: "Lead actualizado",
        description: "La información del lead se actualizó correctamente"
      });
    }
  };

  return (
    <div className="space-y-4">
      {leads.map(lead => (
        <Card key={lead.id}>
          <CardContent className="p-6 bg-lime-100">
            <div className="flex flex-col text-left">
              <div className="flex items-center gap-2 mb-2">
                <h3 className="text-lg font-semibold">{lead.name}</h3>
                <Badge variant="secondary" className={statusColors[lead.status]}>
                  {lead.status}
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground mb-2 text-left">
                Interesado en: {lead.interest}
              </p>
              <div className="flex flex-col gap-2 text-sm text-muted-foreground mb-4">
                {lead.phone && <span className="flex items-center gap-1">
                    <Phone className="h-4 w-4" />
                    Teléfono: {lead.phone}
                  </span>}
                {lead.whatsapp && <span className="flex items-center gap-1">
                    <MessageCircle className="h-4 w-4" />
                    WhatsApp: {lead.whatsapp}
                  </span>}
                {lead.email && <span className="flex items-center gap-1">
                    <Mail className="h-4 w-4" />
                    Email: {lead.email}
                  </span>}
                <span className="flex items-center gap-1">
                  <Calendar className="h-4 w-4" />
                  Fecha: {new Date(lead.created_at).toLocaleDateString()}
                </span>
              </div>
              <div className="flex gap-2">
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => setEditingLead(lead)}
                        className="bg-gray-800 hover:bg-gray-700 text-white"
                      >
                        Editar
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Editar información del lead</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>

                {(lead.whatsapp || lead.phone) && (
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={() => handleWhatsAppClick(lead.whatsapp || lead.phone || '')}
                          className="bg-green-500 hover:bg-green-600 text-white [&>svg]:text-white"
                        >
                          <MessageCircle className="h-4 w-4 mr-1" />
                          WhatsApp
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Contactar por WhatsApp</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                )}

                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => onAddNote(lead.id)}
                        className="bg-lime-50 hover:bg-lime-100 text-gray-800 [&>svg]:text-gray-800"
                      >
                        <PenSquare className="h-4 w-4" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Agregar nota</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>

                {lead.status !== "cerrado" && <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button size="sm" onClick={() => onStatusChange(lead.id, getNextStatus(lead.status))}>
                          {lead.status === "nuevo" ? "Iniciar Seguimiento" : 
                           lead.status === "seguimiento" ? "Marcar como Convertido" : 
                           lead.status === "convertido" ? "Cerrar Lead" :
                           "Reabrir Lead"}
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Cambiar estado del lead</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>}
              </div>
            </div>
            {lead.notes && lead.notes.length > 0 && <div className="mt-4 pt-4 border-t">
                <h4 className="text-sm font-medium mb-2 text-left">Notas:</h4>
                <div className="space-y-2">
                  {lead.notes.map((note, index) => <div key={index} className="text-sm text-muted-foreground text-left">
                      {note}
                    </div>)}
                </div>
              </div>}
          </CardContent>
        </Card>
      ))}
      <Dialog open={!!editingLead} onOpenChange={() => setEditingLead(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Editar Lead</DialogTitle>
          </DialogHeader>
          {editingLead && <div className="space-y-4">
              <div className="space-y-2">
                <Label>Nombre</Label>
                <Input value={updatedData.name ?? editingLead.name} onChange={e => setUpdatedData({
              ...updatedData,
              name: e.target.value
            })} />
              </div>
              <div className="space-y-2">
                <Label>Email</Label>
                <Input value={updatedData.email ?? editingLead.email ?? ''} onChange={e => setUpdatedData({
              ...updatedData,
              email: e.target.value
            })} />
              </div>
              <div className="space-y-2">
                <Label>Teléfono</Label>
                <Input value={updatedData.phone ?? editingLead.phone ?? ''} onChange={e => setUpdatedData({
              ...updatedData,
              phone: e.target.value
            })} />
              </div>
              <div className="space-y-2">
                <Label>WhatsApp</Label>
                <Input value={updatedData.whatsapp ?? editingLead.whatsapp ?? ''} onChange={e => setUpdatedData({
              ...updatedData,
              whatsapp: e.target.value
            })} />
              </div>
            </div>}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditingLead(null)}>
              Cancelar
            </Button>
            <Button onClick={handleSaveUpdates}>
              Guardar cambios
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
