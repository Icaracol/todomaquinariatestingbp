
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search } from "lucide-react";
import { LeadList } from "./LeadList";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/lib/supabase";
import { LeadStatus, Lead } from "@/types/leads";

export function LeadsTab() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<LeadStatus | "todos">("todos");
  const [selectedLeadId, setSelectedLeadId] = useState<string | null>(null);
  const [newNote, setNewNote] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: leads = [], isLoading } = useQuery({
    queryKey: ["leads"],
    queryFn: async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user?.id) throw new Error("No autorizado");

      const { data, error } = await supabase
        .from("leads")
        .select("*")
        .eq("seller_id", session.user.id)
        .order("created_at", { ascending: false });

      if (error) {
        console.error("Error fetching leads:", error);
        throw error;
      }
      return data as Lead[];
    },
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ leadId, newStatus }: { leadId: string; newStatus: LeadStatus }) => {
      const { error } = await supabase
        .from("leads")
        .update({ status: newStatus })
        .eq("id", leadId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["leads"] });
      toast({
        title: "Estado actualizado",
        description: "El estado del lead ha sido actualizado correctamente.",
      });
    },
  });

  const updateLeadMutation = useMutation({
    mutationFn: async ({ leadId, updates }: { leadId: string; updates: Partial<Lead> }) => {
      const { error } = await supabase
        .from("leads")
        .update(updates)
        .eq("id", leadId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["leads"] });
      toast({
        title: "Lead actualizado",
        description: "La información del lead ha sido actualizada correctamente.",
      });
    },
  });

  const addNoteMutation = useMutation({
    mutationFn: async ({ leadId, note }: { leadId: string; note: string }) => {
      const { data: lead } = await supabase
        .from("leads")
        .select("notes")
        .eq("id", leadId)
        .single();

      const updatedNotes = [...(lead?.notes || []), note];

      const { error } = await supabase
        .from("leads")
        .update({ notes: updatedNotes })
        .eq("id", leadId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["leads"] });
      setSelectedLeadId(null);
      setNewNote("");
      toast({
        title: "Nota agregada",
        description: "La nota ha sido agregada correctamente.",
      });
    },
  });

  const filteredLeads = leads.filter((lead) => {
    const matchesSearch =
      lead.name.toLowerCase().includes(search.toLowerCase()) ||
      lead.email?.toLowerCase().includes(search.toLowerCase()) ||
      lead.interest.toLowerCase().includes(search.toLowerCase());
    
    const matchesStatus = statusFilter === "todos" || lead.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  if (isLoading) {
    return <div>Cargando leads...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Input
            type="search"
            placeholder="Buscar leads..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10"
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
        </div>
        <Select value={statusFilter} onValueChange={(value) => setStatusFilter(value as LeadStatus | "todos")}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Filtrar por estado" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todos</SelectItem>
            <SelectItem value="nuevo">Nuevos</SelectItem>
            <SelectItem value="seguimiento">En seguimiento</SelectItem>
            <SelectItem value="convertido">Convertidos</SelectItem>
            <SelectItem value="cerrado">Cerrados</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <LeadList
        leads={filteredLeads}
        onStatusChange={(leadId, newStatus) =>
          updateStatusMutation.mutate({ leadId, newStatus })
        }
        onAddNote={(leadId) => setSelectedLeadId(leadId)}
        onUpdateLead={(leadId, updates) =>
          updateLeadMutation.mutate({ leadId, updates })
        }
      />

      <Dialog open={!!selectedLeadId} onOpenChange={() => setSelectedLeadId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Agregar nota</DialogTitle>
          </DialogHeader>
          <Textarea
            placeholder="Escribe tu nota aquí..."
            value={newNote}
            onChange={(e) => setNewNote(e.target.value)}
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setSelectedLeadId(null)}>
              Cancelar
            </Button>
            <Button
              onClick={() => {
                if (selectedLeadId && newNote.trim()) {
                  addNoteMutation.mutate({
                    leadId: selectedLeadId,
                    note: newNote.trim(),
                  });
                }
              }}
            >
              Guardar nota
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
