
import { Edit } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

interface AdminEditModeToggleProps {
  isEnabled: boolean;
  onToggle: (enabled: boolean) => void;
}

export function AdminEditModeToggle({ isEnabled, onToggle }: AdminEditModeToggleProps) {
  return (
    <div className="mb-6 flex items-center gap-2 bg-white/80 backdrop-blur-sm p-4 rounded-xl shadow-lg border border-lime-100">
      <Switch
        id="edit-mode"
        checked={isEnabled}
        onCheckedChange={onToggle}
        className="data-[state=checked]:bg-lime-500"
      />
      <Label htmlFor="edit-mode" className="flex items-center gap-2 cursor-pointer text-gray-700 font-medium">
        <Edit className="h-4 w-4 text-lime-600" />
        Modo Edición
      </Label>
    </div>
  );
}
