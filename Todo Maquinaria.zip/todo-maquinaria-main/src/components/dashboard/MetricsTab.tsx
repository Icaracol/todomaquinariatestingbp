
import { useState } from "react";
import { Skeleton } from "@/components/ui/skeleton";
import { TimeRangeSelector } from "./metrics/TimeRangeSelector";
import { ViewsChart } from "./metrics/ViewsChart";
import { MessagesChart } from "./metrics/MessagesChart";
import { TopMachinesChart } from "./metrics/TopMachinesChart";
import { useMetricsData } from "./metrics/useMetricsData";

export function MetricsTab() {
  const [timeRange, setTimeRange] = useState("7");
  const { data: metricsData, isLoading } = useMetricsData(timeRange);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-[300px] w-full" />
        <Skeleton className="h-[300px] w-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <TimeRangeSelector value={timeRange} onChange={setTimeRange} />

      <div className="grid gap-6 md:grid-cols-2">
        <ViewsChart data={metricsData?.viewsData || []} />
        <MessagesChart data={metricsData?.messagesData || []} />
        <TopMachinesChart data={metricsData?.topMachines || []} />
      </div>
    </div>
  );
}
