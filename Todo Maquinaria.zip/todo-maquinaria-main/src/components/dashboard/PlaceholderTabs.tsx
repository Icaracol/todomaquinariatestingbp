
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { PDFTemplateSettings } from "./settings/PDFTemplateSettings";

export { MessagesTab } from "./MessagesTab";
export { MetricsTab } from "./MetricsTab";

export function SettingsTab() {
  return (
    <div className="space-y-6">
      <PDFTemplateSettings />
      
      <Card>
        <CardHeader>
          <CardTitle>Configuración General</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Aquí irían otras configuraciones generales */}
        </CardContent>
      </Card>
    </div>
  );
}
