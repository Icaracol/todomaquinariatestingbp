import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/lib/supabase";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { User, LogOut, Settings, ShoppingBag, ChevronDown, Building2, Shield, CreditCard } from "lucide-react";
import { useEffect, useState } from "react";
import { useAdmin } from "@/hooks/useAdmin";
export function DashboardNav() {
  const navigate = useNavigate();
  const {
    toast
  } = useToast();
  const {
    isAdmin
  } = useAdmin();
  const [isAdminUser, setIsAdminUser] = useState(false);
  useEffect(() => {
    const checkAdminStatus = async () => {
      const adminStatus = await isAdmin();
      setIsAdminUser(adminStatus);
    };
    checkAdminStatus();
  }, []);
  const handleLogout = async () => {
    try {
      const {
        error
      } = await supabase.auth.signOut();
      if (error) throw error;
      toast({
        title: "Sesión cerrada",
        description: "Has cerrado sesión correctamente"
      });
      navigate("/");
    } catch (error) {
      console.error("Error al cerrar sesión:", error);
      toast({
        title: "Error",
        description: "No se pudo cerrar la sesión",
        variant: "destructive"
      });
    }
  };
  return <nav className="border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
      <div className="container flex h-14 max-w-screen-2xl items-center">
        <div className="flex flex-1 items-center justify-between">
          <a href="/" className="flex items-center space-x-2">
            <img src="/lovable-uploads/b02b5c24-c115-4b33-8a03-f1aeefad99ab.png" alt="Logo" className="h-8 w-auto" />
          </a>

          <div className="flex items-center gap-2 bg-lime-50">
            <Button variant="ghost" onClick={() => navigate("/pricing")} className="hidden md:flex">
              <CreditCard className="mr-2 h-4 w-4" />
              Planes
            </Button>

            <Button variant="ghost" onClick={() => navigate("/catalogo")} className="hidden md:flex">
              <ShoppingBag className="mr-2 h-4 w-4" />
              Marketplace
            </Button>

            <Button variant="ghost" onClick={() => navigate("/subir-inventario")} className="hidden md:flex">
              <Building2 className="mr-2 h-4 w-4" />
              Publicar Maquinaria
            </Button>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src="" alt="Usuario" />
                    <AvatarFallback>
                      <User className="h-4 w-4" />
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" forceMount className="w-56 bg-lime-50">
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none">Mi Cuenta</p>
                    <p className="text-xs leading-none text-muted-foreground">
                      Configuración y opciones
                    </p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => navigate("/dashboard")}>
                  <User className="mr-2 h-4 w-4" />
                  Dashboard
                </DropdownMenuItem>
                {isAdminUser && <DropdownMenuItem onClick={() => navigate("/admin")}>
                    <Shield className="mr-2 h-4 w-4" />
                    Panel de Admin
                  </DropdownMenuItem>}
                <DropdownMenuItem onClick={() => navigate("/configuracion")}>
                  <Settings className="mr-2 h-4 w-4" />
                  Configuración
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => navigate("/pricing")}>
                  <CreditCard className="mr-2 h-4 w-4" />
                  Planes y Precios
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  Cerrar Sesión
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </nav>;
}