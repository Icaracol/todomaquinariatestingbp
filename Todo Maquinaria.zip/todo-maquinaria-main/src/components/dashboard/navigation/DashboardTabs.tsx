
import { Package, MessageSquare, BarChart3, Settings, UserSquare, Users, Edit } from "lucide-react";
import { TabsList, TabsTrigger } from "@/components/ui/tabs";

interface DashboardTabsProps {
  isAdmin: boolean;
  isEditMode: boolean;
}

export function DashboardTabs({ isAdmin, isEditMode }: DashboardTabsProps) {
  return (
    <TabsList className="inline-flex p-1 bg-gray-100/80 rounded-xl backdrop-blur-sm space-x-2">
      <TabsTrigger 
        value="inventario" 
        className="rounded-lg px-4 py-2 data-[state=active]:bg-white data-[state=active]:text-lime-700 data-[state=active]:shadow-md transition-all duration-200 hover:text-lime-600"
      >
        <div className="flex items-center gap-2">
          <Package className="h-4 w-4" />
          <span className="font-medium">Inventario</span>
        </div>
      </TabsTrigger>
      <TabsTrigger 
        value="leads"
        className="rounded-lg px-4 py-2 data-[state=active]:bg-white data-[state=active]:text-lime-700 data-[state=active]:shadow-md transition-all duration-200 hover:text-lime-600"
      >
        <div className="flex items-center gap-2">
          <UserSquare className="h-4 w-4" />
          <span className="font-medium">Leads</span>
        </div>
      </TabsTrigger>
      <TabsTrigger 
        value="mensajes"
        className="rounded-lg px-4 py-2 data-[state=active]:bg-white data-[state=active]:text-lime-700 data-[state=active]:shadow-md transition-all duration-200 hover:text-lime-600"
      >
        <div className="flex items-center gap-2">
          <MessageSquare className="h-4 w-4" />
          <span className="font-medium">Mensajes</span>
        </div>
      </TabsTrigger>
      <TabsTrigger 
        value="metricas"
        className="rounded-lg px-4 py-2 data-[state=active]:bg-white data-[state=active]:text-lime-700 data-[state=active]:shadow-md transition-all duration-200 hover:text-lime-600"
      >
        <div className="flex items-center gap-2">
          <BarChart3 className="h-4 w-4" />
          <span className="font-medium">Métricas</span>
        </div>
      </TabsTrigger>
      <TabsTrigger 
        value="configuracion"
        className="rounded-lg px-4 py-2 data-[state=active]:bg-white data-[state=active]:text-lime-700 data-[state=active]:shadow-md transition-all duration-200 hover:text-lime-600"
      >
        <div className="flex items-center gap-2">
          <Settings className="h-4 w-4" />
          <span className="font-medium">Configuración</span>
        </div>
      </TabsTrigger>
      {isAdmin && (
        <TabsTrigger 
          value="admin"
          className="rounded-lg px-4 py-2 data-[state=active]:bg-white data-[state=active]:text-lime-700 data-[state=active]:shadow-md transition-all duration-200 hover:text-lime-600"
        >
          <div className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            <span className="font-medium">Usuarios</span>
          </div>
        </TabsTrigger>
      )}
      {isAdmin && isEditMode && (
        <TabsTrigger 
          value="pages"
          className="rounded-lg px-4 py-2 data-[state=active]:bg-white data-[state=active]:text-lime-700 data-[state=active]:shadow-md transition-all duration-200 hover:text-lime-600"
        >
          <div className="flex items-center gap-2">
            <Edit className="h-4 w-4" />
            <span className="font-medium">Páginas</span>
          </div>
        </TabsTrigger>
      )}
    </TabsList>
  );
}
