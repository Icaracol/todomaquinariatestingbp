
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/lib/supabase";
import { format, subDays, startOfDay } from "date-fns";
import { es } from "date-fns/locale";

export function useMetricsData(timeRange: string) {
  return useQuery({
    queryKey: ['metrics', timeRange],
    queryFn: async () => {
      const days = parseInt(timeRange);
      const startDate = startOfDay(subDays(new Date(), days));

      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user?.id) throw new Error('No hay sesión activa');

      const { data: machinery, error: machineryError } = await supabase
        .from('machinery')
        .select('id, name, views, created_at')
        .eq('user_id', session.user.id);

      if (machineryError) throw machineryError;

      const { data: messages, error: messagesError } = await supabase
        .from('messages')
        .select('created_at, machinery_id')
        .eq('recipient_id', session.user.id)
        .gte('created_at', startDate.toISOString());

      if (messagesError) throw messagesError;

      const dailyViews: { [key: string]: number } = {};
      const dailyMessages: { [key: string]: number } = {};
      const machineViews: { name: string; views: number }[] = [];

      for (let i = 0; i <= days; i++) {
        const date = format(subDays(new Date(), i), 'yyyy-MM-dd');
        dailyViews[date] = 0;
        dailyMessages[date] = 0;
      }

      messages.forEach(message => {
        const date = format(new Date(message.created_at), 'yyyy-MM-dd');
        if (dailyMessages[date] !== undefined) {
          dailyMessages[date]++;
        }
      });

      machinery.forEach(machine => {
        machineViews.push({
          name: machine.name,
          views: machine.views || 0
        });
      });

      const viewsData = Object.entries(dailyViews).map(([date, views]) => ({
        date: format(new Date(date), 'd MMM', { locale: es }),
        views,
      })).reverse();

      const messagesData = Object.entries(dailyMessages).map(([date, count]) => ({
        date: format(new Date(date), 'd MMM', { locale: es }),
        mensajes: count,
      })).reverse();

      const topMachines = machineViews
        .sort((a, b) => b.views - a.views)
        .slice(0, 5);

      return {
        viewsData,
        messagesData,
        topMachines,
        totalViews: machineViews.reduce((sum, item) => sum + item.views, 0),
        totalMessages: messages.length,
      };
    },
  });
}
