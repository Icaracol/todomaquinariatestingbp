import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/lib/supabase";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { formatDistanceToNow } from "date-fns";
import { es } from "date-fns/locale";
import type { Conversation, Message } from "@/types/messages";
export function MessagesTab() {
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null);
  const [newMessage, setNewMessage] = useState("");
  const [userId, setUserId] = useState<string | null>(null);
  useEffect(() => {
    supabase.auth.getSession().then(({
      data: {
        session
      }
    }) => {
      if (session?.user?.id) {
        setUserId(session.user.id);
      }
    });
  }, []);
  const {
    data: conversations,
    isLoading
  } = useQuery({
    queryKey: ['conversations'],
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from('conversations').select(`
          *,
          messages!inner (
            content,
            created_at,
            sender_id
          ),
          machinery (
            id,
            name
          )
        `).order('last_message_at', {
        ascending: false
      });
      if (error) throw error;
      const enrichedConversations = await Promise.all((data || []).map(async (conv: any) => {
        const otherUserId = conv.user1_id === userId ? conv.user2_id : conv.user1_id;
        const {
          data: userData
        } = await supabase.from('users').select('email').eq('id', otherUserId).single();
        return {
          ...conv,
          otherUser: {
            id: otherUserId,
            email: userData?.email
          },
          lastMessage: conv.messages?.[0]
        };
      }));
      return enrichedConversations as Conversation[];
    },
    enabled: !!userId
  });
  const {
    data: messages,
    isLoading: messagesLoading
  } = useQuery({
    queryKey: ['messages', selectedConversation?.id],
    queryFn: async () => {
      if (!selectedConversation?.id) return [];
      const {
        data,
        error
      } = await supabase.from('messages').select('*').eq('conversation_id', selectedConversation.id).order('created_at', {
        ascending: true
      });
      if (error) throw error;
      return data as Message[];
    },
    enabled: !!selectedConversation
  });
  const handleSendMessage = async () => {
    if (!newMessage.trim() || !selectedConversation || !userId) return;
    const recipientId = selectedConversation.user1_id === userId ? selectedConversation.user2_id : selectedConversation.user1_id;
    const message = {
      conversation_id: selectedConversation.id,
      machinery_id: selectedConversation.machinery_id,
      sender_id: userId,
      recipient_id: recipientId,
      content: newMessage.trim()
    };
    try {
      await supabase.from('messages').insert([message]);
      await supabase.from('conversations').update({
        last_message_at: new Date().toISOString()
      }).eq('id', selectedConversation.id);
      setNewMessage("");
    } catch (error) {
      console.error('Error al enviar mensaje:', error);
    }
  };
  if (isLoading) {
    return <div className="space-y-4">
        <Skeleton className="h-20 w-full" />
        <Skeleton className="h-20 w-full" />
        <Skeleton className="h-20 w-full" />
      </div>;
  }
  return <div className="grid md:grid-cols-[300px,1fr] gap-4">
      <Card className="md:h-[calc(100vh-12rem)] flex flex-col">
        <CardHeader className="bg-lime-300 hover:bg-lime-200">
          <CardTitle>Conversaciones</CardTitle>
        </CardHeader>
        <CardContent className="flex-1 overflow-y-auto space-y-2 bg-lime-100">
          {conversations?.map(conversation => <Button key={conversation.id} variant={selectedConversation?.id === conversation.id ? "default" : "ghost"} className="w-full justify-start text-left h-auto py-3" onClick={() => setSelectedConversation(conversation)}>
              <div className="space-y-1">
                <div className="font-medium">
                  {conversation.otherUser?.email || 'Usuario'}
                </div>
                {conversation.machinery && <div className="text-sm text-muted-foreground">
                    Re: {conversation.machinery.name}
                  </div>}
                {conversation.lastMessage && <div className="text-sm text-muted-foreground truncate">
                    {formatDistanceToNow(new Date(conversation.last_message_at), {
                addSuffix: true,
                locale: es
              })}
                  </div>}
              </div>
            </Button>)}
        </CardContent>
      </Card>

      {selectedConversation ? <Card className="md:h-[calc(100vh-12rem)] flex flex-col">
          <CardHeader>
            <CardTitle>
              Chat con {selectedConversation.otherUser?.email || 'Usuario'}
              {selectedConversation.machinery && <div className="text-sm font-normal text-muted-foreground mt-1">
                  Sobre: {selectedConversation.machinery.name}
                </div>}
            </CardTitle>
          </CardHeader>
          <CardContent className="flex-1 flex flex-col">
            <div className="flex-1 overflow-y-auto space-y-4 mb-4">
              {messagesLoading ? <div className="space-y-4">
                  <Skeleton className="h-12 w-2/3" />
                  <Skeleton className="h-12 w-2/3 ml-auto" />
                  <Skeleton className="h-12 w-2/3" />
                </div> : messages?.map(message => <div key={message.id} className={`flex ${message.sender_id === userId ? 'justify-end' : 'justify-start'}`}>
                    <div className={`rounded-lg px-4 py-2 max-w-[70%] ${message.sender_id === userId ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
                      <p>{message.content}</p>
                      <span className="text-xs opacity-70">
                        {formatDistanceToNow(new Date(message.created_at), {
                  addSuffix: true,
                  locale: es
                })}
                      </span>
                    </div>
                  </div>)}
            </div>
            <div className="flex gap-2">
              <Textarea value={newMessage} onChange={e => setNewMessage(e.target.value)} placeholder="Escribe un mensaje..." className="resize-none" onKeyDown={e => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              handleSendMessage();
            }
          }} />
              <Button onClick={handleSendMessage}>
                Enviar
              </Button>
            </div>
          </CardContent>
        </Card> : <Card className="md:h-[calc(100vh-12rem)] flex items-center justify-center bg-lime-100">
          <CardContent>
            <p className="text-muted-foreground">
              Selecciona una conversación para ver los mensajes
            </p>
          </CardContent>
        </Card>}
    </div>;
}