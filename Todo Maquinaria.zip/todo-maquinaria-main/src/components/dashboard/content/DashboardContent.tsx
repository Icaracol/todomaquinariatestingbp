
import { TabsContent } from "@/components/ui/tabs";
import { MachineryList } from "@/components/dashboard/MachineryList";
import { MessagesTab } from "@/components/dashboard/MessagesTab";
import { MetricsTab } from "@/components/dashboard/MetricsTab";
import { LeadsTab } from "@/components/dashboard/leads/LeadsTab";
import { SettingsTab } from "@/components/dashboard/PlaceholderTabs";
import { AdminPanel } from "@/components/admin/AdminPanel";
import { PageManager } from "@/components/admin/PageManager";

interface DashboardContentProps {
  isAdmin: boolean;
  isEditMode: boolean;
  loading: boolean;
  machinery: any[];
  searchTerm: string;
  statusFilter: string;
  onSearchChange: (value: string) => void;
  onStatusChange: (value: string) => void;
}

export function DashboardContent({
  isAdmin,
  isEditMode,
  loading,
  machinery,
  searchTerm,
  statusFilter,
  onSearchChange,
  onStatusChange,
}: DashboardContentProps) {
  return (
    <div className="mt-8">
      <TabsContent value="inventario" className="space-y-6 animate-in fade-in-50">
        <MachineryList 
          loading={loading} 
          machinery={machinery} 
          searchTerm={searchTerm} 
          statusFilter={statusFilter} 
          onSearchChange={onSearchChange} 
          onStatusChange={onStatusChange} 
        />
      </TabsContent>

      <TabsContent value="leads" className="space-y-6 animate-in fade-in-50">
        <LeadsTab />
      </TabsContent>

      <TabsContent value="mensajes" className="space-y-6 animate-in fade-in-50">
        <MessagesTab />
      </TabsContent>

      <TabsContent value="metricas" className="space-y-6 animate-in fade-in-50">
        <MetricsTab />
      </TabsContent>

      <TabsContent value="configuracion" className="space-y-6 animate-in fade-in-50">
        <SettingsTab />
      </TabsContent>

      {isAdmin && (
        <TabsContent value="admin" className="space-y-6 animate-in fade-in-50">
          <AdminPanel />
        </TabsContent>
      )}

      {isAdmin && isEditMode && (
        <TabsContent value="pages" className="space-y-6 animate-in fade-in-50">
          <PageManager />
        </TabsContent>
      )}
    </div>
  );
}
