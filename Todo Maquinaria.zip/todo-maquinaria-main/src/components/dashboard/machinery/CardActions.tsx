
import { Button } from "@/components/ui/button";
import { Share2, Settings } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface CardActionsProps {
  machineId: string;
  onShareClick: () => void;
}

export function CardActions({ machineId, onShareClick }: CardActionsProps) {
  const navigate = useNavigate();
  
  return (
    <div className="flex items-center gap-2">
      <Button 
        variant="outline"
        size="sm"
        onClick={(e) => {
          e.stopPropagation();
          onShareClick();
        }}
      >
        <Share2 className="h-4 w-4 mr-2" />
        Compartir
      </Button>
      <Button
        variant="default"
        size="sm"
        onClick={(e) => {
          e.stopPropagation();
          navigate(`/dashboard/maquinaria/${machineId}/editar`);
        }}
      >
        <Settings className="h-4 w-4 mr-2" />
        Editar
      </Button>
    </div>
  );
}
