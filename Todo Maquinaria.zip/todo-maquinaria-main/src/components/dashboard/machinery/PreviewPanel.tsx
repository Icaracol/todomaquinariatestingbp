
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { PDFPreviewSection } from "../settings/components/PDFPreviewSection";
import type { DbMachinery } from "@/types/machinery";

interface PreviewPanelProps {
  previewMachines: DbMachinery[];
}

export function PreviewPanel({ previewMachines }: PreviewPanelProps) {
  return (
    <Card className="sticky top-6">
      <CardHeader>
        <CardTitle>Vista previa del PDF</CardTitle>
        <p className="text-sm text-gray-500">
          {previewMachines.length === 0 
            ? "Selecciona maquinaria para ver la vista previa"
            : `${previewMachines.length} ${previewMachines.length === 1 ? 'máquina seleccionada' : 'máquinas seleccionadas'}`}
        </p>
      </CardHeader>
      <CardContent>
        {previewMachines.length > 0 ? (
          <div className="space-y-6">
            {previewMachines.map((machine) => (
              <div key={machine.id} className="border-t pt-4 first:border-t-0 first:pt-0">
                <PDFPreviewSection
                  settings={{
                    templateId: 'modern',
                    colors: {
                      primary: '#1a1a1a',
                      secondary: '#4a4a4a',
                      accent: '#0ea5e9'
                    }
                  }}
                  previewMachine={machine}
                />
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center p-8 bg-gray-50 rounded-lg">
            <p className="text-gray-500">
              Selecciona maquinaria para ver la vista previa
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
