
import { Package, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";

export function EmptyState() {
  const navigate = useNavigate();
  
  return (
    <div className="flex flex-col items-center justify-center h-64 bg-gray-50/50 rounded-lg p-8">
      <Package className="h-12 w-12 text-gray-400" />
      <h3 className="text-lg font-medium text-gray-900 mt-4">
        No hay maquinaria registrada
      </h3>
      <p className="text-sm text-gray-500 text-center mt-2 max-w-sm">
        Comienza a construir tu catálogo agregando tu primera maquinaria
      </p>
      <Button 
        onClick={() => navigate('/subir-inventario')}
        className="mt-6"
        size="lg"
      >
        <Plus className="mr-2 h-4 w-4" />
        Agregar primera maquinaria
      </Button>
    </div>
  );
}
