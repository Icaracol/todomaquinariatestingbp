
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { ImageIcon, ChevronLeft, ChevronRight } from "lucide-react";
import type { MachineryImage } from "@/types/machinery";
import { useState } from "react";
import { Button } from "@/components/ui/button";

interface CardHeaderProps {
  machineId: string;
  primaryImage?: string;
  allImages?: MachineryImage[];
  isSelected: boolean;
  isPublic: boolean;
  onToggleSelect: (checked: boolean) => void;
  onToggleVisibility: (id: string, currentValue: boolean) => void;
}

export function CardHeader({
  machineId,
  primaryImage,
  allImages = [],
  isSelected,
  isPublic,
  onToggleSelect,
  onToggleVisibility,
}: CardHeaderProps) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const handleControlsClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleImageNavigation = (direction: 'prev' | 'next') => {
    if (allImages.length <= 1) return;
    
    setCurrentImageIndex(current => {
      if (direction === 'prev') {
        return current === 0 ? allImages.length - 1 : current - 1;
      } else {
        return current === allImages.length - 1 ? 0 : current + 1;
      }
    });
  };

  return (
    <div className="relative">
      <div className="aspect-video bg-muted relative group">
        {/* Controls layer */}
        <div 
          className="absolute top-4 right-4 z-20 flex items-center gap-2"
          onClick={handleControlsClick}
        >
          <div className="bg-white/95 backdrop-blur rounded-md p-2 shadow-sm cursor-pointer hover:bg-white">
            <Checkbox 
              checked={isSelected} 
              onCheckedChange={onToggleSelect}
              className="data-[state=checked]:bg-primary"
              id={`checkbox-${machineId}`}
            />
          </div>
          
          <div className="flex items-center gap-2 bg-white/95 backdrop-blur px-3 py-2 rounded-full shadow-sm">
            <span className="text-sm font-medium text-gray-700">
              {isPublic ? "Público" : "Privado"}
            </span>
            <Switch 
              checked={isPublic} 
              onCheckedChange={() => onToggleVisibility(machineId, isPublic)} 
              className="data-[state=checked]:bg-green-500"
            />
          </div>
        </div>

        {/* Navigation buttons */}
        {allImages.length > 1 && (
          <>
            <Button
              variant="ghost"
              size="icon"
              className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white rounded-full"
              onClick={(e) => {
                e.stopPropagation();
                handleImageNavigation('prev');
              }}
            >
              <ChevronLeft className="h-6 w-6" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white rounded-full"
              onClick={(e) => {
                e.stopPropagation();
                handleImageNavigation('next');
              }}
            >
              <ChevronRight className="h-6 w-6" />
            </Button>
          </>
        )}

        {/* Main image */}
        <div className="w-full h-full">
          {allImages && allImages.length > 0 ? (
            <img 
              src={allImages[currentImageIndex].url} 
              alt="Maquinaria" 
              className="w-full h-full object-cover transition-all duration-200 group-hover:opacity-95" 
              loading="lazy"
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                target.src = '/placeholder.svg';
                target.classList.add('bg-gray-100');
              }}
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-gray-100">
              <ImageIcon className="h-12 w-12 text-gray-400" />
            </div>
          )}
        </div>

        {/* Thumbnails strip */}
        {allImages.length > 1 && (
          <div className="absolute bottom-4 left-4 right-4 flex justify-center">
            <div className="bg-black/50 backdrop-blur-sm rounded-lg p-2">
              <div className="flex gap-2">
                {allImages.map((image, index) => (
                  <button
                    key={image.id}
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      setCurrentImageIndex(index);
                    }}
                    className={`w-16 h-12 rounded-md overflow-hidden transition-all ${
                      index === currentImageIndex 
                        ? 'ring-2 ring-white ring-offset-1 ring-offset-black/50' 
                        : 'opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img
                      src={image.url}
                      alt={`Miniatura ${index + 1}`}
                      className="w-full h-full object-cover"
                      loading="lazy"
                    />
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Image counter */}
        <div className="absolute top-4 left-4 bg-black/50 backdrop-blur-sm text-white px-2 py-1 rounded-md text-sm">
          {currentImageIndex + 1} / {allImages.length || 1}
        </div>
      </div>
    </div>
  );
}
