
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { DbMachinery, MachineryImage } from "@/types/machinery";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import { supabase } from "@/lib/supabase";
import { useToast } from "@/hooks/use-toast";
import { CardHeader } from "./CardHeader";
import { CardActions } from "./CardActions";
import { ShareDialog } from "./ShareDialog";

interface MachineryCardProps {
  machine: DbMachinery;
  isSelected: boolean;
  onToggleSelect: (checked: boolean) => void;
  onToggleVisibility: (id: string, currentValue: boolean) => void;
  onImagesUpdate?: (updatedImages: MachineryImage[]) => void;
}

export function MachineryCard({
  machine,
  isSelected,
  onToggleSelect,
  onToggleVisibility,
  onImagesUpdate,
}: MachineryCardProps) {
  const [showShareDialog, setShowShareDialog] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleGenerateShareLink = async () => {
    try {
      const shareToken = crypto.randomUUID();
      const { error } = await supabase
        .from('machinery')
        .update({ share_token: shareToken })
        .eq('id', machine.id);
      
      if (error) throw error;

      const shareUrl = `${window.location.origin}/catalogo/compartido/${shareToken}`;
      await navigator.clipboard.writeText(shareUrl);
      
      toast({
        title: "Enlace copiado",
        description: "El enlace de tu maquinaria ha sido copiado al portapapeles"
      });

      setShowShareDialog(false);
    } catch (error) {
      console.error('Error generating share link:', error);
      toast({
        title: "Error",
        description: "No se pudo generar el enlace compartido",
        variant: "destructive"
      });
    }
  };

  const handleCardClick = () => {
    navigate(`/dashboard/maquinaria/${machine.id}`);
  };

  return (
    <>
      <Card 
        className="relative rounded-xl overflow-hidden bg-white shadow-sm hover:shadow-md transition-shadow cursor-pointer group"
        onClick={handleCardClick}
      >
        <CardContent className="p-0">
          <CardHeader
            machineId={machine.id}
            primaryImage={machine.images?.find(img => img.is_primary)?.url}
            allImages={machine.images}
            isSelected={isSelected}
            isPublic={machine.is_public}
            onToggleSelect={onToggleSelect}
            onToggleVisibility={onToggleVisibility}
          />

          <div className="p-6 pt-4">
            <div className="flex justify-between items-start mb-4">
              <h3 className="font-bold text-xl text-gray-900">{machine.name}</h3>
            </div>

            <div className="flex items-center gap-2 text-sm mb-2">
              <Badge variant="outline" className="bg-green-50">
                {machine.views || 0} visualizaciones
              </Badge>
              {machine.is_public && (
                <Badge variant="outline" className="bg-blue-50">
                  Publicado
                </Badge>
              )}
            </div>

            <div className="space-y-2">
              <p className="font-semibold text-lg text-gray-900">
                {machine.price ? `$${machine.price.toLocaleString()} USD` : 'Precio no especificado'}
              </p>
              <p className="text-gray-500">
                Año: {machine.year || 'No especificado'}
              </p>
            </div>

            <div className="flex items-center justify-between mt-4 pt-4 border-t">
              <CardActions 
                machineId={machine.id}
                onShareClick={() => setShowShareDialog(true)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <ShareDialog
        open={showShareDialog}
        onOpenChange={setShowShareDialog}
        onGenerateLink={handleGenerateShareLink}
        hasShareToken={!!machine.share_token}
      />
    </>
  );
}
