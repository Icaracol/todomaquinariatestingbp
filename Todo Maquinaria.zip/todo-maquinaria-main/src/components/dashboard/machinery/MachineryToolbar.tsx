import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Search, Download } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
interface MachineryToolbarProps {
  searchTerm: string;
  statusFilter: string;
  selectedCount: number;
  selectAll: boolean;
  onToggleSelectAll: () => void;
  onSearchChange: (value: string) => void;
  onStatusChange: (value: string) => void;
  onDownloadPDF: () => void;
}
export function MachineryToolbar({
  searchTerm,
  statusFilter,
  selectedCount,
  selectAll,
  onToggleSelectAll,
  onSearchChange,
  onStatusChange,
  onDownloadPDF
}: MachineryToolbarProps) {
  return <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-end w-full max-w-full">
      <div className="flex-1 min-w-[200px] max-w-xs">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input placeholder="Buscar maquinaria..." value={searchTerm} onChange={e => onSearchChange(e.target.value)} className="pl-10 bg-white" />
        </div>
      </div>
      
      <div className="flex items-center gap-4">
        <Select value={statusFilter} onValueChange={onStatusChange}>
          <SelectTrigger className="w-[180px] bg-white">
            <SelectValue placeholder="Filtrar por estado" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="todos">Todos</SelectItem>
            <SelectItem value="available">Verificados</SelectItem>
            <SelectItem value="reserved">Pendientes</SelectItem>
            <SelectItem value="sold">Vendidos</SelectItem>
          </SelectContent>
        </Select>

        <div className="flex items-center gap-2 min-w-[140px]">
          <Checkbox id="selectAll" checked={selectAll} onCheckedChange={onToggleSelectAll} />
          <label htmlFor="selectAll" className="text-sm text-gray-600">
            Seleccionar todo
          </label>
        </div>

        <Button variant="outline" onClick={onDownloadPDF} disabled={selectedCount === 0} className="whitespace-nowrap text-zinc-950 bg-lime-300 hover:bg-lime-200">
          <Download className="mr-2 h-4 w-4" />
          PDF {selectedCount > 0 ? `(${selectedCount})` : ''}
        </Button>
      </div>
    </div>;
}