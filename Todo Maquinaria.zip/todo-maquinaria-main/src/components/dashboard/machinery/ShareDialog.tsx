
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Share2 } from "lucide-react";

interface ShareDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onGenerateLink: () => Promise<void>;
  hasShareToken: boolean;
}

export function ShareDialog({
  open,
  onOpenChange,
  onGenerateLink,
  hasShareToken
}: ShareDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Compartir maquinaria</DialogTitle>
          <DialogDescription>
            Genera un enlace para compartir esta maquinaria directamente
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 pt-4">
          <Button onClick={onGenerateLink} className="w-full">
            <Share2 className="mr-2 h-4 w-4" />
            Generar enlace compartible
          </Button>
          {hasShareToken && (
            <p className="text-sm text-muted-foreground text-center">
              El enlace se ha copiado al portapapeles
            </p>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
