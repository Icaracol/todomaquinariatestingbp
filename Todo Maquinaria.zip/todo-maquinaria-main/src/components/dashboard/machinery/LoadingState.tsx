
export function LoadingState() {
  return (
    <div className="flex items-center justify-center h-64 bg-gray-50/50 rounded-lg">
      <div className="text-center">
        <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent align-[-0.125em]"></div>
        <p className="text-sm text-gray-500 mt-4">Cargando tu inventario...</p>
      </div>
    </div>
  );
}
