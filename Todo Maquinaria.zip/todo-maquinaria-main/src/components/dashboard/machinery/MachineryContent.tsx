
import { Card, CardHeader, CardContent, CardTitle } from "@/components/ui/card";
import { MachineryToolbar } from "./MachineryToolbar";
import { MachineryCard } from "./MachineryCard";
import { LoadingState } from "./LoadingState";
import { EmptyState } from "./EmptyState";
import type { DbMachinery } from "@/types/machinery";
import type { MachineryImage } from "@/types/machinery";

interface MachineryContentProps {
  loading: boolean;
  machinery: DbMachinery[];
  searchTerm: string;
  statusFilter: string;
  selectedItems: string[];
  selectAll: boolean;
  onToggleSelectAll: () => void;
  onSearchChange: (value: string) => void;
  onStatusChange: (value: string) => void;
  onDownloadPDF: () => void;
  onToggleSelect: (id: string, checked: boolean) => void;
  onToggleVisibility: (id: string, currentValue: boolean) => void;
  onImagesUpdate: (id: string, images: MachineryImage[]) => void;
}

export function MachineryContent({
  loading,
  machinery,
  searchTerm,
  statusFilter,
  selectedItems,
  selectAll,
  onToggleSelectAll,
  onSearchChange,
  onStatusChange,
  onDownloadPDF,
  onToggleSelect,
  onToggleVisibility,
  onImagesUpdate,
}: MachineryContentProps) {
  return (
    <Card className="bg-white border shadow">
      <CardHeader className="border-b bg-gray-50/80">
        <div className="flex flex-col space-y-4 lg:flex-row lg:items-center lg:justify-between lg:space-y-0">
          <div>
            <CardTitle className="text-2xl font-semibold text-gray-900">
              Mi Inventario
            </CardTitle>
            <p className="text-sm text-gray-500 mt-1">
              Gestiona tu catálogo de maquinaria
            </p>
          </div>
          <MachineryToolbar
            searchTerm={searchTerm}
            statusFilter={statusFilter}
            selectedCount={selectedItems.length}
            selectAll={selectAll}
            onToggleSelectAll={onToggleSelectAll}
            onSearchChange={onSearchChange}
            onStatusChange={onStatusChange}
            onDownloadPDF={onDownloadPDF}
          />
        </div>
      </CardHeader>
      <CardContent className="p-6">
        {loading ? (
          <LoadingState />
        ) : machinery.length === 0 ? (
          <EmptyState />
        ) : (
          <div className="grid gap-4 sm:gap-6 grid-cols-1 sm:grid-cols-2">
            {machinery.map(machine => (
              <MachineryCard
                key={machine.id}
                machine={machine}
                isSelected={selectedItems.includes(machine.id)}
                onToggleSelect={(checked) => onToggleSelect(machine.id, checked)}
                onToggleVisibility={onToggleVisibility}
                onImagesUpdate={(updatedImages) => onImagesUpdate(machine.id, updatedImages)}
              />
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
