
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/lib/supabase";
import type { DbMachinery } from "@/types/machinery";
import { MachineryContent } from "./machinery/MachineryContent";
import { PreviewPanel } from "./machinery/PreviewPanel";
import { useMachineryPDF } from "@/hooks/useMachineryPDF";

interface MachineryListProps {
  loading: boolean;
  machinery: DbMachinery[];
  searchTerm: string;
  statusFilter: string;
  onSearchChange: (value: string) => void;
  onStatusChange: (value: string) => void;
}

export function MachineryList({
  loading,
  machinery,
  searchTerm,
  statusFilter,
  onSearchChange,
  onStatusChange
}: MachineryListProps) {
  const { toast } = useToast();
  const { generatePDF } = useMachineryPDF();

  const [selectedItems, setSelectedItems] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('selectedMachinery');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [selectAll, setSelectAll] = useState(false);
  const [previewMachines, setPreviewMachines] = useState<DbMachinery[]>([]);

  useEffect(() => {
    localStorage.setItem('selectedMachinery', JSON.stringify(selectedItems));
    const selected = machinery.filter(m => selectedItems.includes(m.id));
    setPreviewMachines(selected);
  }, [selectedItems, machinery]);

  useEffect(() => {
    if (selectAll) {
      setSelectedItems(machinery.map(m => m.id));
    } else if (selectedItems.length === machinery.length) {
      setSelectedItems([]);
    }
  }, [selectAll, machinery]);

  const handleVisibilityToggle = async (machineId: string, currentValue: boolean) => {
    try {
      const { error } = await supabase
        .from('machinery')
        .update({ is_public: !currentValue })
        .eq('id', machineId);

      if (error) throw error;

      toast({
        title: "Visibilidad actualizada",
        description: `La maquinaria ahora está ${!currentValue ? 'pública' : 'privada'}`,
      });
    } catch (error) {
      console.error('Error updating visibility:', error);
      toast({
        title: "Error",
        description: "No se pudo actualizar la visibilidad",
        variant: "destructive"
      });
    }
  };

  const handleToggleSelect = (id: string, checked: boolean) => {
    if (checked) {
      setSelectedItems(prev => [...prev, id]);
    } else {
      setSelectedItems(prev => prev.filter(itemId => itemId !== id));
      setSelectAll(false);
    }
  };

  const handleImagesUpdate = async (machineId: string, updatedImages: any[]) => {
    // Función para actualizar las imágenes si es necesario
  };

  const handleDownloadPDF = async () => {
    const selectedMachines = selectAll 
      ? machinery 
      : machinery.filter(m => selectedItems.includes(m.id));

    if (selectedMachines.length === 0) {
      toast({
        title: "Error",
        description: "Por favor selecciona al menos una máquina",
        variant: "destructive"
      });
      return;
    }

    await generatePDF(selectedMachines);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-2">
        <MachineryContent
          loading={loading}
          machinery={machinery}
          searchTerm={searchTerm}
          statusFilter={statusFilter}
          selectedItems={selectedItems}
          selectAll={selectAll}
          onToggleSelectAll={() => setSelectAll(!selectAll)}
          onSearchChange={onSearchChange}
          onStatusChange={onStatusChange}
          onDownloadPDF={handleDownloadPDF}
          onToggleSelect={handleToggleSelect}
          onToggleVisibility={handleVisibilityToggle}
          onImagesUpdate={handleImagesUpdate}
        />
      </div>
      <div className="lg:col-span-1">
        <PreviewPanel previewMachines={previewMachines} />
      </div>
    </div>
  );
}
