
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { FileSpreadsheet, Upload, Download, Info } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface DashboardHeaderProps {
  onImportClick: () => void;
}

export function DashboardHeader({
  onImportClick
}: DashboardHeaderProps) {
  const downloadCSVTemplate = () => {
    const headers = ["name", "description", "price", "year", "location", "category_id", "status", "type", "images_urls"].join(",");
    const example1 = ["Excavadora CAT 320", "Excavadora hidráulica en excelente estado", "50000", "2020", "Buenos Aires", "1", "available", "both", "https://imagen1.jpg,https://imagen2.jpg"].join(",");
    const example2 = ["Tractor John Deere 6110J", "Tractor agrícola con 1000 horas de uso", "75000", "2021", "Córdoba", "2", "available", "b2b", "https://imagen3.jpg"].join(",");
    const instructions = `# Instrucciones para importar maquinaria:\n
# 1. No modifique la primera línea (encabezados)\n
# 2. Cada línea siguiente representa una máquina\n
# 3. Estados permitidos: available (disponible), reserved (reservado), sold (vendido)\n
# 4. Tipos permitidos: b2b (empresa), b2c (particular), both (ambos)\n
# 5. Precios: usar números sin símbolos ni separadores de miles\n
# 6. Imágenes: URLs separadas por comas (opcional)\n
# 7. Para categorías disponibles, consulte la documentación\n\n`;
    const csvContent = `${instructions}${headers}\n${example1}\n${example2}`;
    const blob = new Blob([csvContent], {
      type: 'text/csv;charset=utf-8;'
    });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'plantilla_maquinaria.csv';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="flex flex-col gap-6 mb-8 animate-fade-in">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="flex flex-col gap-2">
          <h2 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-slate-800 to-slate-600 bg-clip-text text-transparent">
            Panel de Control
          </h2>
          <p className="text-slate-600 text-sm">
            Gestiona tu inventario, leads y métricas en un solo lugar
          </p>
        </div>
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="outline" 
                  onClick={downloadCSVTemplate}
                  className="w-full sm:w-auto bg-lime-600 hover:bg-lime-700 text-white transition-all duration-200 shadow-lg hover:shadow-xl"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Descargar Plantilla
                </Button>
              </TooltipTrigger>
              <TooltipContent className="bg-slate-800 text-white p-2 rounded-lg shadow-xl">
                <div className="flex items-start gap-2">
                  <Info className="h-4 w-4 mt-0.5 text-lime-400" />
                  <p className="text-sm">Descarga la plantilla CSV para importar tu inventario</p>
                </div>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>

          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="outline" 
                  onClick={onImportClick}
                  className="w-full sm:w-auto bg-slate-800 hover:bg-slate-900 text-white transition-all duration-200 shadow-lg hover:shadow-xl"
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Importar Inventario
                </Button>
              </TooltipTrigger>
              <TooltipContent className="bg-slate-800 text-white p-2 rounded-lg shadow-xl">
                <div className="flex items-start gap-2">
                  <Info className="h-4 w-4 mt-0.5 text-lime-400" />
                  <p className="text-sm">Sube tu archivo CSV para importar maquinaria</p>
                </div>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
      </div>
    </div>
  );
}
