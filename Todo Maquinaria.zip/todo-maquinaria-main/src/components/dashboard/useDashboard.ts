
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/lib/supabase";
import type { DbMachinery } from "@/types/machinery";

export function useDashboard() {
  const navigate = useNavigate();
  const [machinery, setMachinery] = useState<DbMachinery[]>([]);
  const [filteredMachinery, setFilteredMachinery] = useState<DbMachinery[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("todos");
  const [stats, setStats] = useState({
    total: 0,
    verified: 0,
    pending: 0
  });

  const fetchMachinery = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user?.id) return;

      const { data, error } = await supabase
        .from('machinery')
        .select(`
          *,
          images:machinery_images(
            id,
            url,
            is_primary,
            created_at,
            metadata
          )
        `)
        .eq('user_id', session.user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching machinery:', error);
        return;
      }

      const machineryWithImages = data?.map(item => ({
        ...item,
        images: item.images || []
      })) || [];

      setMachinery(machineryWithImages);
      setFilteredMachinery(machineryWithImages);
      setStats({
        total: machineryWithImages.length || 0,
        verified: machineryWithImages.filter(m => m.status === 'available').length || 0,
        pending: machineryWithImages.filter(m => m.status === 'reserved').length || 0
      });
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const checkAuth = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        navigate('/login');
      }
    };

    checkAuth();
  }, [navigate]);

  useEffect(() => {
    fetchMachinery();
  }, []);

  useEffect(() => {
    let filtered = [...machinery];

    if (statusFilter !== "todos") {
      filtered = filtered.filter(item => item.status === statusFilter);
    }

    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase();
      filtered = filtered.filter(item =>
        item.name.toLowerCase().includes(searchLower) ||
        item.description?.toLowerCase().includes(searchLower) ||
        item.location?.toLowerCase().includes(searchLower)
      );
    }

    setFilteredMachinery(filtered);
  }, [searchTerm, statusFilter, machinery]);

  return {
    loading,
    machinery: filteredMachinery,
    searchTerm,
    statusFilter,
    stats,
    setSearchTerm,
    setStatusFilter,
    fetchMachinery
  };
}
