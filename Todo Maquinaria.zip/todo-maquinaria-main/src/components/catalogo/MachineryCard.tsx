
import { Card, CardContent } from "@/components/ui/card";
import { Calendar, MapPin, Tag, Store, Settings } from "lucide-react";
import type { DbMachinery } from "@/types/machinery";
import { Link, useNavigate } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";

interface MachineryCardProps {
  machine: DbMachinery & {
    category: { name: string } | null;
    images: { url: string; is_primary: boolean }[];
  };
}

export function MachineryCard({ machine }: MachineryCardProps) {
  const navigate = useNavigate();
  const [isOwner, setIsOwner] = useState(false);

  useEffect(() => {
    const checkOwnership = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      setIsOwner(session?.user?.id === machine.user_id);
    };
    checkOwnership();
  }, [machine.user_id]);

  return (
    <Link to={`/maquinaria/${machine.id}`}>
      <Card className="group overflow-hidden bg-white hover:shadow-lg transition-all duration-300 relative">
        {isOwner && (
          <div className="absolute top-2 right-2 z-10 flex gap-2">
            <Button
              variant="outline"
              size="sm"
              className="bg-white/90 backdrop-blur-sm hover:bg-white"
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                navigate(`/maquinaria/${machine.id}/editar`);
              }}
            >
              <Settings className="h-4 w-4 mr-2" />
              Editar
            </Button>
          </div>
        )}
        <CardContent className="p-0">
          <div className="aspect-video relative bg-gray-100 overflow-hidden">
            {machine.images?.some(img => img.is_primary) ? (
              <img
                src={machine.images.find(img => img.is_primary)?.url}
                alt={machine.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-gray-500">
                Sin imagen
              </div>
            )}
            {machine.category && (
              <Badge className="absolute top-2 left-2 bg-white/90 text-gray-900">
                <Store className="w-3 h-3 mr-1" />
                {machine.category.name}
              </Badge>
            )}
          </div>
          <div className="p-4 space-y-3">
            <h3 className="font-semibold text-lg truncate text-gray-900">
              {machine.name}
            </h3>
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Calendar className="h-4 w-4" />
                <span>Año: {machine.year || 'No especificado'}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <MapPin className="h-4 w-4" />
                <span>{machine.location || 'Ubicación no especificada'}</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Tag className="h-4 w-4 text-lime-600" />
                <span className="font-semibold text-lg text-lime-600">
                  {machine.price
                    ? new Intl.NumberFormat('es-AR', {
                        style: 'currency',
                        currency: 'ARS'
                      }).format(machine.price)
                    : 'Precio a consultar'}
                </span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
