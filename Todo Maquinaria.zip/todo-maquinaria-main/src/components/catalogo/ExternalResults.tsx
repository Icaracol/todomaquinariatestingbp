
import { Card, CardContent } from "@/components/ui/card";
import { Calendar, MapPin, ExternalLink } from "lucide-react";
import { useState, useEffect } from "react";
import { supabase } from "@/lib/supabase";
import { useToast } from "@/hooks/use-toast";

interface ExternalResult {
  title: string;
  price: string;
  url: string;
  source: string;
  image?: string;
  location?: string;
}

interface ExternalResultsProps {
  searchTerm: string;
}

export function ExternalResults({ searchTerm }: ExternalResultsProps) {
  const [results, setResults] = useState<ExternalResult[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const searchExternal = async () => {
      if (!searchTerm) return;
      
      setIsLoading(true);
      try {
        const { data, error } = await supabase.functions.invoke('search-machinery', {
          body: { query: searchTerm }
        });

        if (error) throw error;
        setResults(data.results);
      } catch (error) {
        console.error('Error searching external sources:', error);
        toast({
          title: "Error",
          description: "No se pudieron cargar los resultados externos.",
          variant: "destructive"
        });
      } finally {
        setIsLoading(false);
      }
    };

    if (searchTerm) {
      searchExternal();
    }
  }, [searchTerm]);

  if (!searchTerm) return null;

  if (isLoading) {
    return <div className="text-white text-center py-4">Buscando en fuentes externas...</div>;
  }

  if (!results.length) {
    return <div className="text-white text-center py-4">No se encontraron resultados externos</div>;
  }

  return (
    <div className="space-y-4">
      <h3 className="text-xl font-semibold text-white mb-4">Resultados de otras fuentes</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {results.map((result, index) => (
          <a 
            key={index} 
            href={result.url} 
            target="_blank" 
            rel="noopener noreferrer"
            className="block hover:scale-[1.02] transition-transform"
          >
            <Card className="bg-white h-full">
              <CardContent className="p-4">
                <div className="aspect-video relative bg-gray-100 mb-4">
                  {result.image ? (
                    <img
                      src={result.image}
                      alt={result.title}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-gray-400">
                      Sin imagen
                    </div>
                  )}
                </div>
                <div className="space-y-2">
                  <h4 className="font-semibold text-gray-900 line-clamp-2">
                    {result.title}
                  </h4>
                  {result.location && (
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <MapPin className="h-4 w-4" />
                      <span>{result.location}</span>
                    </div>
                  )}
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-gray-900">
                      {result.price}
                    </span>
                    <span className="text-sm text-gray-500 flex items-center gap-1">
                      {result.source} <ExternalLink className="h-4 w-4" />
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </a>
        ))}
      </div>
    </div>
  );
}
