
import type { DbMachinery } from "@/types/machinery";
import { MachineryCard } from "./MachineryCard";
import { Store } from "lucide-react";

interface MachineryGridProps {
  machinery: (DbMachinery & {
    category: { name: string } | null;
    images: { url: string; is_primary: boolean }[];
  })[] | null;
  isLoading: boolean;
}

export function MachineryGrid({ machinery, isLoading }: MachineryGridProps) {
  if (isLoading) {
    return (
      <div className="text-center py-12">
        <div className="animate-pulse flex flex-col items-center gap-4">
          <Store className="h-12 w-12 text-muted-foreground" />
          <p className="text-lg text-muted-foreground">Cargando maquinaria...</p>
        </div>
      </div>
    );
  }

  if (!machinery?.length) {
    return (
      <div className="text-center py-12">
        <Store className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
        <p className="text-lg text-muted-foreground">
          No se encontraron resultados para tu búsqueda
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {machinery.map((machine) => (
        <MachineryCard key={machine.id} machine={machine} />
      ))}
    </div>
  );
}
