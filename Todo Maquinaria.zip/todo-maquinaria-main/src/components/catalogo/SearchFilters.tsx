
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Filter } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";

interface SearchFiltersProps {
  searchTerm: string;
  setSearchTerm: (value: string) => void;
  selectedCategory: string;
  setSelectedCategory: (value: string) => void;
  location: string;
  setLocation: (value: string) => void;
  priceRange: number[];
  setPriceRange: (value: number[]) => void;
  yearRange: number[];
  setYearRange: (value: number[]) => void;
  categories: { id: string; name: string }[] | null;
  onSubmit: (e: React.FormEvent) => void;
}

export function SearchFilters({
  searchTerm,
  setSearchTerm,
  selectedCategory,
  setSelectedCategory,
  location,
  setLocation,
  priceRange,
  setPriceRange,
  yearRange,
  setYearRange,
  categories,
  onSubmit,
}: SearchFiltersProps) {
  return (
    <Card className="bg-white">
      <CardContent className="p-4">
        <h2 className="text-lg font-semibold mb-4 flex items-center gap-2 text-gray-900">
          <Filter className="h-5 w-5" />
          Filtros
        </h2>

        <div className="space-y-6">
          <form onSubmit={onSubmit} className="space-y-4">
            <Input
              type="text"
              placeholder="Buscar maquinaria..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-white text-gray-900 border-gray-300"
            />
          </form>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">
              Categoría
            </label>
            <Select
              value={selectedCategory}
              onValueChange={setSelectedCategory}
            >
              <SelectTrigger className="bg-white text-gray-900 border-gray-300">
                <SelectValue placeholder="Todas las categorías" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas las categorías</SelectItem>
                {categories?.map((category) => (
                  <SelectItem key={category.id} value={category.id}>
                    {category.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">
              Ubicación
            </label>
            <Input
              type="text"
              placeholder="Filtrar por ubicación..."
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="bg-white text-gray-900 border-gray-300"
            />
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">
              Rango de precio
            </label>
            <Slider
              min={0}
              max={1000000}
              step={10000}
              value={priceRange}
              onValueChange={setPriceRange}
              className="mt-2"
            />
            <div className="flex justify-between mt-2 text-sm text-gray-600">
              <span>${priceRange[0].toLocaleString()}</span>
              <span>${priceRange[1].toLocaleString()}</span>
            </div>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">
              Año
            </label>
            <Slider
              min={1970}
              max={2024}
              step={1}
              value={yearRange}
              onValueChange={setYearRange}
              className="mt-2"
            />
            <div className="flex justify-between mt-2 text-sm text-gray-600">
              <span>{yearRange[0]}</span>
              <span>{yearRange[1]}</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
