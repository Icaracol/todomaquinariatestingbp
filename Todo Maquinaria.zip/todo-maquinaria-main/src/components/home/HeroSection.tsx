
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useState } from "react";

export function HeroSection() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    navigate(`/catalogo?q=${encodeURIComponent(searchTerm)}`);
  };

  return (
    <div className="relative">
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 to-[#111A23]" />
      <div className="container mx-auto px-4 py-32 relative">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <h1 className="text-6xl font-extrabold text-lime-100">
            Encuentra la maquinaria perfecta para tu negocio
          </h1>
          <p className="text-xl text-gray-300">
            Explora miles de opciones de maquinaria industrial verificada por expertos
          </p>
          
          <form onSubmit={handleSearch} className="flex gap-2 max-w-2xl mx-auto">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <Input
                type="text"
                placeholder="Buscar por tipo de maquinaria, marca o modelo..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 h-12 bg-white/10 border-white/20 text-white placeholder:text-gray-400"
              />
            </div>
            <Button type="submit" variant="primary" size="lg">
              Buscar
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
