
import { Globe, ShieldCheck, Truck } from "lucide-react";

export function FeaturesSection() {
  return (
    <div className="container mx-auto px-4 py-24">
      <div className="grid md:grid-cols-3 gap-8">
        <div className="bg-white/5 p-6 rounded-lg space-y-4">
          <ShieldCheck className="w-12 h-12 text-[#A9F00F]" />
          <h3 className="text-xl font-semibold text-white">Maquinaria Verificada</h3>
          <p className="text-gray-400">
            Todos los equipos son verificados por nuestro equipo de expertos antes de su publicación.
          </p>
        </div>
        
        <div className="bg-white/5 p-6 rounded-lg space-y-4">
          <Truck className="w-12 h-12 text-[#A9F00F]" />
          <h3 className="text-xl font-semibold text-white">
            Envíos Seguros
          </h3>
          <p className="text-gray-400">
            Coordinamos el transporte de tu maquinaria con empresas especializadas y confiables.
          </p>
        </div>
        
        <div className="bg-white/5 p-6 rounded-lg space-y-4">
          <Globe className="w-12 h-12 text-[#A9F00F]" />
          <h3 className="text-xl font-semibold text-white">
            Alcance Nacional
          </h3>
          <p className="text-gray-400">
            Conectamos compradores y vendedores de todo el país en un solo lugar.
          </p>
        </div>
      </div>
    </div>
  );
}
