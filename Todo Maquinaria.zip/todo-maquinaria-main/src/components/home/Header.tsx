import { Button } from "@/components/ui/button";
import { User, Truck, Bell, LogOut } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { Session } from "@supabase/supabase-js";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/lib/supabase";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
interface HeaderProps {
  session: Session | null;
}
export function Header({
  session
}: HeaderProps) {
  const navigate = useNavigate();
  const {
    toast
  } = useToast();
  const handleLogout = async () => {
    try {
      const {
        error
      } = await supabase.auth.signOut();
      if (error) throw error;
      toast({
        title: "Sesión cerrada",
        description: "Has cerrado sesión correctamente"
      });
      navigate("/");
    } catch (error) {
      console.error("Error al cerrar sesión:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "No se pudo cerrar la sesión. Por favor intenta nuevamente."
      });
    }
  };
  return <div className="w-full border-b border-white/10">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center">
            <img src="/lovable-uploads/b02b5c24-c115-4b33-8a03-f1aeefad99ab.png" alt="Logo" className="h-8 w-auto" />
          </Link>
          <div className="flex items-center gap-4">
            {session ? <>
                <Link to="/subir-inventario">
                  <Button variant="primary">
                    Publicar mi inventario
                  </Button>
                </Link>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" className="gap-2">
                      <User className="h-4 w-4" />
                      Mi Cuenta
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56 bg-lime-50">
                    <DropdownMenuLabel>Mi Cuenta</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => navigate('/dashboard')}>
                      <User className="mr-2 h-4 w-4" />
                      Dashboard
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate('/mis-maquinas')}>
                      <Truck className="mr-2 h-4 w-4" />
                      Mis Máquinas
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate('/notificaciones')}>
                      <Bell className="mr-2 h-4 w-4" />
                      Notificaciones
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleLogout}>
                      <LogOut className="mr-2 h-4 w-4" />
                      Cerrar Sesión
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </> : <>
                <Link to="/subir-inventario">
                  <Button variant="primary">
                    Publicar mi inventario
                  </Button>
                </Link>
                <Link to="/login">
                  <Button variant="outline">
                    Iniciar Sesión
                  </Button>
                </Link>
              </>}
          </div>
        </div>
      </div>
    </div>;
}