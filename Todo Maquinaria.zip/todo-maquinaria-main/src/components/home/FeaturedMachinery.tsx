
import { Card, CardContent } from "@/components/ui/card";
import { Calendar, MapPin, Tag } from "lucide-react";
import { Link } from "react-router-dom";
import type { DbMachinery } from "@/types/machinery";

interface FeaturedMachineryProps {
  machinery: (DbMachinery & {
    category: {
      name: string;
    } | null;
    images: {
      url: string;
      is_primary: boolean;
    }[];
  })[] | undefined;
}

export function FeaturedMachinery({
  machinery
}: FeaturedMachineryProps) {
  return (
    <div className="container mx-auto px-4 py-16">
      <h2 className="text-2xl font-bold text-white mb-8">Maquinaria Destacada</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {machinery?.map(machine => (
          <Link key={machine.id} to={`/maquinaria/${machine.id}`}>
            <Card className="hover:scale-[1.02] transition-transform">
              <CardContent className="p-0">
                <div className="aspect-video relative bg-muted">
                  {machine.images?.some(img => img.is_primary) ? (
                    <img
                      src={machine.images.find(img => img.is_primary)?.url}
                      alt={machine.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                      Sin imagen
                    </div>
                  )}
                </div>
                <div className="p-4 space-y-2 bg-slate-950 hover:bg-slate-800">
                  <h3 className="text-lg truncate font-semibold text-lime-200">{machine.name}</h3>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Calendar className="h-4 w-4 bg-transparent" />
                    <span className="text-zinc-50">Año: {machine.year || 'No especificado'}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <MapPin className="h-4 w-4 bg-transparent rounded-none" />
                    <span className="text-zinc-50">{machine.location || 'Ubicación no especificada'}</span>
                  </div>
                  <div className="pt-2">
                    <span className="font-semibold text-lg text-lime-400">
                      {machine.price
                        ? new Intl.NumberFormat('es-AR', {
                            style: 'currency',
                            currency: 'ARS'
                          }).format(machine.price)
                        : 'Precio a consultar'}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}
