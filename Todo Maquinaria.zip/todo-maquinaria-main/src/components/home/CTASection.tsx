
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

export function CTASection() {
  return (
    <div className="container mx-auto px-4 py-24">
      <div className="bg-gradient-to-r from-[#1E2A35] to-[#2A3744] rounded-2xl p-12">
        <div className="max-w-3xl mx-auto text-center space-y-8">
          <h2 className="text-4xl font-bold text-white">
            ¿Tienes maquinaria para vender?
          </h2>
          <p className="text-xl text-gray-300">
            Únete a la plataforma líder en compra-venta de maquinaria industrial en Argentina.
          </p>
          <Button size="xl" variant="primary" className="shadow-xl" asChild>
            <Link to="/register">
              Comienza a vender - ¡Es gratis!
            </Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
