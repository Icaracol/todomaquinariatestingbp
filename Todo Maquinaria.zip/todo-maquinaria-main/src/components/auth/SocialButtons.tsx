
import { Button } from "@/components/ui/button";
import { FcGoogle } from "react-icons/fc";
import { BsApple } from "react-icons/bs";

interface SocialButtonsProps {
  isRegister?: boolean;
  loading?: boolean;
  onGoogleClick: () => Promise<void>;
  onAppleClick: () => Promise<void>;
}

export function SocialButtons({ isRegister, loading, onGoogleClick, onAppleClick }: SocialButtonsProps) {
  return (
    <>
      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <span className="w-full border-t" />
        </div>
        <div className="relative flex justify-center text-xs uppercase">
          <span className="bg-background px-2 text-muted-foreground">
            O continuar con
          </span>
        </div>
      </div>

      <Button variant="outline" className="w-full mt-3" onClick={onGoogleClick} disabled={loading}>
        <FcGoogle className="mr-2 h-4 w-4" />
        {isRegister ? "Registrarse con Google" : "Continuar con Google"}
      </Button>
      <Button variant="outline" className="w-full mt-3" onClick={onAppleClick} disabled={loading}>
        <BsApple className="mr-2 h-4 w-4" />
        {isRegister ? "Registrarse con Apple" : "Continuar con Apple"}
      </Button>
    </>
  );
}
