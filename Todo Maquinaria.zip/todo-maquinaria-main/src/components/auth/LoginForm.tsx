import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { loginSchema, type LoginForm as LoginFormType } from "@/lib/validations/auth";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
interface LoginFormProps {
  onSubmit: (data: LoginFormType) => Promise<void>;
  loading: boolean;
}
export function LoginForm({
  onSubmit,
  loading
}: LoginFormProps) {
  const form = useForm<LoginFormType>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: ""
    }
  });
  return <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 p-6 rounded-lg shadow bg-lime-100">
        <FormField control={form.control} name="email" render={({
        field
      }) => <FormItem>
              <FormLabel>Correo electrónico</FormLabel>
              <FormControl>
                <Input type="email" placeholder="tu@empresa.com" disabled={loading} className="bg-white text-gray-900" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>} />
        <FormField control={form.control} name="password" render={({
        field
      }) => <FormItem>
              <FormLabel>Contraseña</FormLabel>
              <FormControl>
                <Input type="password" placeholder="••••••••" disabled={loading} className="bg-white text-gray-900" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>} />
        <Button type="submit" disabled={loading} className="w-full text-slate-900 bg-lime-500 hover:bg-lime-400">
          {loading ? "Iniciando sesión..." : "Iniciar sesión"}
        </Button>
      </form>
    </Form>;
}