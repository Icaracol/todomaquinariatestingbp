import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { basicRegisterSchema, type BasicRegisterForm } from "@/lib/validations/auth";
import { useToast } from "@/components/ui/use-toast";
import { Link } from "react-router-dom";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
interface RegisterFormProps {
  onSubmit: (data: BasicRegisterForm) => Promise<void>;
  loading: boolean;
}
export function RegisterForm({
  onSubmit,
  loading
}: RegisterFormProps) {
  const {
    toast
  } = useToast();
  const form = useForm<BasicRegisterForm>({
    resolver: zodResolver(basicRegisterSchema),
    defaultValues: {
      email: "",
      password: ""
    }
  });
  const handleSubmit = async (data: BasicRegisterForm) => {
    try {
      await onSubmit(data);
    } catch (error: any) {
      // Check for specific error messages from Supabase
      if (error.message?.includes('User already registered')) {
        toast({
          variant: "destructive",
          title: "Cuenta existente",
          description: "Ya existe una cuenta con este correo electrónico. Por favor inicia sesión."
        });
        return;
      }
      toast({
        variant: "destructive",
        title: "Error al registrar",
        description: "Ocurrió un error durante el registro. Por favor intenta nuevamente."
      });
    }
  };
  return <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4 p-6 rounded-lg shadow bg-lime-200">
        <FormField control={form.control} name="email" render={({
        field
      }) => <FormItem className="bg-lime-50">
              <FormLabel className="bg-transparent">Correo electrónico</FormLabel>
              <FormControl>
                <Input type="email" placeholder="tu@empresa.com" disabled={loading} className="bg-white text-gray-900" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>} />
        <FormField control={form.control} name="password" render={({
        field
      }) => <FormItem className="bg-lime-50">
              <FormLabel>Contraseña</FormLabel>
              <FormControl>
                <Input type="password" placeholder="••••••••" disabled={loading} className="bg-white text-gray-900" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>} />
        <Button type="submit" disabled={loading} className="w-full bg-lime-600 hover:bg-lime-500">
          {loading ? "Registrando..." : "Crear cuenta"}
        </Button>
        
        <div className="text-center mt-4">
          <p className="text-sm text-slate-800">
            ¿Ya tienes una cuenta?{" "}
            <Link to="/login" className="text-primary hover:underline">
              Inicia sesión
            </Link>
          </p>
        </div>
      </form>
    </Form>;
}