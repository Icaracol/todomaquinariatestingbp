import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LoginForm } from "./LoginForm";
import { RegisterForm } from "./RegisterForm";
import { supabase } from "@/lib/supabase";
import { useToast } from "@/hooks/use-toast";
import { SocialButtons } from "./SocialButtons";
interface AuthFormProps {
  isRegister?: boolean;
}
export function AuthForm({
  isRegister = false
}: AuthFormProps) {
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const {
    toast
  } = useToast();
  const returnTo = location.state?.returnTo || "/";
  const message = location.state?.message;
  const handleLogin = async (data: {
    email: string;
    password: string;
  }) => {
    try {
      setLoading(true);
      const {
        error
      } = await supabase.auth.signInWithPassword(data);
      if (error) throw error;
      toast({
        title: "¡Bienvenido de vuelta!",
        description: "Has iniciado sesión correctamente"
      });
      navigate(returnTo);
    } catch (error) {
      console.error("Error:", error);
      toast({
        title: "Error al iniciar sesión",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };
  const handleRegister = async (data: {
    email: string;
    password: string;
  }) => {
    try {
      setLoading(true);
      const {
        error
      } = await supabase.auth.signUp(data);
      if (error) throw error;
      toast({
        title: "¡Registro exitoso!",
        description: "Por favor verifica tu correo electrónico para continuar"
      });
    } catch (error) {
      console.error("Error:", error);
      toast({
        title: "Error al registrarse",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };
  return <Card>
      <CardHeader className="space-y-1 bg-slate-900 hover:bg-slate-800">
        <CardTitle className="text-lime-400 text-lg">¡Le damos la bienvenida a Todo Maquinaria!</CardTitle>
        <CardDescription className="text-lime-50">
          {message || "Inicia sesión o crea una cuenta para continuar"}
        </CardDescription>
      </CardHeader>
      <CardContent className="p-6 bg-slate-900 ">
        <Tabs defaultValue={isRegister ? "register" : "login"} className="space-y-4">
          <TabsList className="grid w-full grid-cols-2 bg-lime-300 hover:bg-lime-200">
            <TabsTrigger value="login" className="bg-lime-300 hover:bg-lime-50 text-slate-800">Iniciar Sesión</TabsTrigger>
            <TabsTrigger value="register" className="bg-lime-300 hover:bg-lime-50 text-slate-800">Registrarse</TabsTrigger>
          </TabsList>
          <TabsContent value="login">
            <LoginForm onSubmit={handleLogin} loading={loading} />
          </TabsContent>
          <TabsContent value="register">
            <RegisterForm onSubmit={handleRegister} loading={loading} />
          </TabsContent>
        </Tabs>

        <div className="mt-6">
          <SocialButtons isRegister={isRegister} onGoogleClick={async () => {}} onAppleClick={async () => {}} loading={loading} />
        </div>
      </CardContent>
    </Card>;
}