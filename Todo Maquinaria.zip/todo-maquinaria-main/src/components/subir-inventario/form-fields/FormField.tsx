
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import React from "react";

interface FormFieldProps {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  type?: string;
  min?: string;
  max?: string;
  required?: boolean;
  icon?: () => React.ReactNode;
}

export function FormField({
  id,
  label,
  value,
  onChange,
  placeholder,
  type = "text",
  min,
  max,
  required = false,
  icon
}: FormFieldProps) {
  return (
    <div className="space-y-2">
      <Label htmlFor={id} className="block text-sm font-medium text-gray-700">
        {label}
        {required && <span className="text-red-500 ml-1">*</span>}
      </Label>
      <div className="relative">
        <Input
          id={id}
          type={type}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          min={min}
          max={max}
          required={required}
          className={icon ? "pr-12" : ""}
        />
        {icon && (
          <div className="absolute inset-y-0 right-0 flex items-center px-3 pointer-events-none text-gray-500 font-medium">
            {icon()}
          </div>
        )}
      </div>
    </div>
  );
}
