
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Loader2, Wand2, FileText, Bookmark, Search } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useMachineryAI } from "@/hooks/use-machinery-ai";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

interface DescriptionFieldProps {
  value: string;
  onChange: (value: string) => void;
  machineData: {
    name: string;
    category_id: string;
    year: string;
    specifications: Record<string, string>;
  };
  categories: Array<{ id: string; name: string }>;
}

export function DescriptionField({ 
  value, 
  onChange, 
  machineData,
  categories 
}: DescriptionFieldProps) {
  const [isGenerating, setIsGenerating] = useState(false);
  const { toast } = useToast();
  const { generateDescription } = useMachineryAI();
  const [selectedDescriptionType, setSelectedDescriptionType] = useState<"commercial" | "technical" | "seo">("commercial");

  const handleGenerateDescription = async () => {
    if (!machineData.name) {
      toast({
        title: "Información incompleta",
        description: "Por favor, completa al menos el nombre de la máquina.",
        variant: "destructive"
      });
      return;
    }

    setIsGenerating(true);
    try {
      const selectedCategory = categories.find(c => c.id === machineData.category_id);
      
      const generatedDescription = await generateDescription(
        machineData.name,
        selectedCategory?.name,
        machineData.year,
        machineData.specifications,
        selectedDescriptionType
      );
      
      if (generatedDescription) {
        onChange(generatedDescription);
        
        toast({
          title: "Descripción generada",
          description: `Se ha generado una descripción ${
            selectedDescriptionType === "technical" ? "técnica" : 
            selectedDescriptionType === "commercial" ? "comercial" : 
            "optimizada para SEO"
          }.`
        });
      }
    } catch (error) {
      console.error('Error generating description:', error);
      toast({
        title: "Error",
        description: "No se pudo generar la descripción. Por favor intenta nuevamente.",
        variant: "destructive"
      });
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-1">
        <Label htmlFor="description" className="block text-sm font-medium text-gray-700">
          Descripción
        </Label>
        <div className="flex gap-2">
          <RadioGroup 
            value={selectedDescriptionType} 
            onValueChange={(value) => setSelectedDescriptionType(value as "commercial" | "technical" | "seo")}
            className="flex items-center bg-gray-100 p-1 rounded-md"
          >
            <div className={`p-1 ${selectedDescriptionType === "commercial" ? "bg-white shadow rounded" : ""}`}>
              <div className="flex items-center space-x-1">
                <RadioGroupItem value="commercial" id="commercial" className="sr-only" />
                <label htmlFor="commercial" className="text-xs cursor-pointer flex items-center gap-1">
                  <Bookmark className="h-3 w-3" />
                  <span>Comercial</span>
                </label>
              </div>
            </div>
            <div className={`p-1 ${selectedDescriptionType === "technical" ? "bg-white shadow rounded" : ""}`}>
              <div className="flex items-center space-x-1">
                <RadioGroupItem value="technical" id="technical" className="sr-only" />
                <label htmlFor="technical" className="text-xs cursor-pointer flex items-center gap-1">
                  <FileText className="h-3 w-3" />
                  <span>Técnica</span>
                </label>
              </div>
            </div>
            <div className={`p-1 ${selectedDescriptionType === "seo" ? "bg-white shadow rounded" : ""}`}>
              <div className="flex items-center space-x-1">
                <RadioGroupItem value="seo" id="seo" className="sr-only" />
                <label htmlFor="seo" className="text-xs cursor-pointer flex items-center gap-1">
                  <Search className="h-3 w-3" />
                  <span>SEO</span>
                </label>
              </div>
            </div>
          </RadioGroup>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={handleGenerateDescription}
            disabled={isGenerating}
            className="flex items-center gap-2"
          >
            {isGenerating ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Wand2 className="h-4 w-4" />
            )}
            Generar descripción
          </Button>
        </div>
      </div>
      <Textarea
        id="description"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={
          selectedDescriptionType === "commercial" 
            ? "Describe las características principales de la máquina para atraer compradores" 
            : selectedDescriptionType === "technical"
            ? "Detalla las especificaciones técnicas, rendimiento y capacidades de la máquina"
            : "Describe la máquina incluyendo palabras clave relevantes para mejor visibilidad"
        }
        className="h-32"
        required
      />
      <div className="mt-1 text-xs text-gray-500">
        {selectedDescriptionType === "commercial" && 
          "Enfocada en beneficios y ventajas comerciales para atraer compradores"}
        {selectedDescriptionType === "technical" && 
          "Enfocada en especificaciones técnicas y características de rendimiento"}
        {selectedDescriptionType === "seo" && 
          "Optimizada para motores de búsqueda con palabras clave relevantes"}
      </div>
    </div>
  );
}
