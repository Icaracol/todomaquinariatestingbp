
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";

interface CategorySelectorProps {
  value: string;
  onChange: (value: string) => void;
  categories: Array<{ id: string; name: string }>;
  isLoading: boolean;
}

export function CategorySelector({ 
  value, 
  onChange, 
  categories, 
  isLoading 
}: CategorySelectorProps) {
  return (
    <div>
      <Label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">
        Categoría
      </Label>
      <Select
        value={value}
        onValueChange={(value) => onChange(value)}
      >
        <SelectTrigger>
          <SelectValue placeholder="Selecciona una categoría" />
        </SelectTrigger>
        <SelectContent>
          {isLoading ? (
            <SelectItem value="loading" disabled>
              Cargando categorías...
            </SelectItem>
          ) : (
            categories.map((category) => (
              <SelectItem key={category.id} value={category.id}>
                {category.name}
              </SelectItem>
            ))
          )}
        </SelectContent>
      </Select>
    </div>
  );
}
