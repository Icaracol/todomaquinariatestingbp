
import React from "react";
import { ProgressBar } from "../pasos/ProgressBar";
import { StepContentContainer } from "./StepContentContainer";
import { StepNavigation } from "./StepNavigation";
import { StepRenderer } from "./StepRenderer";
import { CategoryItem, FormDataType } from "../types";

interface InventoryStepContentProps {
  activeStep: number;
  totalSteps: number;
  formData: FormDataType;
  onChange: (name: string, value: string) => void;
  categories: CategoryItem[];
  selectedMainCategory: string | null;
  hasSubcategories: boolean;
  errors: Record<string, string>;
  clearError: (field: string) => void;
  getSelectedCategoryName: () => string;
  getSelectedMainCategoryName: () => string;
  handleMainCategorySelect: (id: string) => void;
  goToPreviousStep: () => void;
  handleNextStep: () => void;
}

export function InventoryStepContent({
  activeStep,
  totalSteps,
  formData,
  onChange,
  categories,
  selectedMainCategory,
  hasSubcategories,
  errors,
  clearError,
  getSelectedCategoryName,
  getSelectedMainCategoryName,
  handleMainCategorySelect,
  goToPreviousStep,
  handleNextStep
}: InventoryStepContentProps) {
  return (
    <div className="space-y-6">
      <ProgressBar activeStep={activeStep} totalSteps={totalSteps} />
      
      <StepContentContainer>
        <StepRenderer
          activeStep={activeStep}
          formData={formData}
          onChange={onChange}
          categories={categories}
          selectedMainCategory={selectedMainCategory}
          hasSubcategories={hasSubcategories}
          errors={errors}
          clearError={clearError}
          getSelectedCategoryName={getSelectedCategoryName}
          getSelectedMainCategoryName={getSelectedMainCategoryName}
          handleMainCategorySelect={handleMainCategorySelect}
        />
        
        <StepNavigation
          activeStep={activeStep}
          goToPreviousStep={goToPreviousStep}
          handleNextStep={handleNextStep}
          hasSubcategories={hasSubcategories}
        />
      </StepContentContainer>
    </div>
  );
}
