
import React from "react";
import { Button } from "@/components/ui/button";
import { FormField } from "../../form-fields/FormField";
import { MapPin } from "lucide-react";

interface LocationInputProps {
  location: string;
  onChangeLocation: (value: string) => void;
}

export function LocationInput({ location, onChangeLocation }: LocationInputProps) {
  const setDefaultLocation = () => {
    onChangeLocation("Buenos Aires, Argentina");
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-2">
        <h4 className="text-base font-medium text-gray-700">¿Dónde se encuentra la máquina?</h4>
      </div>
      <div className="flex items-center gap-2">
        <div className="flex-1">
          <FormField
            id="location"
            label=""
            value={location}
            onChange={onChangeLocation}
            placeholder="Ej: Buenos Aires, Argentina"
          />
        </div>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={setDefaultLocation}
          className="flex items-center gap-1"
        >
          <MapPin className="h-4 w-4" />
          <span className="hidden md:inline">Buenos Aires</span>
        </Button>
      </div>
    </div>
  );
}
