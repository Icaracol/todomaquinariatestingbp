
import React from "react";
import { Button } from "@/components/ui/button";
import { FormField } from "../../form-fields/FormField";
import { CalendarIcon } from "lucide-react";

interface YearInputProps {
  year: string;
  onChangeYear: (value: string) => void;
  yearError?: string;
  onClearYearError?: () => void;
}

export function YearInput({
  year,
  onChangeYear,
  yearError,
  onClearYearError
}: YearInputProps) {
  const handleYearChange = (value: string) => {
    onChangeYear(value);
    if (yearError && onClearYearError) {
      onClearYearError();
    }
  };

  const setCurrentYear = () => {
    onChangeYear(new Date().getFullYear().toString());
  };

  return (
    <div>
      <h4 className="text-base font-medium text-gray-700 mb-2">¿Cuál es el año de fabricación?</h4>
      <div className="flex items-center gap-2">
        <div className="flex-1">
          <FormField
            id="year"
            label=""
            value={year}
            onChange={handleYearChange}
            placeholder="Ej: 2020"
            type="number"
            min="1900"
            max={new Date().getFullYear().toString()}
          />
        </div>
        <Button
          type="button"
          variant="outline"
          size="sm"
          className="flex items-center"
          onClick={setCurrentYear}
        >
          <CalendarIcon className="h-4 w-4 mr-1" />
          Actual
        </Button>
      </div>
      {yearError && <p className="text-red-500 text-sm mt-1">{yearError}</p>}
    </div>
  );
}
