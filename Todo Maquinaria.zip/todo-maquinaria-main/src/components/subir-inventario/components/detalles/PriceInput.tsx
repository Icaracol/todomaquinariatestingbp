
import React from "react";
import { Button } from "@/components/ui/button";
import { FormField } from "../../form-fields/FormField";
import { Wand2, Loader2, DollarSign, Info } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface PriceInputProps {
  price: string;
  onChangePrice: (value: string) => void;
  priceError?: string;
  onClearPriceError?: () => void;
  suggestion: { price: string; confidence: number; message: string } | null;
  isLoading: boolean;
  onGetSuggestion: () => void;
  onApplySuggestion: () => void;
  productName: string;
}

export function PriceInput({
  price,
  onChangePrice,
  priceError,
  onClearPriceError,
  suggestion,
  isLoading,
  onGetSuggestion,
  onApplySuggestion,
  productName
}: PriceInputProps) {
  const handlePriceChange = (value: string) => {
    onChangePrice(value);
    if (priceError && onClearPriceError) {
      onClearPriceError();
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-2">
        <div className="flex items-center gap-2">
          <h4 className="text-base font-medium text-gray-700">¿A qué precio la quieres vender?</h4>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Info className="h-4 w-4 text-gray-400 cursor-help" />
              </TooltipTrigger>
              <TooltipContent className="max-w-xs">
                <p>Puedes ingresar un precio manualmente o solicitar una sugerencia del asistente IA.</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={onGetSuggestion}
          disabled={isLoading || !productName.trim()}
          className="flex items-center gap-2"
        >
          {isLoading ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Wand2 className="h-4 w-4" />
          )}
          Sugerir precio
        </Button>
      </div>
      
      {suggestion && (
        <Alert className="mb-4 bg-blue-50 border-blue-100">
          <DollarSign className="h-4 w-4 text-blue-600" />
          <AlertDescription className="text-blue-700">
            <div className="flex flex-col space-y-2">
              <div className="flex justify-between items-center">
                <span>{suggestion.message}</span>
                <Button
                  type="button"
                  variant="primary"
                  size="sm"
                  onClick={onApplySuggestion}
                >
                  Aplicar
                </Button>
              </div>
              <p className="text-xs text-blue-600 mt-1">
                Sugerencia basada en análisis de {productName.trim() ? "datos de mercado para " + productName : "maquinaria similar"} 
                {suggestion.confidence > 80 ? " (confianza alta)" : 
                 suggestion.confidence > 50 ? " (confianza media)" : " (confianza baja)"}
              </p>
            </div>
          </AlertDescription>
        </Alert>
      )}
      
      <FormField
        id="price"
        label=""
        value={price}
        onChange={handlePriceChange}
        placeholder="Precio en ARS"
        type="number"
        min="0"
        icon={() => "ARS"}
      />
      {priceError && <p className="text-red-500 text-sm mt-1">{priceError}</p>}
      
      <p className="text-xs text-gray-500 mt-2">
        Nuestro asistente IA analiza miles de anuncios y transacciones recientes para recomendar precios competitivos 
        basados en características similares, año y categoría de la máquina.
      </p>
    </div>
  );
}
