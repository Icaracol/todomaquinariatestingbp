
import React, { ReactNode } from "react";

interface StepContentContainerProps {
  children: ReactNode;
  className?: string;
}

export function StepContentContainer({ children, className = "" }: StepContentContainerProps) {
  return (
    <div className={`bg-white border rounded-lg p-6 shadow-sm ${className}`}>
      {children}
    </div>
  );
}
