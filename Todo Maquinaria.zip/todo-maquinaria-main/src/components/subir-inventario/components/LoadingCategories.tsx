
import React from "react";

export function LoadingCategories() {
  return (
    <div className="text-center py-8">
      <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-4"></div>
      <p className="text-gray-600">Cargando categorías...</p>
      <p className="text-sm text-gray-500 mt-2">Estamos preparando las opciones de categorías para tu maquinaria</p>
    </div>
  );
}
