
import React, { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface StepNavigationProps {
  activeStep: number;
  goToPreviousStep: () => void;
  handleNextStep: () => void;
  hasSubcategories: boolean;
  isLastStep?: boolean;
}

export function StepNavigation({
  activeStep,
  goToPreviousStep,
  handleNextStep,
  hasSubcategories,
  isLastStep = false
}: StepNavigationProps) {
  const { toast } = useToast();
  
  // Debug log when component mounts or activeStep changes
  useEffect(() => {
    console.log("StepNavigation - Current step:", activeStep);
    console.log("StepNavigation - Has subcategories:", hasSubcategories);
  }, [activeStep, hasSubcategories]);

  const handlePreviousClick = () => {
    console.log("StepNavigation - Previous button clicked for step:", activeStep);
    try {
      goToPreviousStep();
    } catch (error) {
      console.error("Error navigating to previous step:", error);
      toast({
        title: "Error al retroceder",
        description: "Hubo un problema al volver al paso anterior.",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="flex justify-between mt-8 pt-4 border-t">
      <Button 
        type="button" 
        variant="outline" 
        onClick={handlePreviousClick} 
        disabled={activeStep === 1} 
        className="flex items-center gap-2 text-slate-50 bg-blue-800 hover:bg-blue-700 disabled:bg-gray-300"
      >
        <ChevronLeft className="h-4 w-4" />
        Anterior
      </Button>
      
      {activeStep < 3 ? (
        <Button 
          type="button" 
          onClick={handleNextStep} 
          className="bg-primary hover:bg-primary/90 flex items-center gap-2"
        >
          Siguiente
          <ChevronRight className="h-4 w-4" />
        </Button>
      ) : (
        <Button 
          type="button" 
          onClick={handleNextStep} 
          className="bg-gradient-to-r from-primary to-blue-600 hover:from-primary/90 hover:to-blue-600/90 flex items-center gap-2"
        >
          <Check className="h-4 w-4" />
          Finalizar
        </Button>
      )}
    </div>
  );
}
