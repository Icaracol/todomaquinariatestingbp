
import React from "react";
import { PasoNombreMaquina } from "../pasos/PasoNombreMaquina";
import { PasoCategoriaPrincipal } from "../pasos/PasoCategoriaPrincipal";
import { PasoSubcategorias } from "../pasos/PasoSubcategorias";
import { PasoBrandSelection } from "../pasos/PasoBrandSelection";
import { PasoDetallesBasicos } from "../pasos/PasoDetallesBasicos";
import { PasoDescripcion } from "../pasos/PasoDescripcion";
import { PasoRevision } from "../pasos/PasoRevision";
import { CategoryItem, FormDataType } from "../types";

interface StepRendererProps {
  activeStep: number;
  formData: FormDataType;
  onChange: (name: string, value: string) => void;
  categories: CategoryItem[];
  selectedMainCategory: string | null;
  hasSubcategories: boolean;
  errors: Record<string, string>;
  clearError: (field: string) => void;
  getSelectedCategoryName: () => string;
  getSelectedMainCategoryName: () => string;
  handleMainCategorySelect: (id: string) => void;
}

export function StepRenderer({
  activeStep,
  formData,
  onChange,
  categories,
  selectedMainCategory,
  hasSubcategories,
  errors,
  clearError,
  getSelectedCategoryName,
  getSelectedMainCategoryName,
  handleMainCategorySelect,
}: StepRendererProps) {
  // Filtrar las subcategorías basadas en la categoría principal seleccionada
  const getSubcategories = () => {
    if (!selectedMainCategory) return [];
    return categories.filter(cat => 
      cat.parent_id === selectedMainCategory && 
      (!cat.type || cat.type === 'category')
    );
  };

  // Dummy onNext function for components that require it but don't need
  // actual navigation (since navigation is handled at a higher level)
  const handleDummyNext = () => {
    console.log("Dummy next function called from step component");
  };

  const renderStep = () => {
    switch (activeStep) {
      case 1:
        // Step 1: Combine machine name and main category selection
        return (
          <div className="space-y-8">
            <PasoNombreMaquina
              name={formData.name}
              onChange={(value) => onChange('name', value)}
              error={errors.name}
              onClearError={() => clearError('name')}
            />
            
            <PasoCategoriaPrincipal
              categories={categories.filter(cat => cat.parent_id === null)}
              selectedCategory={selectedMainCategory}
              onSelectCategory={handleMainCategorySelect}
              productName={formData.name}
              error={errors.category_id}
            />
          </div>
        );
      case 2:
        // Step 2: Combine subcategories and brand selection
        return (
          <div className="space-y-8">
            <PasoSubcategorias
              categories={categories}
              mainCategoryId={selectedMainCategory}
              selectedCategoryId={formData.category_id}
              onSelectCategory={(id) => onChange('category_id', id)}
              mainCategoryName={getSelectedMainCategoryName()}
              hasSubcategories={hasSubcategories}
              error={errors.category_id}
              onClearError={() => clearError('category_id')}
              productName={formData.name}
              subcategories={getSubcategories()}
              onNext={handleDummyNext}
            />
            
            <PasoBrandSelection
              mainCategoryId={selectedMainCategory}
              mainCategoryName={getSelectedMainCategoryName()}
              productName={formData.name}
              selectedBrand={formData.brand || ""}
              onSelectBrand={(value) => onChange('brand', value)}
              onNext={handleDummyNext}
            />
          </div>
        );
      case 3:
        // Step 3: Combine details, description and final review
        return (
          <div className="space-y-8">
            <PasoDetallesBasicos
              categoryName={getSelectedCategoryName()}
              year={formData.year}
              price={formData.price}
              location={formData.location}
              onChangeYear={(value) => onChange('year', value)}
              onChangePrice={(value) => onChange('price', value)}
              onChangeLocation={(value) => onChange('location', value)}
              yearError={errors.year}
              priceError={errors.price}
              onClearYearError={() => clearError('year')}
              onClearPriceError={() => clearError('price')}
              productName={formData.name}
            />
            
            <PasoDescripcion
              description={formData.description}
              onChangeDescription={(value) => onChange('description', value)}
              error={errors.description}
              onClearError={() => clearError('description')}
              categoryName={getSelectedCategoryName()}
              productName={formData.name}
              machineData={{
                name: formData.name,
                category_id: formData.category_id,
                year: formData.year,
                specifications: formData.specifications
              }}
              categories={categories}
            />
            
            <PasoRevision
              name={formData.name}
              categoryName={getSelectedCategoryName()}
              brand={formData.brand}
              year={formData.year}
              price={formData.price}
              location={formData.location}
              description={formData.description}
            />
          </div>
        );
      default:
        return <div>Paso desconocido</div>;
    }
  };

  return renderStep();
}
