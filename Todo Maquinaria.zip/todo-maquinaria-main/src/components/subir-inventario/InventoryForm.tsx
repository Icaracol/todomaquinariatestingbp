
import { useState, useEffect } from "react";
import { InformacionBasica } from "./InformacionBasica";
import { SubirFotos } from "./SubirFotos";
import RegistroFinal from "./RegistroFinal";
import { useInventoryForm } from "@/hooks/use-inventory-form";
import { useQuery } from "@tanstack/react-query";
import { getCategories } from "@/services/machinery";
import { toast } from "@/hooks/use-toast";
import { Sparkles, Loader2 } from "lucide-react";

interface InventoryFormProps {
  paso: number;
  onNext: () => void;
  onPrevious: () => void;
}

const InventoryForm = ({ paso, onNext, onPrevious }: InventoryFormProps) => {
  const {
    formData,
    handleInputChange,
    handleImageUpload,
    handleSubmit,
    mutation
  } = useInventoryForm();

  const { data: categories, isLoading: isLoadingCategories } = useQuery({
    queryKey: ['categories'],
    queryFn: getCategories
  });

  const handleChange = (name: string, value: string) => {
    handleInputChange({
      target: { name, value }
    } as React.ChangeEvent<HTMLInputElement>);
  };

  const renderPaso = () => {
    switch (paso) {
      case 1:
        return (
          <InformacionBasica
            formData={formData}
            onChange={handleChange}
            onNext={onNext}
            categories={categories || []}
            isLoadingCategories={isLoadingCategories}
          />
        );
      case 2:
        return (
          <SubirFotos
            formData={formData}
            onImageUpload={handleImageUpload}
            onNext={onNext}
            onPrevious={onPrevious}
          />
        );
      case 3:
        return (
          <RegistroFinal
            formData={formData}
            onSubmit={handleSubmit}
            categories={categories || []}
          />
        );
      default:
        return <div>Paso no válido</div>;
    }
  };

  // Si estamos en una fase temprana y la consulta de categorías falla, mostrar un mensaje
  useEffect(() => {
    if (!isLoadingCategories && (!categories || categories.length === 0) && paso === 1) {
      toast({
        title: "No se pudieron cargar las categorías",
        description: "Estamos experimentando problemas para cargar los datos. Por favor, inténtalo más tarde.",
        variant: "destructive",
      });
    }
  }, [categories, isLoadingCategories, paso]);

  if (mutation.isPending) {
    return (
      <div className="flex flex-col items-center justify-center p-12 space-y-6 bg-white rounded-lg shadow text-center">
        <Loader2 className="h-16 w-16 text-primary animate-spin" />
        <h3 className="text-xl font-semibold">Publicando tu maquinaria...</h3>
        <p className="text-gray-500 max-w-md">
          Estamos procesando tu publicación y subiendo las imágenes. Esto podría tomar unos momentos.
        </p>
      </div>
    );
  }

  return (
    <div className="relative">
      {/* Indicador de asistencia IA */}
      <div className="absolute -top-4 right-4 bg-gradient-to-r from-indigo-500 to-purple-600 text-white px-3 py-1 rounded-full text-sm font-medium flex items-center shadow-lg animate-pulse">
        <Sparkles className="h-3.5 w-3.5 mr-1" />
        Asistente IA activo
      </div>
      
      {renderPaso()}
    </div>
  );
};

export default InventoryForm;
