
import { LoadingCategories } from "./components/LoadingCategories";
import { CategoryItem, FormDataType } from "./types";
import { useCategoryManagement } from "./hooks/useCategoryManagement";
import { useStepManagement } from "./hooks/useStepManagement";
import { useErrorHandler } from "./hooks/useErrorHandler";
import { InventoryStepContent } from "./components/InventoryStepContent";

interface InformacionBasicaProps {
  formData: FormDataType;
  onChange: (name: string, value: string) => void;
  onNext: () => void;
  categories: CategoryItem[];
  isLoadingCategories: boolean;
}

export function InformacionBasica({
  formData,
  onChange,
  onNext,
  categories,
  isLoadingCategories
}: InformacionBasicaProps) {
  // Usar el hook de gestión de categorías
  const {
    selectedMainCategory,
    hasSubcategories,
    handleMainCategorySelect,
    getSelectedCategoryName,
    getSelectedMainCategoryName
  } = useCategoryManagement({ formData, onChange, categories });

  // Usar el hook de gestión de pasos
  const {
    errors,
    activeStep,
    validateForm,
    goToNextStep,
    goToPreviousStep,
    clearError
  } = useStepManagement({ categories, selectedMainCategory, formData });

  // Usar el hook para manejo de errores
  const { showErrorToast } = useErrorHandler({
    isLoadingCategories,
    categories,
    activeStep
  });

  // Manejar la navegación al siguiente paso del formulario principal
  const handleNextStep = () => {
    if (activeStep < 3) {
      // For steps 1-2, validate but continue regardless
      validateForm();
      goToNextStep();
    } else {
      // For the final step, validate strictly
      if (validateForm()) {
        onNext();
      } else {
        // Mostrar toast con errores
        showErrorToast({
          title: "Por favor corrige los errores",
          description: "Hay campos incompletos o con errores.",
          variant: "destructive"
        });
      }
    }
  };

  if (isLoadingCategories) {
    return <LoadingCategories />;
  }

  return (
    <InventoryStepContent
      activeStep={activeStep}
      totalSteps={3} // Changed from 6 to 3 steps
      formData={formData}
      onChange={onChange}
      categories={categories}
      selectedMainCategory={selectedMainCategory}
      hasSubcategories={hasSubcategories}
      errors={errors}
      clearError={clearError}
      getSelectedCategoryName={getSelectedCategoryName}
      getSelectedMainCategoryName={getSelectedMainCategoryName}
      handleMainCategorySelect={handleMainCategorySelect}
      goToPreviousStep={goToPreviousStep}
      handleNextStep={handleNextStep}
    />
  );
}
