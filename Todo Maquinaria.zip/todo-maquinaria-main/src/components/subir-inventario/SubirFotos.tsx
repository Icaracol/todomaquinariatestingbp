
import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { MachineFormData } from "@/types/machinery";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Trash2, Upload, ChevronLeft, ChevronRight, Image, Check, Info, Camera } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription } from "@/components/ui/alert";

interface SubirFotosProps {
  formData: MachineFormData;
  onImageUpload: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onNext: () => void;
  onPrevious: () => void;
}

export function SubirFotos({ formData, onImageUpload, onNext, onPrevious }: SubirFotosProps) {
  const [dragActive, setDragActive] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const [preview, setPreview] = useState<{ index: number; url: string } | null>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      // Crear un evento sintético para pasar a onImageUpload
      const fileInput = inputRef.current;
      if (fileInput) {
        // Crear un nuevo objeto FileList a partir de los archivos arrastrados
        const dataTransfer = new DataTransfer();
        Array.from(e.dataTransfer.files).forEach(file => {
          if (file.type.startsWith('image/')) {
            dataTransfer.items.add(file);
          }
        });
        
        // Asignar los archivos al input
        fileInput.files = dataTransfer.files;
        
        // Disparar el evento change
        const event = new Event('change', { bubbles: true });
        fileInput.dispatchEvent(event);
        
        // Llamar a onImageUpload con un evento sintético
        onImageUpload({
          target: { files: dataTransfer.files }
        } as unknown as React.ChangeEvent<HTMLInputElement>);
      }
    }
  };

  const handleButtonClick = () => {
    inputRef.current?.click();
  };

  const handleContinue = () => {
    if (!formData.imagenes || formData.imagenes.length === 0) {
      toast({
        title: "¡Se necesitan imágenes!",
        description: "Por favor, sube al menos una imagen para continuar.",
        variant: "destructive",
      });
      return;
    }
    onNext();
  };

  const removeImage = (index: number) => {
    if (formData.imagenes) {
      const files = Array.from(formData.imagenes);
      files.splice(index, 1);
      
      // Crear un nuevo objeto FileList sintético
      const dataTransfer = new DataTransfer();
      files.forEach(file => dataTransfer.items.add(file));
      
      // Actualizar el input
      if (inputRef.current) {
        inputRef.current.files = dataTransfer.files;
      }
      
      // Llamar a onImageUpload con un evento sintético
      onImageUpload({
        target: { files: dataTransfer.files }
      } as unknown as React.ChangeEvent<HTMLInputElement>);
      
      // Cerrar la previsualización si es necesario
      if (preview && preview.index === index) {
        setPreview(null);
      } else if (preview && preview.index > index) {
        // Ajustar el índice de la previsualización
        setPreview({ ...preview, index: preview.index - 1 });
      }
    }
  };

  const viewImage = (index: number) => {
    if (formData.imagenes && formData.imagenes[index]) {
      const url = URL.createObjectURL(formData.imagenes[index]);
      setPreview({ index, url });
    }
  };

  const closePreview = () => {
    if (preview) {
      URL.revokeObjectURL(preview.url);
      setPreview(null);
    }
  };

  return (
    <div className="space-y-8">
      <div className="text-center space-y-2">
        <h2 className="text-2xl font-bold text-gray-800">{formData.name}</h2>
        <p className="text-gray-600">
          {formData.year && `${formData.year} • `}
          {formData.price && `ARS ${formData.price} • `}
          {formData.location}
        </p>
      </div>

      <div className="space-y-6">
        <div className="text-center mb-6">
          <h3 className="text-xl font-semibold text-gray-800">Agrega fotos de tu maquinaria</h3>
          <p className="text-gray-600">
            Las fotos de alta calidad pueden aumentar el interés por tu maquinaria hasta un 70%
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-7">
          <div className="md:col-span-4">
            <div 
              className={`border-2 border-dashed rounded-lg p-8 h-60 flex flex-col items-center justify-center cursor-pointer transition-all
                ${dragActive ? 'border-primary bg-primary/5' : 'border-gray-300 hover:border-primary hover:bg-gray-50'}`}
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
              onClick={handleButtonClick}
            >
              <input
                ref={inputRef}
                type="file"
                id="imageUpload"
                multiple
                accept="image/*"
                onChange={onImageUpload}
                className="hidden"
              />
              
              <div className="flex flex-col items-center text-center">
                <Camera className="h-10 w-10 text-gray-400 mb-3" />
                <h4 className="font-semibold mb-1 text-gray-700">Arrastra y suelta o haz clic para subir</h4>
                <p className="text-sm text-gray-500">Soporta jpg, jpeg, png (máx 5MB por imagen)</p>
                
                <Button
                  type="button"
                  variant="outline"
                  className="mt-4"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleButtonClick();
                  }}
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Seleccionar imágenes
                </Button>
              </div>
            </div>

            <Alert className="mt-4 bg-blue-50 border-blue-100">
              <Info className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-blue-700">
                Para mejores resultados, incluye fotos desde diferentes ángulos, detalles de la cabina, y estado general.
              </AlertDescription>
            </Alert>
          </div>

          <div className="md:col-span-3">
            <Card className="h-full">
              <CardContent className="p-4 h-full">
                {formData.imagenes && formData.imagenes.length > 0 ? (
                  <div className="space-y-4 h-full flex flex-col">
                    <h4 className="font-semibold">Imágenes seleccionadas ({formData.imagenes.length})</h4>
                    
                    <div className="flex-1 overflow-y-auto">
                      <div className="grid grid-cols-3 gap-2">
                        {Array.from(formData.imagenes).map((image, index) => (
                          <div 
                            key={index} 
                            className="relative group aspect-square bg-gray-100 rounded-md overflow-hidden border"
                          >
                            <img 
                              src={URL.createObjectURL(image)} 
                              alt={`Preview ${index}`}
                              className="object-cover w-full h-full cursor-pointer"
                              onClick={() => viewImage(index)}
                            />
                            
                            {index === 0 && (
                              <span className="absolute top-1 left-1 bg-primary text-white text-xs px-1.5 py-0.5 rounded-sm">
                                Principal
                              </span>
                            )}
                            
                            <button
                              type="button"
                              className="absolute bottom-1 right-1 bg-red-500 text-white p-1 rounded opacity-0 group-hover:opacity-100 transition-opacity"
                              onClick={(e) => {
                                e.stopPropagation();
                                removeImage(index);
                              }}
                            >
                              <Trash2 className="h-3 w-3" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <div className="text-center text-sm text-gray-500">
                      La primera imagen será la miniatura principal
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-full text-center">
                    <Image className="h-12 w-12 text-gray-300 mb-2" />
                    <h4 className="text-gray-400 font-medium">No hay imágenes seleccionadas</h4>
                    <p className="text-gray-400 text-sm">
                      Las publicaciones con 3+ imágenes reciben más interés
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {preview && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
          <div className="relative bg-white rounded-lg shadow-xl max-w-3xl w-full max-h-[90vh] flex flex-col">
            <div className="p-4 border-b flex justify-between items-center">
              <h3 className="font-semibold">Vista previa de imagen</h3>
              <button 
                type="button" 
                className="text-gray-500 hover:text-gray-700"
                onClick={closePreview}
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <div className="flex-1 overflow-hidden p-4">
              <img 
                src={preview.url} 
                alt="Preview" 
                className="max-w-full max-h-[70vh] mx-auto object-contain"
              />
            </div>
            <div className="p-4 border-t flex justify-between">
              <Button
                variant="destructive"
                size="sm"
                onClick={() => {
                  removeImage(preview.index);
                  closePreview();
                }}
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Eliminar
              </Button>
              <Button
                variant="default"
                size="sm"
                onClick={closePreview}
              >
                <Check className="h-4 w-4 mr-2" />
                Aceptar
              </Button>
            </div>
          </div>
        </div>
      )}

      <div className="flex justify-between pt-4">
        <Button type="button" variant="outline" onClick={onPrevious}>
          <ChevronLeft className="mr-2 h-4 w-4" />
          Anterior
        </Button>
        <Button type="button" onClick={handleContinue}>
          Siguiente
          <ChevronRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
