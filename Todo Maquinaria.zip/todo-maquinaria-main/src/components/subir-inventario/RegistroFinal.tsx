
import { MachineFormData } from "@/types/machinery";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { PublicationSummary } from "./registro-final/PublicationSummary";
import { PricingTabsSection } from "./registro-final/PricingTabsSection";
import { TermsAndConditions } from "./registro-final/TermsAndConditions";
import { PublishButton } from "./registro-final/PublishButton";
import { PRICING_PLANS } from "./registro-final/constants";

interface RegistroFinalProps {
  formData: MachineFormData;
  onSubmit: () => void;
  categories: Array<{ 
    id: string; 
    name: string; 
    parent_id: string | null;
  }>;
}

const RegistroFinal = ({ formData, onSubmit, categories }: RegistroFinalProps) => {
  const [selectedPlan, setSelectedPlan] = useState<string>("free");
  const [termsAccepted, setTermsAccepted] = useState(false);
  const navigate = useNavigate();
  
  const getCategoryName = (id: string) => {
    return categories.find(cat => cat.id === id)?.name || 'No especificada';
  };

  const handleSubmitWithPlan = () => {
    if (!termsAccepted) {
      alert("Por favor acepta los términos y condiciones para continuar");
      return;
    }
    
    // Verificar si está en modo gratis y necesita actualizar plan
    if (selectedPlan !== "free") {
      // Redirigir a la página de precios con los datos guardados
      navigate("/pricing");
    } else {
      // Continuar con la publicación gratuita
      onSubmit();
    }
  };

  return (
    <div className="space-y-8">
      <PublicationSummary 
        formData={formData} 
        getCategoryName={getCategoryName} 
      />
      
      <PricingTabsSection 
        plans={PRICING_PLANS}
        selectedPlan={selectedPlan}
        onPlanChange={setSelectedPlan}
      />
      
      <TermsAndConditions 
        termsAccepted={termsAccepted}
        onTermsChange={setTermsAccepted}
      />
      
      <PublishButton 
        onClick={handleSubmitWithPlan} 
        disabled={!termsAccepted} 
      />
    </div>
  );
};

export default RegistroFinal;
