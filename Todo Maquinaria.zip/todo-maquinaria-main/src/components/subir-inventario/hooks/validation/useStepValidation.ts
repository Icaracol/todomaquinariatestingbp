
import { CategoryItem } from "../../types";
import { useErrorState } from "./useErrorState";

interface UseStepValidationProps {
  categories: CategoryItem[];
  selectedMainCategory: string | null;
  formData: {
    name: string;
    category_id: string;
    year: string;
    price: string;
    location?: string; // Make location optional
  };
}

export function useStepValidation({
  categories,
  selectedMainCategory,
  formData
}: UseStepValidationProps) {
  const { errors, setErrors, clearError } = useErrorState();

  const validateCurrentStep = (activeStep: number) => {
    const newErrors: Record<string, string> = {};
    console.log(`Validating step ${activeStep} with formData:`, formData);
    
    switch (activeStep) {
      case 1:
        // Validate Step 1: Machine name and main category
        if (!formData.name || !formData.name.trim()) {
          newErrors.name = "El nombre de la máquina es obligatorio";
          console.log("Validation failed: Machine name is required");
        }
        
        if (!selectedMainCategory) {
          newErrors.category = "Debes seleccionar una categoría principal";
          console.log("Validation failed: Main category is required");
        }
        break;
        
      case 2:
        // Validate Step 2: Subcategory and brand (brand is optional)
        const hasSubcategories = categories.some(cat => cat.parent_id === selectedMainCategory);
        
        if (hasSubcategories) {
          const subcategories = categories.filter(cat => 
            cat.parent_id === selectedMainCategory && 
            (!cat.type || cat.type === 'category')
          );
          
          if (subcategories.length > 0) {
            const isValidSubcategory = subcategories.some(sub => sub.id === formData.category_id);
            
            if (!formData.category_id || !isValidSubcategory) {
              newErrors.category = "Debes seleccionar una subcategoría válida";
              console.log("Validation failed: Invalid or missing subcategory");
            }
          }
        }
        break;
        
      case 3:
        // Validate Step 3: Details, description and final review
        if (formData.year && (parseInt(formData.year) < 1900 || parseInt(formData.year) > new Date().getFullYear())) {
          newErrors.year = `El año debe estar entre 1900 y ${new Date().getFullYear()}`;
          console.log("Validation failed: Year is invalid");
        }
        
        if (!formData.price) {
          newErrors.price = "El precio es obligatorio";
          console.log("Validation failed: Price is required");
        } else if (parseFloat(formData.price) <= 0) {
          newErrors.price = "El precio debe ser mayor que 0";
          console.log("Validation failed: Price is invalid");
        }
        
        // Only validate location if it exists
        if (formData.location !== undefined && (!formData.location || !formData.location.trim())) {
          newErrors.location = "La ubicación es obligatoria";
          console.log("Validation failed: Location is required");
        }
        break;
    }
    
    console.log("Validation errors:", newErrors);
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  return {
    errors,
    validateCurrentStep,
    clearError,
    setErrors
  };
}
