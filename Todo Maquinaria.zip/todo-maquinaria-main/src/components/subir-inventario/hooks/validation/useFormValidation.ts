
import { CategoryItem } from "../../types";
import { useStepValidation } from "./useStepValidation";
import { useFormValidator } from "./useFormValidator";

interface UseFormValidationProps {
  categories: CategoryItem[];
  selectedMainCategory: string | null;
  formData: {
    name: string;
    category_id: string;
    year: string;
    price: string;
    location?: string; // Make location optional
  };
}

export function useFormValidation({
  categories,
  selectedMainCategory,
  formData
}: UseFormValidationProps) {
  // Use the step validation hook
  const { 
    errors: stepErrors, 
    validateCurrentStep, 
    clearError: clearStepError,
    setErrors: setStepErrors
  } = useStepValidation({ categories, selectedMainCategory, formData });

  // Use the form validator hook
  const { 
    validateForm,
  } = useFormValidator({ categories, selectedMainCategory, formData });

  return {
    errors: stepErrors,
    validateCurrentStep,
    validateForm,
    clearError: clearStepError,
    setErrors: setStepErrors
  };
}
