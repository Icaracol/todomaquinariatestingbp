
import { CategoryItem } from "../../types";
import { useErrorState } from "./useErrorState";

interface UseFormValidatorProps {
  categories: CategoryItem[];
  selectedMainCategory: string | null;
  formData: {
    name: string;
    category_id: string;
    year: string;
    price: string;
    location?: string; // Make location optional
  };
}

export function useFormValidator({
  categories,
  selectedMainCategory,
  formData
}: UseFormValidatorProps) {
  const { errors, setErrors, clearError } = useErrorState();

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    // Name validation
    if (!formData.name || !formData.name.trim()) {
      newErrors.name = "El nombre de la máquina es obligatorio";
    }

    // Category validation
    if (!selectedMainCategory) {
      newErrors.category = "Debes seleccionar una categoría principal";
    } else {
      // Check if this category has subcategories
      const hasSubcategories = categories.some(cat => cat.parent_id === selectedMainCategory);
      
      if (hasSubcategories) {
        const subcategories = categories.filter(cat => 
          cat.parent_id === selectedMainCategory && 
          (!cat.type || cat.type === 'category')
        );
        
        // Only validate subcategory selection if subcategories exist
        if (subcategories.length > 0 && !formData.category_id) {
          newErrors.category = "Debes seleccionar una categoría específica";
        } else if (subcategories.length > 0) {
          // Verify that the selected category_id is actually a valid subcategory
          const isValidSubcategory = subcategories.some(sub => sub.id === formData.category_id);
          if (!isValidSubcategory) {
            newErrors.category = "La subcategoría seleccionada no es válida";
          }
        }
      }
    }
    
    // Year validation
    if (formData.year && (parseInt(formData.year) < 1900 || parseInt(formData.year) > new Date().getFullYear())) {
      newErrors.year = `El año debe estar entre 1900 y ${new Date().getFullYear()}`;
    }
    
    // Price validation
    if (!formData.price) {
      newErrors.price = "El precio es obligatorio";
    } else if (parseFloat(formData.price) <= 0) {
      newErrors.price = "El precio debe ser mayor que 0";
    }
    
    // Location validation - only validate if it exists
    if (formData.location !== undefined && (!formData.location || !formData.location.trim())) {
      newErrors.location = "La ubicación es obligatoria";
    }
    
    console.log("Form validation errors:", newErrors);
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  return {
    errors,
    validateForm,
    clearError,
    setErrors
  };
}
