
import { useState } from "react";

export function useErrorState() {
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Clear a specific error
  const clearError = (field: string) => {
    setErrors(prev => {
      const newErrors = {
        ...prev
      };
      delete newErrors[field];
      return newErrors;
    });
  };

  return {
    errors,
    setErrors,
    clearError
  };
}
