
import { useFormValidation } from "./validation/useFormValidation";
import { useStepNavigation } from "./navigation/useStepNavigation";
import { CategoryItem } from "../types";

interface UseStepManagementProps {
  categories: CategoryItem[];
  selectedMainCategory: string | null;
  formData: {
    name: string;
    category_id: string;
    year: string;
    price: string;
    location?: string; // Make location optional
  };
}

export function useStepManagement({ 
  categories, 
  selectedMainCategory, 
  formData 
}: UseStepManagementProps) {
  const {
    errors,
    validateCurrentStep,
    validateForm,
    clearError,
    setErrors
  } = useFormValidation({ categories, selectedMainCategory, formData });

  const {
    activeStep,
    setActiveStep,
    goToNextStep,
    goToPreviousStep
  } = useStepNavigation({ 
    validateCurrentStep: (step) => validateCurrentStep(step)
  });

  return {
    errors,
    activeStep,
    setActiveStep,
    validateCurrentStep,
    validateForm,
    goToNextStep,
    goToPreviousStep,
    clearError
  };
}
