
import { useToast } from "@/hooks/use-toast";
import { useEffect } from "react";
import { CategoryItem } from "../types";

interface UseErrorHandlerProps {
  isLoadingCategories: boolean;
  categories: CategoryItem[];
  activeStep: number;
}

export function useErrorHandler({ 
  isLoadingCategories, 
  categories, 
  activeStep 
}: UseErrorHandlerProps) {
  const { toast } = useToast();

  // If we're in an early phase and the category query fails, show a message
  useEffect(() => {
    if (!isLoadingCategories && (!categories || categories.length === 0) && activeStep === 1) {
      toast({
        title: "No se pudieron cargar las categorías",
        description: "Estamos experimentando problemas para cargar los datos. Por favor, inténtalo más tarde.",
        variant: "destructive",
      });
    }
  }, [categories, isLoadingCategories, activeStep, toast]);

  return { showErrorToast: toast };
}
