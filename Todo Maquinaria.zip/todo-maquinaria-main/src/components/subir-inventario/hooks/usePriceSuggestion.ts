
import { useState } from "react";
import { useMachineryAI } from "@/hooks/use-machinery-ai";
import { useToast } from "@/hooks/use-toast";

interface UsePriceSuggestionProps {
  productName: string;
  year: string;
  categoryName: string;
  onChangePrice: (value: string) => void;
  onClearPriceError?: () => void;
}

interface PriceSuggestion {
  price: string;
  confidence: number;
  message: string;
}

export function usePriceSuggestion({
  productName,
  year,
  categoryName,
  onChangePrice,
  onClearPriceError
}: UsePriceSuggestionProps) {
  const { suggestMarketPrice, isLoading } = useMachineryAI();
  const { toast } = useToast();
  const [suggestion, setSuggestion] = useState<PriceSuggestion | null>(null);

  const handleGetPriceSuggestion = async () => {
    if (!productName.trim()) {
      toast({
        title: "Información incompleta",
        description: "Se necesita el nombre de la máquina para sugerir un precio",
        variant: "destructive"
      });
      return;
    }

    try {
      // Notify user that we're analyzing the market
      toast({
        title: "Analizando mercado",
        description: "Estamos consultando precios similares y tendencias actuales...",
      });
      
      const result = await suggestMarketPrice(productName, year, categoryName);
      
      if (result) {
        setSuggestion(result);
        
        // Use confidence level to determine toast variant
        const variant = result.confidence > 70 ? undefined : "default";
        
        toast({
          title: "Precio sugerido",
          description: `${result.message} (basado en análisis de mercado ${
            result.confidence > 80 ? "con alta confianza" : 
            result.confidence > 50 ? "con confianza media" : "con baja confianza"
          })`,
          variant: variant
        });
      }
    } catch (error) {
      console.error("Error al sugerir precio:", error);
      toast({
        title: "No se pudo obtener sugerencia",
        description: "Hubo un problema al analizar los datos del mercado. Puedes establecer un precio manualmente.",
        variant: "destructive"
      });
    }
  };

  const applyPriceSuggestion = () => {
    if (suggestion?.price) {
      onChangePrice(suggestion.price);
      if (onClearPriceError) {
        onClearPriceError();
      }
      
      toast({
        title: "Precio aplicado",
        description: "Se ha aplicado el precio sugerido por la IA.",
      });
      
      setSuggestion(null);
    }
  };

  return {
    suggestion,
    isLoading,
    handleGetPriceSuggestion,
    applyPriceSuggestion
  };
}
