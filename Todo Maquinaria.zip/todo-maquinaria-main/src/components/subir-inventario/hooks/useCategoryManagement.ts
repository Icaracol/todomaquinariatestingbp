
import { useState } from "react";
import { useCategorySelection } from "./category/useCategorySelection";
import { useCategorySync } from "./category/useCategorySync";
import { useCategoryAutoSuggest } from "./category/useCategoryAutoSuggest";
import { useCategoryUtils } from "./category/useCategoryUtils";
import { CategoryItem, FormDataType } from "../types";

interface UseCategoryManagementProps {
  formData: FormDataType;
  onChange: (name: string, value: string) => void;
  categories: CategoryItem[];
}

export function useCategoryManagement({
  formData,
  onChange,
  categories
}: UseCategoryManagementProps) {
  // Get category selection functionality from the selection hook
  const {
    selectedMainCategory,
    selectedSubCategory,
    selectedModel,
    hasSubcategories,
    hasModels,
    handleMainCategorySelect,
    handleSubCategorySelect,
    handleModelSelect
  } = useCategorySelection({ onChange, categories });

  // Use the category sync hook to keep UI state in sync with form data
  useCategorySync({
    formData,
    categories,
    // Use the handler functions instead of directly assigning to constants
    setSelectedMainCategory: (id) => {
      if (id) handleMainCategorySelect(id);
    },
    setSelectedSubCategory: (id) => {
      if (id) handleSubCategorySelect(id);
    },
    setSelectedModel: (id) => {
      if (id) handleModelSelect(id);
    }
  });

  // Auto-suggestion functionality
  useCategoryAutoSuggest({
    formData,
    categories,
    selectedMainCategory,
    setSelectedMainCategory: (id) => {
      if (id) handleMainCategorySelect(id);
    },
    setSelectedSubCategory: (id) => {
      if (id) handleSubCategorySelect(id);
    }
  });

  // Utility functions for category data
  const {
    getCategoryHierarchy,
    getSelectedCategoryName,
    getSelectedMainCategoryName,
    getFullCategoryPath,
    getSubcategories,
    getModels
  } = useCategoryUtils({
    categories,
    formData,
    selectedMainCategory,
    selectedSubCategory,
    selectedModel
  });

  return {
    // Basic category selection state
    selectedMainCategory,
    selectedSubCategory,
    selectedModel,
    hasSubcategories,
    hasModels,
    
    // Category selection handlers
    handleMainCategorySelect,
    handleSubCategorySelect,
    handleModelSelect,
    
    // Utility functions
    getCategoryHierarchy,
    getSelectedCategoryName, 
    getSelectedMainCategoryName,
    getFullCategoryPath,
    getSubcategories,
    getModels
  };
}
