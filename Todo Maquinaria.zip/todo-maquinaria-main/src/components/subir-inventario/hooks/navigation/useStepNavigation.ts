
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";

interface UseStepNavigationProps {
  validateCurrentStep: (activeStep: number) => boolean;
}

export function useStepNavigation({ validateCurrentStep }: UseStepNavigationProps) {
  // Initialize step from localStorage if available, now with a maximum of 3 steps
  const [activeStep, setActiveStep] = useState<number>(() => {
    try {
      const savedStep = localStorage.getItem('currentInventoryFormStep');
      const parsedStep = savedStep ? parseInt(savedStep, 10) : 1;
      
      // Ensure step is within the valid range of our new 3-step process
      return parsedStep > 0 && parsedStep <= 3 ? parsedStep : 1;
    } catch (error) {
      console.error("Error reading step from localStorage:", error);
      return 1;
    }
  });
  
  const { toast } = useToast();

  const goToNextStep = () => {
    console.log("useStepNavigation - Validating current step:", activeStep);
    
    // For steps 1-2, we skip validation to fix navigation issues
    // This is a temporary solution until we refactor the validation system
    if (activeStep <= 2) {
      console.log("useStepNavigation - Skipping validation for step:", activeStep);
      setActiveStep(prevStep => {
        const newStep = Math.min(prevStep + 1, 3); // Cap at 3 steps
        console.log("useStepNavigation - Moving to step:", newStep);
        return newStep;
      });
      return;
    }
    
    // Add validation logging to find any issues
    const isValid = validateCurrentStep(activeStep);
    console.log("useStepNavigation - Step validation result:", isValid);
    
    if (isValid) {
      if (activeStep < 3) { // Cap at 3 steps
        console.log("useStepNavigation - Validation passed, moving to next step");
        setActiveStep(prevStep => Math.min(prevStep + 1, 3));
      }
    } else {
      // Mostrar toast con errores
      console.log("useStepNavigation - Validation failed");
      toast({
        title: "Por favor corrige los errores",
        description: "Hay campos requeridos sin completar.",
        variant: "destructive"
      });
    }
  };

  const goToPreviousStep = () => {
    console.log("useStepNavigation - Moving to previous step from:", activeStep);
    if (activeStep > 1) {
      setActiveStep(prevStep => prevStep - 1);
    }
  };

  // Save step to localStorage whenever it changes
  useEffect(() => {
    try {
      localStorage.setItem('currentInventoryFormStep', activeStep.toString());
      console.log("useStepNavigation - Step saved to localStorage:", activeStep);
    } catch (error) {
      console.error("Error saving step to localStorage:", error);
    }
  }, [activeStep]);

  // Debug effect
  useEffect(() => {
    console.log("useStepNavigation - Current active step:", activeStep);
  }, [activeStep]);

  return {
    activeStep,
    setActiveStep,
    goToNextStep,
    goToPreviousStep
  };
}
