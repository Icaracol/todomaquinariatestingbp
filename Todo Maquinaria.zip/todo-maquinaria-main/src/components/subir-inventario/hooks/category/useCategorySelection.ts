
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { CategoryItem } from "../../types";

interface UseCategorySelectionProps {
  onChange: (name: string, value: string) => void;
  categories: CategoryItem[];
}

export function useCategorySelection({ onChange, categories }: UseCategorySelectionProps) {
  const [selectedMainCategory, setSelectedMainCategory] = useState<string | null>(null);
  const [selectedSubCategory, setSelectedSubCategory] = useState<string | null>(null);
  const [selectedModel, setSelectedModel] = useState<string | null>(null);
  const { toast } = useToast();

  // Handle main category selection
  const handleMainCategorySelect = (categoryId: string) => {
    // Al seleccionar una nueva categoría principal, reiniciamos las selecciones secundarias
    setSelectedMainCategory(categoryId);
    setSelectedSubCategory(null);
    setSelectedModel(null);

    // Check if there are subcategories for this main category
    const hasSubcategories = categories.some(cat => cat.parent_id === categoryId);
    
    // Si no hay subcategorías, usar esta como la categoría final
    if (!hasSubcategories) {
      onChange('category_id', categoryId);
      toast({
        title: "Categoría seleccionada",
        description: "Se ha seleccionado esta categoría para tu maquinaria.",
      });
    } else {
      // Limpiar la selección actual hasta que se elija una subcategoría
      onChange('category_id', '');
    }
  };

  // Handle subcategory selection
  const handleSubCategorySelect = (categoryId: string) => {
    setSelectedSubCategory(categoryId);
    setSelectedModel(null);
    
    // Check if there are specific models for this subcategory
    const hasModels = categories.some(cat => cat.parent_id === categoryId);
    
    // Si no hay modelos específicos, usar esta como la categoría final
    if (!hasModels) {
      onChange('category_id', categoryId);
      toast({
        title: "Subcategoría seleccionada",
        description: "Se ha seleccionado esta subcategoría para tu maquinaria.",
      });
    } else {
      // Limpiar la selección actual hasta que se elija un modelo
      onChange('category_id', '');
    }
  };

  // Handle specific model selection
  const handleModelSelect = (categoryId: string) => {
    setSelectedModel(categoryId);
    onChange('category_id', categoryId);
    toast({
      title: "Modelo seleccionado",
      description: "Se ha seleccionado este modelo específico para tu maquinaria.",
    });
  };

  // Check if there are subcategories for the current selection
  const hasSubcategories = selectedMainCategory 
    ? categories.some(cat => cat.parent_id === selectedMainCategory) 
    : false;

  // Check if there are specific models for the selected subcategory
  const hasModels = selectedSubCategory 
    ? categories.some(cat => cat.parent_id === selectedSubCategory) 
    : false;

  return {
    selectedMainCategory,
    selectedSubCategory,
    selectedModel,
    hasSubcategories,
    hasModels,
    handleMainCategorySelect,
    handleSubCategorySelect,
    handleModelSelect
  };
}
