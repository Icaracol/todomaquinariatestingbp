
import { useEffect } from "react";
import { CategoryItem } from "../../types";

interface UseCategorySyncProps {
  formData: {
    category_id: string;
  };
  categories: CategoryItem[];
  setSelectedMainCategory: (id: string | null) => void;
  setSelectedSubCategory: (id: string | null) => void;
  setSelectedModel: (id: string | null) => void;
}

export function useCategorySync({
  formData,
  categories,
  setSelectedMainCategory,
  setSelectedSubCategory,
  setSelectedModel
}: UseCategorySyncProps) {
  // Sync with existing selections
  useEffect(() => {
    if (formData.category_id) {
      const selectedCategory = categories.find(cat => cat.id === formData.category_id);
      
      if (selectedCategory) {
        // If it's a third-level category (specific model)
        if (selectedCategory.parent_id) {
          const parentCategory = categories.find(cat => cat.id === selectedCategory.parent_id);
          
          if (parentCategory && parentCategory.parent_id) {
            // It's a specific model (level 3)
            setSelectedModel(selectedCategory.id);
            setSelectedSubCategory(parentCategory.id);
            setSelectedMainCategory(parentCategory.parent_id);
          } else if (parentCategory) {
            // It's a subcategory (level 2)
            setSelectedSubCategory(selectedCategory.id);
            setSelectedMainCategory(selectedCategory.parent_id);
            setSelectedModel(null);
          }
        } else {
          // It's a main category (level 1)
          setSelectedMainCategory(selectedCategory.id);
          setSelectedSubCategory(null);
          setSelectedModel(null);
        }
      }
    }
  }, [formData.category_id, categories, setSelectedMainCategory, setSelectedSubCategory, setSelectedModel]);
}
