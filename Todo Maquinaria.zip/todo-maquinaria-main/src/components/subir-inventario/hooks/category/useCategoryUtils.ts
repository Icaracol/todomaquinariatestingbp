
import { useMemo } from "react";
import { CategoryItem, CategoryHierarchy } from "../../types";

interface UseCategoryUtilsProps {
  categories: CategoryItem[];
  formData: {
    category_id: string;
  };
  selectedMainCategory: string | null;
  selectedSubCategory: string | null;
  selectedModel: string | null;
}

export function useCategoryUtils({
  categories,
  formData,
  selectedMainCategory,
  selectedSubCategory,
  selectedModel
}: UseCategoryUtilsProps) {
  // Get the complete category hierarchy based on current selections
  const getCategoryHierarchy = useMemo((): CategoryHierarchy => {
    const mainCategory = selectedMainCategory 
      ? categories.find(cat => cat.id === selectedMainCategory) || null 
      : null;
    
    const subCategory = selectedSubCategory 
      ? categories.find(cat => cat.id === selectedSubCategory) || null 
      : null;
    
    const specificModel = selectedModel 
      ? categories.find(cat => cat.id === selectedModel) || null 
      : null;
    
    return {
      mainCategory,
      subCategory,
      specificModel
    };
  }, [categories, selectedMainCategory, selectedSubCategory, selectedModel]);

  // Get selected category name (for display)
  const getSelectedCategoryName = useMemo(() => {
    return () => {
      if (!formData.category_id) return "";
      const category = categories.find(cat => cat.id === formData.category_id);
      return category?.name || "";
    };
  }, [categories, formData.category_id]);

  // Get selected main category name
  const getSelectedMainCategoryName = useMemo(() => {
    return () => {
      if (!selectedMainCategory) return "";
      const mainCategory = categories.find(cat => cat.id === selectedMainCategory);
      return mainCategory?.name || "";
    };
  }, [categories, selectedMainCategory]);

  // Get full category path (including hierarchy)
  const getFullCategoryPath = useMemo(() => {
    if (getCategoryHierarchy.specificModel) {
      return `${getCategoryHierarchy.mainCategory?.name} > ${getCategoryHierarchy.subCategory?.name} > ${getCategoryHierarchy.specificModel.name}`;
    } else if (getCategoryHierarchy.subCategory) {
      return `${getCategoryHierarchy.mainCategory?.name} > ${getCategoryHierarchy.subCategory.name}`;
    } else if (getCategoryHierarchy.mainCategory) {
      return getCategoryHierarchy.mainCategory.name;
    }
    
    return "";
  }, [getCategoryHierarchy]);

  // Get subcategories for the selected main category
  const getSubcategories = useMemo(() => {
    if (!selectedMainCategory) return [];
    return categories.filter(cat => cat.parent_id === selectedMainCategory);
  }, [categories, selectedMainCategory]);

  // Get models for the selected subcategory
  const getModels = useMemo(() => {
    if (!selectedSubCategory) return [];
    return categories.filter(cat => cat.parent_id === selectedSubCategory);
  }, [categories, selectedSubCategory]);

  return {
    getCategoryHierarchy,
    getSelectedCategoryName,
    getSelectedMainCategoryName,
    getFullCategoryPath,
    getSubcategories,
    getModels
  };
}
