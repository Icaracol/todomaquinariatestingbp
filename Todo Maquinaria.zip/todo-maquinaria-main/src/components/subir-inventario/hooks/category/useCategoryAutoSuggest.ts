
import { useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { CategoryItem } from "../../types";

interface UseCategoryAutoSuggestProps {
  formData: {
    name: string;
  };
  categories: CategoryItem[];
  selectedMainCategory: string | null;
  setSelectedMainCategory: (id: string | null) => void;
  setSelectedSubCategory: (id: string | null) => void;
}

export function useCategoryAutoSuggest({
  formData,
  categories,
  selectedMainCategory,
  setSelectedMainCategory,
  setSelectedSubCategory
}: UseCategoryAutoSuggestProps) {
  const { toast } = useToast();

  // Auto-suggest category based on machine name
  useEffect(() => {
    if (formData.name && !selectedMainCategory) {
      const nameLower = formData.name.toLowerCase();
      const mainCategories = categories.filter(cat => !cat.parent_id);
      
      // Improved matching algorithm
      // First try exact matches or contains
      let suggestedCategory = mainCategories.find(cat => 
        nameLower.includes(cat.name.toLowerCase())
      );
      
      // If no match found, try word-by-word matching
      if (!suggestedCategory) {
        const nameWords = nameLower.split(/\s+/);
        
        for (const word of nameWords) {
          if (word.length < 3) continue; // Skip very short words
          
          const matchByWord = mainCategories.find(cat => 
            cat.name.toLowerCase().includes(word)
          );
          
          if (matchByWord) {
            suggestedCategory = matchByWord;
            break;
          }
        }
      }
      
      if (suggestedCategory) {
        setSelectedMainCategory(suggestedCategory.id);
        toast({
          title: "Categoría sugerida",
          description: `Hemos detectado que tu máquina podría ser ${suggestedCategory.name}`
        });
      } else {
        // Search for matches in subcategories with improved algorithm
        const subCategories = categories.filter(cat => cat.parent_id !== null);
        
        // Try exact matches first
        let suggestedSubCategory = subCategories.find(cat => 
          nameLower.includes(cat.name.toLowerCase())
        );
        
        // If no match, try word-by-word for subcategories
        if (!suggestedSubCategory) {
          const nameWords = nameLower.split(/\s+/);
          
          for (const word of nameWords) {
            if (word.length < 3) continue;
            
            const matchByWord = subCategories.find(cat => 
              cat.name.toLowerCase().includes(word)
            );
            
            if (matchByWord) {
              suggestedSubCategory = matchByWord;
              break;
            }
          }
        }
        
        if (suggestedSubCategory && suggestedSubCategory.parent_id) {
          setSelectedSubCategory(suggestedSubCategory.id);
          setSelectedMainCategory(suggestedSubCategory.parent_id);
          toast({
            title: "Subcategoría sugerida",
            description: `Hemos detectado que tu máquina podría ser una ${suggestedSubCategory.name}`
          });
        }
      }
    }
  }, [formData.name, categories, toast, selectedMainCategory, setSelectedMainCategory, setSelectedSubCategory]);
}
