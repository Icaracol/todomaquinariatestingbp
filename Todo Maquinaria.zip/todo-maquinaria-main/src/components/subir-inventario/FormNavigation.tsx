
import { Button } from "@/components/ui/button";
import { ArrowLeft, ArrowRight, Loader2 } from "lucide-react";

interface FormNavigationProps {
  paso: number;
  onNext: () => void;
  onPrevious: () => void;
  isPending: boolean;
  onSubmit: () => void;
}

const FormNavigation = ({
  paso,
  onNext,
  onPrevious,
  isPending,
  onSubmit
}: FormNavigationProps) => {
  const isFirstStep = paso === 1;
  const isLastStep = paso === 3;

  return (
    <div className="flex justify-between items-center pt-6 border-t mt-8">
      <Button
        type="button"
        onClick={onPrevious}
        disabled={isFirstStep || isPending}
        variant="outline"
        className="relative group px-6"
      >
        <span className="absolute inset-0 bg-gradient-to-r from-primary/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity rounded-md" />
        <ArrowLeft className="h-4 w-4 mr-2 transition-transform group-hover:-translate-x-1" />
        Anterior
      </Button>

      {!isLastStep && (
        <Button
          type="button"
          onClick={onNext}
          className="relative group px-6 bg-gradient-to-r from-primary to-blue-600 hover:from-primary/90 hover:to-blue-600/90 shadow-lg shadow-primary/25"
        >
          Siguiente
          <ArrowRight className="h-4 w-4 ml-2 transition-transform group-hover:translate-x-1" />
          <span className="absolute inset-0 bg-white opacity-0 group-hover:opacity-10 transition-opacity rounded-md" />
        </Button>
      )}

      {isPending && (
        <div className="flex items-center gap-2 text-primary">
          <Loader2 className="h-4 w-4 animate-spin" />
          Procesando...
        </div>
      )}
    </div>
  );
};

export default FormNavigation;
