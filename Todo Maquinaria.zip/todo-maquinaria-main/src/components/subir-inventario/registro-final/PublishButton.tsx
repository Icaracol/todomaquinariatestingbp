
import { Check, Loader2 } from "lucide-react";

interface PublishButtonProps {
  onClick: () => void;
  disabled: boolean;
  isLoading?: boolean;
}

export function PublishButton({ onClick, disabled, isLoading = false }: PublishButtonProps) {
  return (
    <div className="flex justify-center pt-4">
      <button
        onClick={onClick}
        disabled={disabled || isLoading}
        className={`px-8 py-4 bg-gradient-to-r from-primary to-blue-600 hover:from-primary/90 hover:to-blue-600/90 
          text-white font-semibold rounded-lg text-lg shadow-lg shadow-primary/25 relative overflow-hidden
          transition-all duration-300 ${disabled || isLoading ? 'opacity-50 cursor-not-allowed' : 'hover:scale-105'}`}
      >
        <span className="absolute inset-0 bg-white opacity-0 hover:opacity-10 transition-opacity rounded-md" />
        <span className="flex items-center gap-2">
          {isLoading ? (
            <Loader2 className="h-5 w-5 animate-spin" />
          ) : (
            <Check className="h-5 w-5" />
          )}
          {isLoading ? 'Publicando...' : 'Publicar Ahora'}
        </span>
      </button>
    </div>
  );
}
