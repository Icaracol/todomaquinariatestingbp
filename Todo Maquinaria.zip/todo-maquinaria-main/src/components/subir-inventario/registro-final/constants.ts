
import { PricingPlanData } from "./PricingPlan";

// Pricing plans data
export const PRICING_PLANS: PricingPlanData[] = [
  {
    id: "free",
    name: "Básico",
    price: "Gratis",
    description: "Prueba gratuita por tiempo limitado",
    features: [
      "1 Producto/Servicio publicado",
      "Visible por 15 días",
      "Acceso a consultas básicas"
    ],
    role: "basic"
  },
  {
    id: "premium",
    name: "Premium",
    price: "65",
    description: "Para pequeños negocios y vendedores individuales",
    features: [
      "Hasta 15 maquinarias publicadas",
      "Destacado en búsquedas",
      "Estadísticas de visitas"
    ],
    role: "premium"
  },
  {
    id: "business",
    name: "Empresarial",
    price: "200",
    description: "Para empresas y vendedores profesionales",
    features: [
      "Publicación ilimitada",
      "Integración con tu sitio web",
      "Soporte prioritario 24/7"
    ],
    role: "enterprise"
  }
];
