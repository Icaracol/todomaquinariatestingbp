
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle, ShieldCheck } from "lucide-react";

interface TermsAndConditionsProps {
  termsAccepted: boolean;
  onTermsChange: (checked: boolean) => void;
}

export function TermsAndConditions({ termsAccepted, onTermsChange }: TermsAndConditionsProps) {
  return (
    <div className="space-y-4">
      <div className="flex items-start space-x-2">
        <Checkbox 
          id="terms" 
          checked={termsAccepted}
          onCheckedChange={(checked) => onTermsChange(checked as boolean)}
        />
        <div className="grid gap-1.5 leading-none">
          <Label
            htmlFor="terms"
            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
          >
            Acepto los términos y condiciones
          </Label>
          <p className="text-sm text-muted-foreground">
            Al publicar, aceptas nuestros <a href="#" className="text-primary underline">términos de servicio</a> y <a href="#" className="text-primary underline">política de privacidad</a>.
          </p>
        </div>
      </div>
      
      <Alert className="bg-blue-50 border-blue-200">
        <ShieldCheck className="h-4 w-4 text-blue-600" />
        <AlertTitle className="text-blue-800">Información importante</AlertTitle>
        <AlertDescription className="text-blue-700">
          Recibirás notificaciones cuando los compradores muestren interés en tu maquinaria.
          Todos los leads serán gestionados automáticamente en tu panel.
        </AlertDescription>
      </Alert>
    </div>
  );
}
