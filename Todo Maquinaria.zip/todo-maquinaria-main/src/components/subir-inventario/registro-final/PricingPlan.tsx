
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Check } from "lucide-react";

export interface PricingPlanData {
  id: string;
  name: string;
  price: string;
  description: string;
  features: string[];
  role: string;
}

interface PricingPlanProps {
  plan: PricingPlanData;
}

export function PricingPlan({ plan }: PricingPlanProps) {
  return (
    <Card className="border-2 border-primary p-4">
      <div className="flex justify-between items-start">
        <h4 className="font-semibold text-lg">{plan.name}</h4>
        {plan.id !== "free" ? (
          <span className="text-primary font-bold text-lg">${plan.price}/mes</span>
        ) : (
          <Badge variant="outline" className="text-green-600 border-green-300 bg-green-50">
            Prueba Gratuita
          </Badge>
        )}
      </div>
      <p className="text-gray-600 text-sm mt-1">{plan.description}</p>
      <ul className="mt-4 space-y-2">
        {plan.features.map((feature, index) => (
          <li key={index} className="flex items-center gap-2">
            <Check className="h-5 w-5 text-primary" />
            <span>{feature}</span>
          </li>
        ))}
      </ul>
    </Card>
  );
}
