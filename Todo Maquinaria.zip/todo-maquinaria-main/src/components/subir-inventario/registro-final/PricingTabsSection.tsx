
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { PricingPlan, PricingPlanData } from "./PricingPlan";

interface PricingTabsSectionProps {
  plans: PricingPlanData[];
  selectedPlan: string;
  onPlanChange: (value: string) => void;
}

export function PricingTabsSection({ plans, selectedPlan, onPlanChange }: PricingTabsSectionProps) {
  return (
    <div className="bg-gray-50 p-6 rounded-lg">
      <h3 className="text-xl font-semibold text-gray-800 mb-4 text-center">
        Selecciona tu Plan
      </h3>
      
      <Tabs 
        defaultValue={selectedPlan} 
        value={selectedPlan}
        onValueChange={onPlanChange}
        className="w-full"
      >
        <TabsList className="grid w-full grid-cols-3 mb-6">
          {plans.map(plan => (
            <TabsTrigger 
              key={plan.id} 
              value={plan.id} 
              className="data-[state=active]:bg-primary data-[state=active]:text-white"
            >
              {plan.name}
              {plan.id === "free" && <Badge className="ml-2 bg-green-500">Gratis</Badge>}
            </TabsTrigger>
          ))}
        </TabsList>
        
        {plans.map(plan => (
          <TabsContent key={plan.id} value={plan.id} className="mt-0">
            <PricingPlan plan={plan} />
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
