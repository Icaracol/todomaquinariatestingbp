
import { MachineFormData } from "@/types/machinery";
import { Card } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

interface PublicationSummaryProps {
  formData: MachineFormData;
  getCategoryName: (id: string) => string;
}

export function PublicationSummary({ formData, getCategoryName }: PublicationSummaryProps) {
  return (
    <div className="space-y-4">
      <h3 className="text-xl font-semibold text-gray-800 text-center">
        Resumen de tu Publicación
      </h3>
      
      <Card className="p-6 border-none shadow-md bg-gradient-to-r from-lime-50 to-green-50">
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div>
              <h4 className="text-sm font-semibold text-gray-500">Nombre</h4>
              <p className="text-lg font-medium">{formData.nombre}</p>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-gray-500">Categoría</h4>
              <p className="text-lg font-medium">{getCategoryName(formData.categoria)}</p>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-gray-500">Año</h4>
              <p className="text-lg font-medium">{formData.año || 'No especificado'}</p>
            </div>
          </div>
          <div className="space-y-4">
            <div>
              <h4 className="text-sm font-semibold text-gray-500">Precio</h4>
              <p className="text-lg font-medium">ARS {formData.precio}</p>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-gray-500">Ubicación</h4>
              <p className="text-lg font-medium">{formData.ubicacion}</p>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-gray-500">Imágenes</h4>
              <p className="text-lg font-medium">{formData.imagenes.length} seleccionadas</p>
            </div>
          </div>
        </div>
        
        {formData.descripcion && (
          <>
            <Separator className="my-4" />
            <div>
              <h4 className="text-sm font-semibold text-gray-500 mb-2">Descripción</h4>
              <p className="text-sm text-gray-700">{formData.descripcion}</p>
            </div>
          </>
        )}
      </Card>
    </div>
  );
}
