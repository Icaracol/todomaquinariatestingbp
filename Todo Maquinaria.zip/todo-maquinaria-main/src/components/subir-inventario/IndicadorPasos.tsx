
import { CheckCircle } from "lucide-react";
import { LucideIcon } from "lucide-react";

interface Paso {
  num: number;
  icon: LucideIcon;
  label: string;
}

interface IndicadorPasosProps {
  pasoActual: number;
  pasos: Paso[];
}

const IndicadorPasos = ({ pasoActual, pasos }: IndicadorPasosProps) => {
  return (
    <div className="relative mb-12">
      {/* Línea de progreso */}
      <div className="absolute top-1/2 left-0 right-0 h-1 bg-gray-200 -translate-y-1/2 rounded-full">
        <div
          className="h-full bg-gradient-to-r from-primary to-blue-500 rounded-full transition-all duration-300 ease-in-out"
          style={{ width: `${((pasoActual - 1) * 50)}%` }}
        />
      </div>
      
      {/* Pasos */}
      <div className="relative flex justify-between">
        {pasos.map(({ num, icon: Icon, label }) => (
          <div key={num} className="text-center">
            <div
              className={`w-14 h-14 rounded-full flex items-center justify-center mb-3 transition-all duration-300 mx-auto
                ${pasoActual >= num 
                  ? "bg-primary text-white shadow-lg shadow-primary/25" 
                  : "bg-gray-100 text-gray-400"
                }`}
            >
              {pasoActual > num ? (
                <CheckCircle className="w-6 h-6 animate-fade-in" />
              ) : (
                <Icon className="w-6 h-6" />
              )}
            </div>
            <span className={`text-sm font-medium block transition-colors duration-300
              ${pasoActual >= num ? "text-primary" : "text-gray-400"}
            `}>
              {label}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default IndicadorPasos;
