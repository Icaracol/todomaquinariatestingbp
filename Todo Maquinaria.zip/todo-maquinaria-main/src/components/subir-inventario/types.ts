
export interface CategoryItem {
  id: string;
  name: string;
  description?: string;
  parent_id: string | null;
  icon?: string;
  seo_keywords?: string[];
  level?: 'main' | 'sub' | 'model'; // New field to classify category hierarchy level
  type?: 'category' | 'brand' | 'model'; // New field to distinguish between categories and brands
}

export interface FormDataType {
  name: string;
  description: string;
  category_id: string;
  year: string;
  price: string;
  location: string;
  specifications: Record<string, string>;
  brand?: string; // Optional field for brands
}

export interface CategoryHierarchy {
  mainCategory: CategoryItem | null;
  subCategory: CategoryItem | null;
  specificModel: CategoryItem | null;
}

// New interface for brands
export interface BrandItem {
  id: string;
  name: string;
  category_ids?: string[]; // Associated category IDs
  logo?: string;
}
