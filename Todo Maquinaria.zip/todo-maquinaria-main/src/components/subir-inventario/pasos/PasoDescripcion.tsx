
import React from "react";
import { DescriptionField } from "../form-fields/DescriptionField";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";
import { CategoryItem } from "../types";

interface PasoDescripcionProps {
  productName: string;
  description: string;
  onChangeDescription: (value: string) => void;
  error?: string;
  onClearError: () => void;
  categoryName: string;
  machineData: {
    name: string;
    category_id: string;
    year: string;
    specifications: Record<string, string>;
  };
  categories: CategoryItem[];
}

export function PasoDescripcion({
  productName,
  description,
  onChangeDescription,
  error,
  onClearError,
  categoryName,
  machineData,
  categories
}: PasoDescripcionProps) {
  return (
    <div className="space-y-4">
      <h3 className="text-xl font-semibold text-gray-800">Danos más características e información</h3>
      <p className="text-gray-600 mb-4">Describe tu {productName} con el mayor detalle posible para atraer a los compradores.</p>
      
      <DescriptionField
        value={description}
        onChange={value => {
          onChangeDescription(value);
          if (error) {
            onClearError();
          }
        }}
        machineData={machineData}
        categories={categories}
      />
      
      <Alert className="bg-blue-50 border-blue-100 mt-6">
        <AlertCircle className="h-4 w-4 text-blue-600" />
        <AlertDescription className="text-blue-700">
          Las descripciones detalladas aumentan las posibilidades de venta hasta en un 50%.
        </AlertDescription>
      </Alert>

      {error && <p className="text-red-500 text-sm mt-1">{error}</p>}
    </div>
  );
}
