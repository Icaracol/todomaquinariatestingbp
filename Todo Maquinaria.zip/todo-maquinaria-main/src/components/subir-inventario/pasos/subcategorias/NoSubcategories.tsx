
import React from "react";
import { Info } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";

interface NoSubcategoriesProps {
  mainCategoryName: string;
  onNext: () => void;
}

export function NoSubcategories({ mainCategoryName, onNext }: NoSubcategoriesProps) {
  return (
    <div className="text-center py-6">
      <Alert className="bg-blue-50 border-blue-100">
        <Info className="h-4 w-4 text-blue-600" />
        <AlertDescription className="text-blue-700">
          No se encontraron subcategorías para esta selección. Se utilizará "{mainCategoryName}" como categoría.
        </AlertDescription>
      </Alert>
      <Button
        type="button"
        variant="outline"
        className="mt-4 text-primary"
        onClick={onNext}
      >
        Continuar con esta categoría
      </Button>
    </div>
  );
}
