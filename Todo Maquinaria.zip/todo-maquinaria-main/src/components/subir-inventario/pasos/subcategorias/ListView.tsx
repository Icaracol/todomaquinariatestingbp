
import React, { useEffect } from "react";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { CategoryItem } from "../../types";

interface ListViewProps {
  subcategories: CategoryItem[];
  selectedCategoryId: string;
  handleSelectCategory: (id: string) => void;
}

export function ListView({ subcategories, selectedCategoryId, handleSelectCategory }: ListViewProps) {
  // Debugging log to track selection state
  useEffect(() => {
    console.log("ListView - Current selectedCategoryId:", selectedCategoryId);
  }, [selectedCategoryId]);

  // Ensure we have a valid selected ID
  const safeSelectedId = selectedCategoryId || "";

  return (
    <RadioGroup 
      value={safeSelectedId}
      onValueChange={(value) => {
        if (!value) return;
        console.log("ListView - Radio onValueChange:", value);
        handleSelectCategory(value);
      }}
      className="space-y-2"
    >
      {subcategories.map(subcat => (
        <div 
          key={subcat.id} 
          className={`flex items-start space-x-2 p-3 rounded-md border transition-all duration-200
            ${safeSelectedId === subcat.id ? 'border-primary bg-primary/5 shadow-sm' : 'border-transparent hover:bg-gray-50'}`}
          onClick={(e) => {
            e.stopPropagation(); // Prevent event bubbling
            console.log("ListView item clicked:", subcat.id);
            handleSelectCategory(subcat.id);
          }}
        >
          <RadioGroupItem 
            value={subcat.id} 
            id={subcat.id} 
            className="mt-1" 
            checked={safeSelectedId === subcat.id}
          />
          <div className="space-y-1 cursor-pointer flex-1">
            <Label 
              htmlFor={subcat.id} 
              className="font-medium cursor-pointer"
            >
              {subcat.name || "Untitled"}
            </Label>
            <p className="text-xs text-gray-500">
              {subcat.description || `${subcat.name || "Untitled"} para aplicaciones industriales.`}
            </p>
          </div>
        </div>
      ))}
    </RadioGroup>
  );
}
