import React, { useEffect, useState } from "react";
import { CategoryItem } from "../../../types";
import { SubcategorySelector } from "../SubcategorySelector";
import { NoSubcategories } from "../NoSubcategories";
import { useToast } from "@/hooks/use-toast";

interface SubcategoryContentProps {
  mainCategoryId: string;
  mainCategoryName: string;
  productName: string;
  selectedCategoryId: string;
  onSelectCategory: (id: string) => void;
  filteredSubcategories: CategoryItem[];
  onClearError: () => void;
  onNext: () => void;
  hasModels?: boolean;
}

export function SubcategoryContent({
  mainCategoryId,
  mainCategoryName,
  productName,
  selectedCategoryId,
  onSelectCategory,
  filteredSubcategories,
  onClearError,
  onNext,
  hasModels = false
}: SubcategoryContentProps) {
  const { toast } = useToast();
  const [localSelectedId, setLocalSelectedId] = useState<string>(selectedCategoryId || "");

  // Keep local state in sync with parent state
  useEffect(() => {
    console.log("SubcategoryContent - Current prop selectedCategoryId:", selectedCategoryId);
    console.log("SubcategoryContent - Current localSelectedId:", localSelectedId);
    
    if (selectedCategoryId && selectedCategoryId !== localSelectedId) {
      console.log("SubcategoryContent - Updating localSelectedId to match prop:", selectedCategoryId);
      setLocalSelectedId(selectedCategoryId);
    } else if (localSelectedId && !selectedCategoryId) {
      // If we have a local selection but parent state doesn't have it,
      // sync parent with our selection
      console.log("SubcategoryContent - Syncing parent with local selection:", localSelectedId);
      onSelectCategory(localSelectedId);
    }
  }, [selectedCategoryId, localSelectedId, onSelectCategory]);

  // If no subcategories are available for this main category, we should use the main category as the selection
  useEffect(() => {
    if (filteredSubcategories.length === 0 && mainCategoryId && !localSelectedId) {
      console.log("SubcategoryContent - No subcategories, using main category as selection:", mainCategoryId);
      setLocalSelectedId(mainCategoryId);
      onSelectCategory(mainCategoryId);
      
      try {
        const savedData = localStorage.getItem('pendingMachinery');
        const currentData = savedData ? JSON.parse(savedData) : {};
        localStorage.setItem('pendingMachinery', JSON.stringify({
          ...currentData,
          category_id: mainCategoryId
        }));
      } catch (error) {
        console.error("Error updating localStorage:", error);
      }
    }
  }, [filteredSubcategories.length, mainCategoryId, localSelectedId, onSelectCategory]);

  const handleSelectCategory = (id: string) => {
    console.log("SubcategoryContent - Selected category:", id);
    
    // Update local state first
    setLocalSelectedId(id);
    
    // Call parent handler with logging for debugging
    if (id) {
      console.log("SubcategoryContent - Calling parent onSelectCategory with:", id);
      onSelectCategory(id);
      
      // Update localStorage
      try {
        const savedData = localStorage.getItem('pendingMachinery');
        const currentData = savedData ? JSON.parse(savedData) : {};
        localStorage.setItem('pendingMachinery', JSON.stringify({
          ...currentData,
          category_id: id
        }));
      } catch (error) {
        console.error("Error updating localStorage:", error);
      }
      
      // Show success toast
      toast({
        title: "Subcategoría seleccionada",
        description: "Se ha seleccionado la subcategoría exitosamente.",
      });
      
      // Clear any errors
      if (onClearError) {
        onClearError();
      }
    } else {
      console.warn("SubcategoryContent - Cannot select empty ID");
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg border shadow-sm">
      {filteredSubcategories.length > 0 ? (
        <SubcategorySelector
          subcategories={filteredSubcategories}
          selectedCategoryId={localSelectedId}
          onSelectCategory={handleSelectCategory}
          mainCategoryId={mainCategoryId}
          productName={productName || ""}
          onClearError={onClearError}
          hasModels={hasModels}
        />
      ) : (
        <NoSubcategories mainCategoryName={mainCategoryName || "Categoría"} onNext={onNext} />
      )}
    </div>
  );
}
