
import React from "react";
import { CategoryBreadcrumb } from "../CategoryBreadcrumb";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Info } from "lucide-react";

interface SubcategoryHeaderProps {
  mainCategoryName: string;
  productName: string;
}

export function SubcategoryHeader({ mainCategoryName, productName }: SubcategoryHeaderProps) {
  return (
    <>
      <CategoryBreadcrumb mainCategoryName={mainCategoryName} />
      
      <h3 className="text-xl font-semibold text-gray-800">
        ¿Qué tipo específico de {mainCategoryName || "equipo"} es?
      </h3>
      <p className="text-gray-600">
        Selecciona la subcategoría específica de tu {productName || mainCategoryName.toLowerCase() || "equipo"}.
      </p>
      
      <Alert variant="default" className="bg-blue-50 border-blue-100">
        <Info className="h-4 w-4" />
        <AlertTitle>Instrucciones</AlertTitle>
        <AlertDescription>
          En este paso debes seleccionar únicamente el tipo de máquina. 
          Las marcas se seleccionarán en un paso posterior.
        </AlertDescription>
      </Alert>
    </>
  );
}
