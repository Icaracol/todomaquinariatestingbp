
import React from "react";
import { ChevronRight } from "lucide-react";

interface CategoryBreadcrumbProps {
  mainCategoryName: string;
}

export function CategoryBreadcrumb({ mainCategoryName }: CategoryBreadcrumbProps) {
  return (
    <div className="bg-gray-50 p-3 rounded-lg flex items-center text-sm text-gray-600 mb-2">
      <span className="font-medium">{mainCategoryName}</span>
      <ChevronRight className="w-4 h-4 mx-1" />
      <span className="text-primary">Selecciona una subcategoría</span>
    </div>
  );
}
