
import { useState, useEffect, useCallback, useMemo } from "react";
import { useMachineryAI } from "@/hooks/use-machinery-ai";
import { useToast } from "@/hooks/use-toast";
import { CategoryItem } from "../../../types";

interface UseSubcategoriasProps {
  productName: string;
  mainCategoryId: string | null;
  onSelectCategory: (id: string) => void;
  onClearError?: () => void;
  selectedCategoryId?: string;
}

export function useSubcategorias({
  productName,
  mainCategoryId,
  onSelectCategory,
  onClearError,
  selectedCategoryId = ""
}: UseSubcategoriasProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [viewMode, setViewMode] = useState<"grid" | "list">(
    () => (localStorage.getItem("subcategoryViewMode") as "grid" | "list") || "grid"
  );
  const { suggestSubcategory, isLoading } = useMachineryAI();
  const { toast } = useToast();
  const [suggestion, setSuggestion] = useState<{id: string | null, name: string, confidence: number} | null>(null);
  
  // Use the prop for initial state and track it
  const [localSelectedId, setLocalSelectedId] = useState<string>(selectedCategoryId || "");

  // Track last search to improve user experience
  const [lastSearches, setLastSearches] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem("recentSubcategorySearches");
      return saved ? JSON.parse(saved) : [];
    } catch (error) {
      return [];
    }
  });

  // Save view mode preference to localStorage
  useEffect(() => {
    localStorage.setItem("subcategoryViewMode", viewMode);
  }, [viewMode]);

  // Sync local state with prop when it changes from outside
  useEffect(() => {
    if (selectedCategoryId && selectedCategoryId !== localSelectedId) {
      setLocalSelectedId(selectedCategoryId);
    }
  }, [selectedCategoryId, localSelectedId]);

  // Save recent searches
  useEffect(() => {
    if (lastSearches.length > 0) {
      localStorage.setItem("recentSubcategorySearches", JSON.stringify(lastSearches));
    }
  }, [lastSearches]);

  // Make handleSelectCategory a useCallback to prevent recreation on each render
  const handleSelectCategory = useCallback((id: string) => {
    if (!id) {
      console.error("useSubcategorias - Attempted to select a subcategory with an empty ID");
      return;
    }
    
    // Update local state first
    setLocalSelectedId(id);
    
    // Call parent callback
    onSelectCategory(id);
    
    if (onClearError) {
      onClearError();
    }
    
    // Show success toast
    toast({
      title: "Subcategoría seleccionada",
      description: "Ahora puedes continuar al siguiente paso.",
    });
  }, [onSelectCategory, onClearError, toast]);

  const handleGetSuggestion = async () => {
    if (!productName?.trim() || !mainCategoryId) {
      toast({
        title: "Información incompleta",
        description: "Se necesita el nombre de la máquina y una categoría principal",
        variant: "destructive"
      });
      return;
    }

    try {
      const result = await suggestSubcategory(productName, mainCategoryId);
      if (result) {
        setSuggestion(result);
        
        if (result.id) {
          toast({
            title: "Subcategoría sugerida",
            description: `El asistente IA sugiere: ${result.name}`,
          });
        } else {
          toast({
            title: "Sugerencia aproximada",
            description: "No se encontró una coincidencia exacta con: " + result.name,
          });
        }
      }
    } catch (error) {
      console.error("Error al sugerir subcategoría:", error);
      toast({
        title: "Error al sugerir subcategoría",
        description: "No se pudo obtener una sugerencia en este momento",
        variant: "destructive"
      });
    }
  };

  const applySuggestion = useCallback(() => {
    if (suggestion?.id) {
      handleSelectCategory(suggestion.id);
      setSuggestion(null);
    }
  }, [suggestion, handleSelectCategory]);

  // Enhanced search functionality with improved relevance scoring
  const filterSubcategories = useCallback((subcategories: CategoryItem[]) => {
    if (!subcategories) return [];
    
    // Filter out any brands (if type property exists)
    const categoriesOnly = subcategories.filter(cat => 
      (!cat.type || cat.type === 'category') && 
      (!mainCategoryId || cat.parent_id === mainCategoryId)
    );
    
    // Then apply search filter with improved algorithm
    if (!searchTerm) return categoriesOnly;
    
    // Add to recent searches if not already there
    if (searchTerm.trim().length > 2 && !lastSearches.includes(searchTerm)) {
      const updatedSearches = [searchTerm, ...lastSearches.slice(0, 4)];
      setLastSearches(updatedSearches);
    }
    
    const searchTermLower = searchTerm.toLowerCase();
    const searchWords = searchTermLower.split(/\s+/).filter(word => word.length > 1);
    
    return categoriesOnly.filter(cat => {
      // Calculate relevance score for each category
      let relevanceScore = 0;
      
      // Exact name match (highest priority)
      if (cat.name?.toLowerCase() === searchTermLower) {
        relevanceScore += 10;
      }
      
      // Name contains search term
      if (cat.name?.toLowerCase().includes(searchTermLower)) {
        relevanceScore += 5;
      }
      
      // Words in name match search words
      const nameLower = cat.name?.toLowerCase() || "";
      searchWords.forEach(word => {
        if (nameLower.includes(word)) {
          relevanceScore += 3;
        }
      });
      
      // Description match
      if (cat.description?.toLowerCase().includes(searchTermLower)) {
        relevanceScore += 2;
      }
      
      // SEO keywords match
      if (cat.seo_keywords?.some(keyword => 
        keyword.toLowerCase().includes(searchTermLower)
      )) {
        relevanceScore += 3;
      }
      
      return relevanceScore > 0;
    }).sort((a, b) => {
      // Sort by relevance (exact matches first)
      const aNameLower = a.name?.toLowerCase() || "";
      const bNameLower = b.name?.toLowerCase() || "";
      
      // Exact matches first
      const aExactMatch = aNameLower === searchTermLower;
      const bExactMatch = bNameLower === searchTermLower;
      
      if (aExactMatch && !bExactMatch) return -1;
      if (!aExactMatch && bExactMatch) return 1;
      
      // Then by starts with
      const aStartsWith = aNameLower.startsWith(searchTermLower);
      const bStartsWith = bNameLower.startsWith(searchTermLower);
      
      if (aStartsWith && !bStartsWith) return -1;
      if (!aStartsWith && bStartsWith) return 1;
      
      // Then alphabetically
      return aNameLower.localeCompare(bNameLower);
    });
  }, [searchTerm, mainCategoryId, lastSearches]);

  // Group subcategories (using the first word of the name as a grouper)
  const groupSubcategories = useCallback((subcategories: CategoryItem[]) => {
    if (!subcategories) return {};
    
    return subcategories.reduce((groups, cat) => {
      // Try to use a more meaningful group name
      const groupName = cat.name?.split(" ")[0] || "Otros";
      if (!groups[groupName]) {
        groups[groupName] = [];
      }
      groups[groupName].push(cat);
      return groups;
    }, {} as Record<string, CategoryItem[]>);
  }, []);

  // Enhanced search features
  const handleClearSearch = useCallback(() => {
    setSearchTerm("");
  }, []);

  // Computed property to check if suggestion is disabled
  const disableSuggestion = useMemo(() => {
    return !productName?.trim() || !mainCategoryId;
  }, [productName, mainCategoryId]);

  return {
    searchTerm,
    setSearchTerm,
    viewMode,
    setViewMode,
    suggestion,
    isLoading,
    handleSelectCategory,
    handleGetSuggestion,
    applySuggestion,
    filterSubcategories,
    groupSubcategories,
    localSelectedId,
    handleClearSearch,
    disableSuggestion,
    lastSearches
  };
}
