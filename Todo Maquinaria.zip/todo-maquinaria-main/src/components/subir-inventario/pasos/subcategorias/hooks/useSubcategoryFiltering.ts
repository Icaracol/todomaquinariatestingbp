
import { useMemo } from "react";
import { CategoryItem } from "../../../types";

interface UseSubcategoryFilteringProps {
  subcategories: CategoryItem[];
  mainCategoryId: string | null;
}

export function useSubcategoryFiltering({
  subcategories,
  mainCategoryId
}: UseSubcategoryFilteringProps) {
  // Filter subcategories to only include those that belong to the selected main category
  // and are NOT brands (if type property exists)
  const filteredSubcategories = useMemo(() => {
    return subcategories.filter(
      subcat => !subcat.type || subcat.type === 'category'
    );
  }, [subcategories]);

  // Check if there are subcategories
  const hasSubcategories = useMemo(() => {
    return filteredSubcategories.length > 0;
  }, [filteredSubcategories]);

  return {
    filteredSubcategories,
    hasSubcategories
  };
}
