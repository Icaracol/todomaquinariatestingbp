
import React from "react";
import { Tag, ChevronDown } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { GridView } from "./GridView";
import { ListView } from "./ListView";
import { CategoryItem } from "../../types";

interface CategoryGroupProps {
  groupName: string;
  subcategories: CategoryItem[];
  viewMode: "grid" | "list";
  selectedCategoryId: string;
  handleSelectCategory: (id: string) => void;
}

export function CategoryGroup({ 
  groupName, 
  subcategories, 
  viewMode, 
  selectedCategoryId, 
  handleSelectCategory 
}: CategoryGroupProps) {
  return (
    <Collapsible defaultOpen={true} className="border rounded-md overflow-hidden">
      <CollapsibleTrigger className="flex items-center justify-between w-full p-3 bg-gray-50 hover:bg-gray-100">
        <div className="flex items-center gap-2">
          <Tag className="h-4 w-4 text-primary" />
          <h4 className="font-medium">{groupName}</h4>
          <Badge variant="outline">{subcategories.length}</Badge>
        </div>
        <ChevronDown className="h-4 w-4" />
      </CollapsibleTrigger>
      <CollapsibleContent>
        <div className="p-3">
          {viewMode === "grid" ? (
            <GridView 
              subcategories={subcategories}
              selectedCategoryId={selectedCategoryId}
              handleSelectCategory={handleSelectCategory}
            />
          ) : (
            <ListView 
              subcategories={subcategories}
              selectedCategoryId={selectedCategoryId}
              handleSelectCategory={handleSelectCategory}
            />
          )}
        </div>
      </CollapsibleContent>
    </Collapsible>
  );
}
