
import React from "react";
import { Search, Grid, Layers, Wand2, Loader2, X, Clock } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

interface SearchBarProps {
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  viewMode: "grid" | "list";
  setViewMode: (mode: "grid" | "list") => void;
  handleGetSuggestion: () => void;
  isLoading: boolean;
  disableSuggestion: boolean;
  lastSearches?: string[];
}

export function SearchBar({
  searchTerm,
  setSearchTerm,
  viewMode,
  setViewMode,
  handleGetSuggestion,
  isLoading,
  disableSuggestion,
  lastSearches = []
}: SearchBarProps) {
  const handleClearSearch = () => {
    setSearchTerm("");
  };

  const hasRecentSearches = lastSearches.length > 0;

  return (
    <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
      <div className="relative flex-1 w-full">
        <Popover>
          <PopoverTrigger asChild>
            <div className="relative flex-1 w-full">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                type="text"
                placeholder="Buscar subcategoría..."
                className="pl-10 pr-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              {searchTerm && (
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute right-1 top-1/2 transform -translate-y-1/2 h-8 w-8"
                  onClick={handleClearSearch}
                  aria-label="Limpiar búsqueda"
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
          </PopoverTrigger>
          {hasRecentSearches && (
            <PopoverContent className="w-[var(--radix-popover-trigger-width)] p-0" align="start">
              <div className="py-2">
                <div className="px-3 py-2 text-xs font-medium text-gray-500 border-b">
                  Búsquedas recientes
                </div>
                <div className="max-h-[200px] overflow-y-auto">
                  {lastSearches.map((term, index) => (
                    <button
                      key={index}
                      className="flex items-center w-full px-3 py-2 text-sm hover:bg-gray-100 text-left"
                      onClick={() => setSearchTerm(term)}
                    >
                      <Clock className="h-3.5 w-3.5 text-gray-500 mr-2" />
                      {term}
                    </button>
                  ))}
                </div>
              </div>
            </PopoverContent>
          )}
        </Popover>
      </div>
      
      <div className="flex gap-2">
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                type="button"
                variant="outline"
                size="icon"
                className={viewMode === "grid" ? "bg-gray-100" : ""}
                onClick={() => setViewMode("grid")}
              >
                <Grid className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Vista de cuadrícula</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>

        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                type="button"
                variant="outline"
                size="icon"
                className={viewMode === "list" ? "bg-gray-100" : ""}
                onClick={() => setViewMode("list")}
              >
                <Layers className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Vista de lista</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>

        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleGetSuggestion}
                disabled={isLoading || disableSuggestion}
                className="flex items-center gap-2 ml-2"
              >
                {isLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Wand2 className="h-4 w-4" />
                )}
                <span className="hidden sm:inline">Sugerir</span>
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>{disableSuggestion 
                ? "Completa el nombre de la máquina y categoría principal" 
                : "Sugerir subcategoría con IA"}
              </p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      </div>
    </div>
  );
}
