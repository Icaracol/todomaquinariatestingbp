
import React from "react";
import { HelpCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

interface NoCategorySelectedProps {
  onNext: () => void;
}

export function NoCategorySelected({ onNext }: NoCategorySelectedProps) {
  return (
    <div className="space-y-4">
      <h3 className="text-xl font-semibold text-gray-800">Selecciona una subcategoría</h3>
      <div className="bg-amber-50 border border-amber-200 p-6 rounded-lg text-center space-y-3">
        <HelpCircle className="w-10 h-10 text-amber-500 mx-auto" />
        <p className="text-amber-800 font-medium">Primero debes seleccionar una categoría principal</p>
        <p className="text-amber-700">
          Vuelve al paso anterior para seleccionar una categoría principal y poder ver las subcategorías disponibles.
        </p>
        <Button 
          variant="outline" 
          className="mt-2 text-amber-800 border-amber-300 hover:bg-amber-100"
          onClick={onNext}
        >
          Volver a categorías principales
        </Button>
      </div>
    </div>
  );
}
