
import React from "react";
import { Button } from "@/components/ui/button";
import { Wand2 } from "lucide-react";

interface SuggestionAlertProps {
  suggestion: {id: string | null, name: string, confidence: number} | null;
  applySuggestion: () => void;
}

export function SuggestionAlert({ suggestion, applySuggestion }: SuggestionAlertProps) {
  if (!suggestion) return null;

  return (
    <div className="bg-blue-50 border border-blue-100 p-4 rounded-md animate-in fade-in">
      <div className="flex justify-between items-center">
        <div>
          <div className="flex items-center gap-2">
            <Wand2 className="h-4 w-4 text-blue-600" />
            <p className="text-blue-800 font-medium">Sugerencia del asistente IA:</p>
          </div>
          <p className="text-blue-700 font-semibold mt-1">{suggestion.name}</p>
          {suggestion.confidence > 0.7 ? (
            <span className="inline-block px-2 py-0.5 bg-green-100 text-green-800 text-xs rounded-full mt-1">
              Alta confianza
            </span>
          ) : suggestion.confidence > 0.4 ? (
            <span className="inline-block px-2 py-0.5 bg-yellow-100 text-yellow-800 text-xs rounded-full mt-1">
              Confianza moderada
            </span>
          ) : (
            <span className="inline-block px-2 py-0.5 bg-orange-100 text-orange-800 text-xs rounded-full mt-1">
              Baja confianza
            </span>
          )}
        </div>
        <Button
          type="button"
          variant="primary"
          size="sm"
          onClick={applySuggestion}
          disabled={!suggestion.id}
          className={!suggestion.id ? "opacity-50 cursor-not-allowed" : ""}
        >
          {suggestion.id ? "Aplicar sugerencia" : "No disponible"}
        </Button>
      </div>
      
      {!suggestion.id && (
        <p className="text-sm text-blue-600 mt-2">
          No se ha encontrado una subcategoría exacta para esta sugerencia. 
          Intenta buscar manualmente o con otros términos.
        </p>
      )}
    </div>
  );
}
