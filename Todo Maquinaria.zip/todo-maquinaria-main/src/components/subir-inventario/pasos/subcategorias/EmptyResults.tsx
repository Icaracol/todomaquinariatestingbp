
import React from "react";
import { Filter, X, Search, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

interface EmptyResultsProps {
  onClearSearch?: () => void;
  searchTerm?: string;
}

export function EmptyResults({ onClearSearch, searchTerm }: EmptyResultsProps) {
  return (
    <div className="text-center py-8 bg-gray-50 rounded-lg border border-gray-100">
      <div className="flex justify-center items-center mb-3">
        <div className="relative">
          <Search className="h-12 w-12 text-gray-300" />
          <X className="h-6 w-6 text-gray-300 absolute bottom-0 right-0" />
        </div>
      </div>
      
      <h4 className="text-gray-600 font-medium mb-2">No se encontraron resultados</h4>
      <p className="text-gray-500 text-sm mb-4">
        No hay subcategorías que coincidan con "<span className="font-medium">{searchTerm}</span>"
      </p>
      
      {onClearSearch && (
        <div className="flex justify-center gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={onClearSearch}
            className="mt-2"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Volver a todos
          </Button>
        </div>
      )}
      
      <div className="mt-4 text-xs text-gray-500 max-w-xs mx-auto">
        Intenta usar términos más generales o verifica la ortografía
      </div>
    </div>
  );
}
