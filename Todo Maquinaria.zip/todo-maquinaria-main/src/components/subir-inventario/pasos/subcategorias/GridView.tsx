
import React, { useEffect } from "react";
import { Check } from "lucide-react";
import { CategoryItem } from "../../types";

interface GridViewProps {
  subcategories: CategoryItem[];
  selectedCategoryId: string;
  handleSelectCategory: (id: string) => void;
}

export function GridView({ subcategories, selectedCategoryId, handleSelectCategory }: GridViewProps) {
  // Debugging log to track selection state
  useEffect(() => {
    console.log("GridView - Current selectedCategoryId:", selectedCategoryId);
  }, [selectedCategoryId]);

  // Ensure we have a valid selected ID
  const safeSelectedId = selectedCategoryId || "";

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
      {subcategories.map(subcat => (
        <div
          key={subcat.id}
          className={`p-4 rounded-md border-2 cursor-pointer transition-all duration-200 relative
            ${safeSelectedId === subcat.id 
              ? 'border-primary bg-primary/5 shadow-md' 
              : 'border-gray-100 hover:border-gray-300 hover:shadow'}`}
          onClick={(e) => {
            e.stopPropagation(); // Prevent event bubbling
            console.log("GridView - Clicking on subcategory:", subcat.id);
            handleSelectCategory(subcat.id);
          }}
        >
          <div className="flex justify-between items-start mb-2">
            <h5 className="font-medium">{subcat.name || "Untitled"}</h5>
            {safeSelectedId === subcat.id && (
              <div className="bg-primary text-white p-1 rounded-full animate-in fade-in duration-300">
                <Check className="h-3 w-3" />
              </div>
            )}
          </div>
          <p className="text-sm text-gray-500 line-clamp-2">
            {subcat.description || `${subcat.name || "Untitled"} para aplicaciones industriales.`}
          </p>
          
          {/* Overlay de selección para mejor feedback visual */}
          {safeSelectedId === subcat.id && (
            <div className="absolute inset-0 border-2 border-primary rounded-md pointer-events-none"></div>
          )}
        </div>
      ))}
    </div>
  );
}
