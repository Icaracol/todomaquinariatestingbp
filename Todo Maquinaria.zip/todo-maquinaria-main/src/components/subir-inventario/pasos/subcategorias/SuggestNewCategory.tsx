
import React, { useState } from "react";
import { Info, Plus, X } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { 
  Dialog, 
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

interface SuggestNewCategoryProps {
  hasModels: boolean;
}

export function SuggestNewCategory({
  hasModels
}: SuggestNewCategoryProps) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name.trim()) {
      toast({
        title: "Nombre requerido",
        description: "Por favor ingresa un nombre para la nueva categoría",
        variant: "destructive"
      });
      return;
    }
    
    // Here we would typically send this to the backend
    toast({
      title: "Sugerencia enviada",
      description: "Tu sugerencia de nueva categoría ha sido enviada para revisión. Gracias por contribuir.",
    });
    
    setOpen(false);
    setName("");
    setDescription("");
  };

  return (
    <div className="mt-4 pt-4 border-t border-dashed">
      <Alert className="bg-blue-50 border-blue-100">
        <Info className="h-4 w-4 text-blue-600" />
        <AlertDescription className="text-blue-700 flex justify-between items-center">
          <span>¿No encuentras la {hasModels ? "marca/modelo" : "subcategoría"} específica?</span>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm" className="text-blue-600 border-blue-200 bg-slate-50">
                <Plus className="h-3.5 w-3.5 mr-1" />
                Sugerir nueva
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Sugerir nueva {hasModels ? "marca/modelo" : "subcategoría"}</DialogTitle>
                <DialogDescription>
                  Por favor proporciona los detalles de la {hasModels ? "marca/modelo" : "subcategoría"} que quieres sugerir.
                  La revisaremos y la añadiremos si es apropiada.
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit}>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="name" className="text-right">
                      Nombre
                    </Label>
                    <Input
                      id="name"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="col-span-3"
                      placeholder={hasModels ? "Ej: Caterpillar 950G" : "Ej: Retroexcavadoras"}
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="description" className="text-right">
                      Descripción
                    </Label>
                    <Textarea
                      id="description"
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      className="col-span-3"
                      placeholder="Breve descripción (opcional)"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <DialogClose asChild>
                    <Button variant="outline" type="button">
                      <X className="h-4 w-4 mr-1" />
                      Cancelar
                    </Button>
                  </DialogClose>
                  <Button type="submit">
                    <Plus className="h-4 w-4 mr-1" />
                    Enviar sugerencia
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </AlertDescription>
      </Alert>
    </div>
  );
}
