
import React, { useEffect, useState } from "react";
import { CategoryItem } from "../../types";
import { useSubcategorias } from "./hooks/useSubcategorias";
import { SearchBar } from "./SearchBar";
import { SuggestionAlert } from "./SuggestionAlert";
import { EmptyResults } from "./EmptyResults";
import { CategoryGroup } from "./CategoryGroup";
import { SuggestNewCategory } from "./SuggestNewCategory";
import { GridView } from "./GridView";
import { ListView } from "./ListView";

interface SubcategorySelectorProps {
  subcategories: CategoryItem[];
  selectedCategoryId: string;
  onSelectCategory: (id: string) => void;
  mainCategoryId: string;
  productName: string;
  onClearError?: () => void;
  hasModels?: boolean;
}

export function SubcategorySelector({
  subcategories,
  selectedCategoryId,
  onSelectCategory,
  mainCategoryId,
  productName,
  onClearError,
  hasModels = false
}: SubcategorySelectorProps) {
  // Initialize selected ID from localStorage or props
  const [internalSelectedId, setInternalSelectedId] = useState<string>(() => {
    try {
      const savedData = localStorage.getItem('pendingMachinery');
      if (savedData) {
        const parsed = JSON.parse(savedData);
        // Use saved category_id if it exists and is a subcategory of the current main category
        if (parsed.category_id) {
          const isSubcategoryOfMain = subcategories.some(cat => 
            cat.id === parsed.category_id && cat.parent_id === mainCategoryId
          );
          
          if (isSubcategoryOfMain) {
            return parsed.category_id;
          }
        }
      }
      
      // Use the provided selectedCategoryId if localStorage doesn't have valid data
      if (selectedCategoryId) {
        return selectedCategoryId;
      }
      
      return "";
    } catch (error) {
      console.error("Error parsing localStorage data:", error);
      return selectedCategoryId || "";
    }
  });
  
  const {
    searchTerm,
    setSearchTerm,
    viewMode,
    setViewMode,
    suggestion,
    isLoading,
    handleGetSuggestion,
    applySuggestion,
    filterSubcategories,
    disableSuggestion,
    localSelectedId: hookSelectedId,
    handleClearSearch,
    lastSearches
  } = useSubcategorias({
    productName,
    mainCategoryId,
    onSelectCategory,
    onClearError,
    selectedCategoryId: internalSelectedId
  });

  // Synchronize internal state with hook state and props
  useEffect(() => {
    if (hookSelectedId && hookSelectedId !== internalSelectedId) {
      setInternalSelectedId(hookSelectedId);
    }
  }, [hookSelectedId, internalSelectedId]);

  useEffect(() => {
    if (selectedCategoryId && selectedCategoryId !== internalSelectedId) {
      setInternalSelectedId(selectedCategoryId);
    }
  }, [selectedCategoryId, internalSelectedId]);

  const filteredSubcategories = filterSubcategories(subcategories);

  const handleCategorySelect = (id: string) => {
    if (!id) {
      console.warn("SubcategorySelector - Attempted to select category with empty ID");
      return;
    }
    
    // Update internal state
    setInternalSelectedId(id);
    
    // Update localStorage
    try {
      const savedData = localStorage.getItem('pendingMachinery');
      const currentData = savedData ? JSON.parse(savedData) : {};
      const updatedData = {
        ...currentData,
        category_id: id
      };
      localStorage.setItem('pendingMachinery', JSON.stringify(updatedData));
    } catch (error) {
      console.error("Error updating localStorage:", error);
    }
    
    // Call parent handler
    onSelectCategory(id);
    
    // Clear any validation errors
    if (onClearError) {
      onClearError();
    }
  };

  // If we have a selection but parent doesn't know, update parent
  useEffect(() => {
    if (internalSelectedId && internalSelectedId !== selectedCategoryId) {
      onSelectCategory(internalSelectedId);
    }
  }, [internalSelectedId, selectedCategoryId, onSelectCategory]);

  return (
    <div className="space-y-6">
      <SearchBar
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        viewMode={viewMode}
        setViewMode={setViewMode}
        handleGetSuggestion={handleGetSuggestion}
        isLoading={isLoading}
        disableSuggestion={disableSuggestion}
        lastSearches={lastSearches}
      />

      <SuggestionAlert 
        suggestion={suggestion} 
        applySuggestion={applySuggestion} 
      />

      {filteredSubcategories.length > 0 ? (
        <div className="mt-6">
          <h4 className="text-base font-medium text-gray-700 mb-4">
            Subcategorías disponibles 
            {searchTerm && <span className="text-sm font-normal text-gray-500 ml-1">
              (filtradas por "<span className="font-medium">{searchTerm}</span>")
            </span>}
          </h4>
          
          {viewMode === "grid" ? (
            <GridView 
              subcategories={filteredSubcategories}
              selectedCategoryId={internalSelectedId}
              handleSelectCategory={handleCategorySelect}
            />
          ) : (
            <ListView 
              subcategories={filteredSubcategories}
              selectedCategoryId={internalSelectedId}
              handleSelectCategory={handleCategorySelect}
            />
          )}
        </div>
      ) : (
        searchTerm ? (
          <EmptyResults 
            searchTerm={searchTerm} 
            onClearSearch={handleClearSearch} 
          />
        ) : (
          <div className="text-center p-8">
            <p className="text-gray-500">No hay subcategorías disponibles para esta categoría principal.</p>
          </div>
        )
      )}

      <SuggestNewCategory hasModels={hasModels} />
    </div>
  );
}
