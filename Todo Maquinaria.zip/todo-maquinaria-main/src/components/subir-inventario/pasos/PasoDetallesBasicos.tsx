
import React from "react";
import { YearInput } from "../components/detalles/YearInput";
import { PriceInput } from "../components/detalles/PriceInput";
import { LocationInput } from "../components/detalles/LocationInput";
import { usePriceSuggestion } from "../hooks/usePriceSuggestion";

interface PasoDetallesBasicosProps {
  categoryName: string;
  year: string;
  price: string;
  location: string;
  onChangeYear: (value: string) => void;
  onChangePrice: (value: string) => void;
  onChangeLocation: (value: string) => void;
  yearError?: string;
  priceError?: string;
  onClearYearError: () => void;
  onClearPriceError: () => void;
  productName: string;
}

export function PasoDetallesBasicos({
  categoryName,
  year,
  price,
  location,
  onChangeYear,
  onChangePrice,
  onChangeLocation,
  yearError,
  priceError,
  onClearYearError,
  onClearPriceError,
  productName
}: PasoDetallesBasicosProps) {
  // Use the extracted price suggestion hook
  const {
    suggestion,
    isLoading,
    handleGetPriceSuggestion,
    applyPriceSuggestion
  } = usePriceSuggestion({
    productName,
    year,
    categoryName,
    onChangePrice,
    onClearPriceError
  });

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-xl font-semibold text-gray-800">Detalles básicos de la {categoryName}</h3>
        <p className="text-gray-600 mb-4">Proporciona información esencial sobre tu maquinaria.</p>
      </div>
      
      <div className="space-y-6">
        <YearInput
          year={year}
          onChangeYear={onChangeYear}
          yearError={yearError}
          onClearYearError={onClearYearError}
        />
        
        <PriceInput
          price={price}
          onChangePrice={onChangePrice}
          priceError={priceError}
          onClearPriceError={onClearPriceError}
          suggestion={suggestion}
          isLoading={isLoading}
          onGetSuggestion={handleGetPriceSuggestion}
          onApplySuggestion={applyPriceSuggestion}
          productName={productName}
        />
        
        <LocationInput
          location={location}
          onChangeLocation={onChangeLocation}
        />
      </div>
    </div>
  );
}
