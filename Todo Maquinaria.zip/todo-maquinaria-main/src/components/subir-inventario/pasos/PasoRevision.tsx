import React from "react";
import { AlertCircle } from "lucide-react";

interface PasoRevisionProps {
  name: string;
  categoryName: string;
  brand?: string; // Add the brand field
  year: string;
  price: string;
  location: string;
  description: string;
}

export function PasoRevision({
  name,
  categoryName,
  brand,
  year,
  price,
  location,
  description
}: PasoRevisionProps) {
  const formatPrice = (price: string) => {
    if (!price) return "No especificado";
    const numPrice = parseFloat(price);
    return numPrice.toLocaleString('es-ES');
  };

  return (
    <div className="space-y-6">
      <h3 className="text-xl font-semibold text-gray-800">Revisión de la Maquinaria</h3>
      <p className="text-gray-600">Revisa los detalles de tu maquinaria antes de publicarla.</p>

      <div className="bg-white p-6 rounded-lg border shadow-sm">
        <div className="space-y-4">
          <div className="border-b pb-3">
            <h4 className="text-lg font-semibold text-gray-800 mb-2">{name}</h4>
            <div className="flex flex-wrap items-center gap-2 text-sm text-gray-600">
              <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium">
                {categoryName}
              </span>
              {brand && (
                <span className="bg-purple-100 text-purple-800 px-2 py-1 rounded-full text-xs font-medium">
                  {brand}
                </span>
              )}
              {year && (
                <span className="bg-gray-100 text-gray-800 px-2 py-1 rounded-full text-xs font-medium">
                  Año {year}
                </span>
              )}
            </div>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <h5 className="text-sm font-medium text-gray-500">Precio</h5>
              <p className="text-2xl font-bold text-primary">${formatPrice(price)}</p>
            </div>
            
            <div>
              <h5 className="text-sm font-medium text-gray-500">Ubicación</h5>
              <p className="text-base">{location || "No especificada"}</p>
            </div>
          </div>
          
          <div>
            <h5 className="text-sm font-medium text-gray-500 mb-2">Descripción</h5>
            <div className="text-gray-700 bg-gray-50 p-3 rounded-md">
              {description ? (
                <p>{description}</p>
              ) : (
                <p className="italic text-gray-400">No se ha proporcionado una descripción</p>
              )}
            </div>
          </div>
        </div>
      </div>
      
      <div className="border p-4 rounded-md bg-yellow-50 border-yellow-100">
        <h4 className="font-medium text-yellow-800 mb-2 flex items-center">
          <AlertCircle className="h-4 w-4 mr-2" />
          Próximo paso: Imágenes
        </h4>
        <p className="text-sm text-yellow-700">
          En el siguiente paso podrás subir fotografías de tu maquinaria para completar la publicación.
        </p>
      </div>
    </div>
  );
}
