
import React from "react";
import { Check } from "lucide-react";

interface ProgressBarProps {
  activeStep: number;
  totalSteps: number;
}

export function ProgressBar({ activeStep, totalSteps }: ProgressBarProps) {
  return (
    <div className="mb-8">
      <div className="flex justify-between mb-2">
        {Array.from({ length: totalSteps }).map((_, index) => (
          <div 
            key={index}
            className={`w-8 h-8 rounded-full flex items-center justify-center ${
              activeStep > index + 1 ? 'bg-green-500 text-white' : 
              activeStep === index + 1 ? 'bg-primary text-white' : 
              'bg-gray-200 text-gray-500'
            }`}
          >
            {activeStep > index + 1 ? <Check className="w-4 h-4" /> : index + 1}
          </div>
        ))}
      </div>
      <div className="w-full bg-gray-200 h-2 rounded-full overflow-hidden">
        <div 
          className="h-full bg-primary transition-all duration-300"
          style={{ width: `${(activeStep / totalSteps) * 100}%` }}
        ></div>
      </div>
    </div>
  );
}
