
import { FormField } from "../form-fields/FormField";
import React, { useState, useEffect } from "react";
import { useMachineryAI } from "@/hooks/use-machinery-ai";
import { Button } from "@/components/ui/button";
import { Wand2, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface PasoNombreMaquinaProps {
  name: string;
  onChange: (value: string) => void;
  error?: string;
  onClearError: () => void;
}

export function PasoNombreMaquina({
  name,
  onChange,
  error,
  onClearError
}: PasoNombreMaquinaProps) {
  const { improveMachineTitle, isLoading } = useMachineryAI();
  const { toast } = useToast();
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [retryCount, setRetryCount] = useState<number>(0);

  // Ensure name is validated on change
  useEffect(() => {
    if (name && name.trim() && error) {
      console.log("PasoNombreMaquina - Name changed, clearing error:", name);
      onClearError();
    }
  }, [name, error, onClearError]);

  const handleImproveTitle = async () => {
    if (!name.trim()) {
      toast({
        title: "Necesitas un nombre inicial",
        description: "Por favor, escribe primero un nombre básico para la máquina",
        variant: "destructive"
      });
      return;
    }

    try {
      toast({
        title: "Generando sugerencia",
        description: "Estamos mejorando el título con IA...",
      });

      const improvedTitle = await improveMachineTitle(name);
      
      if (improvedTitle) {
        // Agregar el título mejorado a las sugerencias
        setSuggestions(prev => [improvedTitle, ...prev].slice(0, 3));
        toast({
          title: "Sugerencia generada",
          description: "Se ha generado un título mejorado que puedes utilizar"
        });
        
        // Reiniciar el contador de intentos si tuvimos éxito
        setRetryCount(0);
      } else if (retryCount < 2) {
        // Si falló pero no hemos intentado demasiadas veces, intentar de nuevo
        setRetryCount(prev => prev + 1);
        toast({
          title: "Intentando de nuevo",
          description: "Hubo un problema, intentando generar otra sugerencia..."
        });
        
        // Esperar un momento antes de reintentar
        setTimeout(() => handleImproveTitle(), 1500);
      } else {
        // Si hemos intentado varias veces y sigue fallando
        toast({
          title: "No se pudo generar sugerencia",
          description: "Por favor, intenta más tarde o contacta con soporte",
          variant: "destructive"
        });
        
        // Reiniciar el contador para futuros intentos
        setRetryCount(0);
      }
    } catch (error) {
      console.error("Error al mejorar el título:", error);
      toast({
        title: "Error al generar sugerencia",
        description: "No se pudo conectar con el asistente IA, por favor intenta más tarde",
        variant: "destructive"
      });
    }
  };

  const applySuggestion = (suggestion: string) => {
    console.log("PasoNombreMaquina - Applying suggestion:", suggestion);
    onChange(suggestion);
    if (error) {
      onClearError();
    }

    // Eliminar la sugerencia aplicada de la lista
    setSuggestions(prev => prev.filter(s => s !== suggestion));
    
    toast({
      title: "Título aplicado",
      description: "Se ha aplicado el título sugerido con éxito"
    });
  };

  return (
    <div className="space-y-4">
      <h3 className="text-xl font-semibold text-gray-800">¿Qué máquina deseas vender?</h3>
      <p className="text-gray-600">Ingresa el nombre o modelo de la maquinaria que quieres publicar.</p>
      
      <div className="relative">
        <FormField 
          id="name" 
          label="" 
          value={name} 
          onChange={value => {
            console.log("PasoNombreMaquina - Name input changed:", value);
            onChange(value);
            if (error) {
              onClearError();
            }
          }} 
          placeholder="Ej: Excavadora Caterpillar 320" 
          required 
        />

        <div className="flex justify-end mt-2">
          <Button 
            type="button" 
            variant="outline" 
            size="sm" 
            onClick={handleImproveTitle} 
            disabled={isLoading || !name.trim()} 
            className="flex items-center gap-2 bg-violet-300 hover:bg-violet-200 text-purple-500"
          >
            {isLoading ? 
              <Loader2 className="h-4 w-4 animate-spin" /> : 
              <Wand2 className="h-4 w-4" />
            }
            Mejorar título
          </Button>
        </div>
      </div>
      
      {suggestions.length > 0 && (
        <div className="mt-4 space-y-2">
          <p className="text-sm font-medium text-gray-700">Sugerencias del asistente IA:</p>
          <div className="space-y-2">
            {suggestions.map((suggestion, index) => (
              <div key={index} className="flex bg-blue-50 border border-blue-100 p-3 rounded-md">
                <p className="flex-1 text-blue-700">{suggestion}</p>
                <Button 
                  type="button" 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => applySuggestion(suggestion)} 
                  className="text-blue-600 hover:text-blue-800"
                >
                  Aplicar
                </Button>
              </div>
            ))}
          </div>
        </div>
      )}
      
      {error && <p className="text-red-500 text-sm mt-1">{error}</p>}
    </div>
  );
}
