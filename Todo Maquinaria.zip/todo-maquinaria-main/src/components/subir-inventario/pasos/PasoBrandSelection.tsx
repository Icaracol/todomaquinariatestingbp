
import React, { useState, useEffect } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Input } from "@/components/ui/input";
import { Info, Wand2, Loader2 } from "lucide-react";
import { CategoryBreadcrumb } from "./subcategorias/CategoryBreadcrumb";
import { useMachineryAI } from "@/hooks/use-machinery-ai";
import { useToast } from "@/hooks/use-toast";

interface PasoBrandSelectionProps {
  mainCategoryId: string | null;
  mainCategoryName: string;
  productName: string;
  selectedBrand: string;
  onSelectBrand: (brand: string) => void;
  onNext: () => void;
}

export function PasoBrandSelection({
  mainCategoryId,
  mainCategoryName,
  productName,
  selectedBrand,
  onSelectBrand,
  onNext
}: PasoBrandSelectionProps) {
  const [brandSuggestions, setBrandSuggestions] = useState<string[]>([]);
  const [isLoadingSuggestions, setIsLoadingSuggestions] = useState(false);
  const { suggestBrand, isLoading } = useMachineryAI();
  const { toast } = useToast();
  
  // Marcas populares pre-configuradas por categoría
  const popularBrandsByCategory: Record<string, string[]> = {
    // Maquinaria Agrícola
    'agri-001': ['John Deere', 'New Holland', 'Case IH', 'Massey Ferguson', 'Claas'],
    // Maquinaria de Construcción
    'const-001': ['Caterpillar', 'Komatsu', 'Volvo CE', 'JCB', 'Liebherr', 'Hitachi'],
    // Maquinaria de Manipulación
    'manip-001': ['Toyota', 'Linde', 'Jungheinrich', 'Crown', 'Hyster'],
    // Default en caso de que no haya categoría
    'default': ['Caterpillar', 'John Deere', 'Volvo', 'JCB', 'Komatsu']
  };
  
  const handleBrandSuggestion = async () => {
    if (!mainCategoryId || !productName) {
      toast({
        title: "Información incompleta",
        description: "Se necesita el nombre del producto y la categoría para sugerir marcas",
        variant: "destructive"
      });
      return;
    }
    
    try {
      const result = await suggestBrand(productName, mainCategoryId);
      if (result && result.name) {
        onSelectBrand(result.name);
        toast({
          title: "Marca sugerida",
          description: `El asistente IA sugiere: ${result.name}`,
        });
      }
    } catch (error) {
      console.error("Error al sugerir marca:", error);
    }
  };
  
  const getPopularBrands = () => {
    if (!mainCategoryId) return popularBrandsByCategory['default'];
    return popularBrandsByCategory[mainCategoryId] || popularBrandsByCategory['default'];
  };
  
  return (
    <div className="space-y-4">
      <CategoryBreadcrumb mainCategoryName={mainCategoryName} />
      
      <h3 className="text-xl font-semibold text-gray-800">
        ¿De qué marca es tu {productName || mainCategoryName.toLowerCase()}?
      </h3>
      <p className="text-gray-600">
        Selecciona o escribe la marca de tu {productName || mainCategoryName.toLowerCase()}.
      </p>
      
      <Alert variant="default" className="bg-blue-50 border-blue-100">
        <Info className="h-4 w-4" />
        <AlertTitle>Paso 3 de 3: Selección de Marca</AlertTitle>
        <AlertDescription>
          En este paso puedes seleccionar la marca de tu maquinaria.
          Este campo es opcional pero recomendado para mejorar la visibilidad de tu anuncio.
        </AlertDescription>
      </Alert>
      
      <div className="bg-white p-6 rounded-lg border shadow-sm">
        <div className="space-y-6">
          <div>
            <label htmlFor="brand" className="block text-sm font-medium text-gray-700 mb-1">
              Marca
            </label>
            <div className="flex gap-2">
              <Input
                id="brand"
                placeholder="Ingresa la marca (ej: Caterpillar, John Deere)"
                value={selectedBrand}
                onChange={(e) => onSelectBrand(e.target.value)}
                className="flex-1"
              />
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleBrandSuggestion}
                disabled={isLoading || !productName || !mainCategoryId}
                className="whitespace-nowrap"
              >
                {isLoading ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Wand2 className="h-4 w-4 mr-2" />
                )}
                Sugerir marca
              </Button>
            </div>
          </div>
          
          <div>
            <h4 className="text-sm font-medium text-gray-700 mb-2">Marcas populares:</h4>
            <div className="flex flex-wrap gap-2">
              {getPopularBrands().map((brand, index) => (
                <Badge
                  key={index}
                  variant={selectedBrand === brand ? "default" : "outline"}
                  className="cursor-pointer px-3 py-1"
                  onClick={() => onSelectBrand(brand)}
                >
                  {brand}
                </Badge>
              ))}
            </div>
          </div>
          
          <div className="flex justify-between items-center pt-4 border-t">
            <p className="text-sm text-gray-600">
              La marca ayuda a los compradores a encontrar tu maquinaria más fácilmente.
            </p>
            <Button 
              type="button" 
              onClick={onNext}
              className="bg-primary hover:bg-primary/90"
            >
              {selectedBrand ? "Continuar" : "Omitir"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
