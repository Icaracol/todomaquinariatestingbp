
import React from "react";
import { CategoryItem } from "../types";
import { NoCategorySelected } from "./subcategorias/NoCategorySelected";
import { useSubcategoryFiltering } from "./subcategorias/hooks/useSubcategoryFiltering";
import { SubcategoryHeader } from "./subcategorias/components/SubcategoryHeader";
import { SubcategoryContent } from "./subcategorias/components/SubcategoryContent";
import { ValidationError } from "./subcategorias/components/ValidationError";

interface PasoSubcategoriasProps {
  categories: CategoryItem[];
  mainCategoryId: string | null;
  selectedCategoryId: string;
  onSelectCategory: (id: string) => void;
  mainCategoryName: string;
  hasSubcategories: boolean;
  error?: string;
  onClearError: () => void;
  onNext: () => void;
  productName: string;
  subcategories: CategoryItem[];
  hasModels?: boolean;
}

export function PasoSubcategorias({
  categories,
  mainCategoryId,
  selectedCategoryId,
  onSelectCategory,
  mainCategoryName,
  hasSubcategories: hasSubcategoriesProp,
  error,
  onClearError,
  onNext,
  productName,
  subcategories: providedSubcategories,
  hasModels = false
}: PasoSubcategoriasProps) {
  // Use custom hook for filtering subcategories
  const { filteredSubcategories, hasSubcategories } = useSubcategoryFiltering({
    subcategories: providedSubcategories,
    mainCategoryId
  });
  
  // Handle no main category scenario
  if (!mainCategoryId) {
    return <NoCategorySelected onNext={onNext} />;
  }
  
  return (
    <div className="space-y-4">
      <SubcategoryHeader 
        mainCategoryName={mainCategoryName} 
        productName={productName}
      />
      
      <SubcategoryContent
        mainCategoryId={mainCategoryId}
        mainCategoryName={mainCategoryName}
        productName={productName}
        selectedCategoryId={selectedCategoryId}
        onSelectCategory={onSelectCategory}
        filteredSubcategories={filteredSubcategories}
        onClearError={onClearError}
        onNext={onNext}
        hasModels={hasModels}
      />
      
      <ValidationError error={error} />
    </div>
  );
}
