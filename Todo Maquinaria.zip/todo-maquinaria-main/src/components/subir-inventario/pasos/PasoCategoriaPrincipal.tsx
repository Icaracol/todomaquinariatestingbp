
import React, { useState, useEffect } from "react";
import { Tractor, Truck, Package, Forklift, Factory, Info, Wand2, Loader2, Wrench } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";
import { useMachineryAI } from "@/hooks/use-machinery-ai";
import { useToast } from "@/hooks/use-toast";
import { CategoryItem } from "../types";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

interface PasoCategoriaPrincipalProps {
  categories: CategoryItem[];
  selectedCategory: string | null;
  onSelectCategory: (id: string) => void;
  productName: string;
  error?: string;
}

export function PasoCategoriaPrincipal({
  categories,
  selectedCategory,
  onSelectCategory,
  productName,
  error
}: PasoCategoriaPrincipalProps) {
  const { suggestCategory, isLoading } = useMachineryAI();
  const { toast } = useToast();
  const [suggestion, setSuggestion] = useState<{id: string | null, name: string, confidence: number} | null>(null);

  // Filter to only show main categories (those with no parent_id)
  const mainCategories = categories.filter(cat => !cat.parent_id || cat.level === 'main');

  // Ensure we log the selected category for debugging
  useEffect(() => {
    console.log("PasoCategoriaPrincipal - Current selectedCategory:", selectedCategory);
  }, [selectedCategory]);

  // Map for displaying appropriate icons based on category
  const getIconForCategory = (category: CategoryItem) => {
    const iconMap: Record<string, React.ReactNode> = {
      'tractor': <Tractor className="w-5 h-5" />,
      'truck': <Truck className="w-5 h-5" />,
      'factory': <Factory className="w-5 h-5" />,
      'package': <Package className="w-5 h-5" />,
      'forklift': <Forklift className="w-5 h-5" />,
      'tool': <Wrench className="w-5 h-5" />
    };

    return category.icon && iconMap[category.icon] 
      ? iconMap[category.icon] 
      : <Wrench className="w-5 h-5" />;
  };

  const handleGetSuggestion = async () => {
    if (!productName.trim()) {
      toast({
        title: "Nombre de máquina requerido",
        description: "Se necesita el nombre de la máquina para sugerir una categoría",
        variant: "destructive"
      });
      return;
    }

    try {
      const result = await suggestCategory(productName);
      if (result) {
        setSuggestion(result);
        
        if (result.id) {
          toast({
            title: "Categoría sugerida",
            description: `El asistente IA sugiere: ${result.name}`,
          });
        } else {
          toast({
            title: "Sugerencia disponible",
            description: "No se encontró una coincidencia exacta, pero hay una sugerencia aproximada",
          });
        }
      }
    } catch (error) {
      console.error("Error al sugerir categoría:", error);
    }
  };

  const applySuggestion = () => {
    if (suggestion?.id) {
      console.log("PasoCategoriaPrincipal - Applying category suggestion:", suggestion.id);
      onSelectCategory(suggestion.id);
      setSuggestion(null);
    }
  };

  return (
    <div className="space-y-4">
      <h3 className="text-xl font-semibold text-gray-800">¿Qué tipo de maquinaria es?</h3>
      <p className="text-gray-600">Selecciona la categoría principal de tu {productName || "maquinaria"}.</p>
      
      <Alert variant="default" className="bg-blue-50 border-blue-100">
        <Info className="h-4 w-4" />
        <AlertTitle>Paso 1 de 3: Selección de Categoría Principal</AlertTitle>
        <AlertDescription>
          En este paso debes seleccionar únicamente la categoría principal.
          Las subcategorías y marcas se seleccionarán en pasos posteriores.
        </AlertDescription>
      </Alert>
      
      <div className="flex justify-end">
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={handleGetSuggestion}
          disabled={isLoading || !productName.trim()}
          className="flex items-center gap-2"
        >
          {isLoading ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Wand2 className="h-4 w-4" />
          )}
          Sugerir categoría
        </Button>
      </div>
      
      {suggestion && (
        <div className="bg-blue-50 border border-blue-100 p-4 rounded-md mb-4">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-blue-800 font-medium">Sugerencia del asistente IA:</p>
              <p className="text-blue-700">{suggestion.name}</p>
              {suggestion.confidence > 0.7 ? (
                <span className="text-xs text-green-600">Alta confianza</span>
              ) : (
                <span className="text-xs text-yellow-600">Confianza moderada</span>
              )}
            </div>
            <Button
              type="button"
              variant="primary"
              size="sm"
              onClick={applySuggestion}
              disabled={!suggestion.id}
              className={!suggestion.id ? "opacity-50 cursor-not-allowed" : ""}
            >
              Aplicar
            </Button>
          </div>
        </div>
      )}
      
      <div className="bg-white p-6 rounded-lg border shadow-sm">
        <h4 className="text-base font-medium text-gray-700 mb-3">Selecciona una categoría principal:</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {mainCategories.map(category => (
            <TooltipProvider key={category.id}>
              <Tooltip>
                <TooltipTrigger asChild>
                  <div
                    className={`p-4 rounded-lg border-2 cursor-pointer transition-all hover:shadow-md flex flex-col items-center text-center
                      ${selectedCategory === category.id ? 'border-primary bg-primary/5' : 'border-gray-200 hover:border-gray-300'}`}
                    onClick={() => {
                      console.log("PasoCategoriaPrincipal - Category clicked:", category.id);
                      onSelectCategory(category.id);
                    }}
                  >
                    <div className={`w-14 h-14 rounded-full flex items-center justify-center mb-2
                      ${selectedCategory === category.id ? 'bg-primary text-white' : 'bg-gray-100 text-gray-500'}`}>
                      {getIconForCategory(category)}
                    </div>
                    <h4 className="font-medium">{category.name}</h4>
                  </div>
                </TooltipTrigger>
                <TooltipContent>
                  <p className="max-w-xs">{category.description || `Categoría para maquinarias tipo ${category.name}`}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          ))}
        </div>
        
        {error && (
          <div className="mt-4 p-3 bg-red-50 border border-red-100 rounded-md">
            <p className="text-red-600 text-sm">{error}</p>
          </div>
        )}

        <div className="mt-6 bg-blue-50 p-3 rounded-md">
          <p className="text-sm text-blue-700 flex items-start">
            <Info className="w-4 h-4 mr-2 mt-0.5 flex-shrink-0" />
            <span>Primero selecciona una categoría principal. En los siguientes pasos podrás elegir subcategorías y marcas específicas.</span>
          </p>
        </div>
      </div>
    </div>
  );
}
