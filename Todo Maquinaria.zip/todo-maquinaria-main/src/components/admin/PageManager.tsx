
import React from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { BlockEditor } from '@/components/editor/BlockEditor';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import * as pageClient from '@/lib/pages';
import type { Block } from '@/types/editor';

const AVAILABLE_BLOCKS: Block['type'][] = [
  'hero',
  'features',
  'pricing',
  'cta',
  'text',
  'image'
];

const initialPageState: Omit<pageClient.Page, 'id'> = {
  title: '',
  slug: '',
  meta: {
    description: '',
    keywords: []
  },
  blocks: []
};

export function PageManager() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [editingPage, setEditingPage] = React.useState<pageClient.Page | null>(null);
  const [newPage, setNewPage] = React.useState(initialPageState);

  const { data: pages = [], isLoading } = useQuery({
    queryKey: ['pages'],
    queryFn: pageClient.getPages
  });

  const createMutation = useMutation({
    mutationFn: pageClient.createPage,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pages'] });
      toast({
        title: "Página creada",
        description: "La página se ha creado correctamente."
      });
      setNewPage(initialPageState);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "No se pudo crear la página.",
        variant: "destructive"
      });
    }
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, updates }: { id: string; updates: Partial<pageClient.Page> }) => 
      pageClient.updatePage(id, updates),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pages'] });
      toast({
        title: "Página actualizada",
        description: "La página se ha actualizado correctamente."
      });
      setEditingPage(null);
    }
  });

  const deleteMutation = useMutation({
    mutationFn: pageClient.deletePage,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['pages'] });
      toast({
        title: "Página eliminada",
        description: "La página se ha eliminado correctamente."
      });
    }
  });

  const handleCreatePage = (e: React.FormEvent) => {
    e.preventDefault();
    createMutation.mutate(newPage);
  };

  const handleUpdatePage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPage?.id) return;
    
    updateMutation.mutate({
      id: editingPage.id,
      updates: editingPage
    });
  };

  if (isLoading) {
    return <div>Cargando...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Gestión de Páginas</h2>
        <Dialog>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Nueva Página
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl">
            <DialogHeader>
              <DialogTitle>Crear Nueva Página</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleCreatePage} className="space-y-6">
              <div className="grid gap-4">
                <div>
                  <Label htmlFor="title">Título</Label>
                  <Input
                    id="title"
                    value={newPage.title}
                    onChange={e => setNewPage({ ...newPage, title: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="slug">URL Amigable</Label>
                  <Input
                    id="slug"
                    value={newPage.slug}
                    onChange={e => setNewPage({ ...newPage, slug: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="description">Descripción (Meta)</Label>
                  <Input
                    id="description"
                    value={newPage.meta.description}
                    onChange={e => setNewPage({
                      ...newPage,
                      meta: { ...newPage.meta, description: e.target.value }
                    })}
                  />
                </div>
              </div>
              
              <div>
                <Label>Bloques</Label>
                <BlockEditor
                  blocks={newPage.blocks}
                  onBlocksChange={blocks => setNewPage({ ...newPage, blocks })}
                  availableBlocks={AVAILABLE_BLOCKS}
                />
              </div>

              <Button type="submit" disabled={createMutation.isPending}>
                Crear Página
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4">
        {pages.map(page => (
          <Card key={page.id} className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium">{page.title}</h3>
                <p className="text-sm text-gray-500">/{page.slug}</p>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setEditingPage(page)}
                >
                  <Pencil className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => deleteMutation.mutate(page.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {editingPage && (
        <Dialog open={true} onOpenChange={() => setEditingPage(null)}>
          <DialogContent className="max-w-4xl">
            <DialogHeader>
              <DialogTitle>Editar Página</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleUpdatePage} className="space-y-6">
              <div className="grid gap-4">
                <div>
                  <Label htmlFor="edit-title">Título</Label>
                  <Input
                    id="edit-title"
                    value={editingPage.title}
                    onChange={e => setEditingPage({
                      ...editingPage,
                      title: e.target.value
                    })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="edit-slug">URL Amigable</Label>
                  <Input
                    id="edit-slug"
                    value={editingPage.slug}
                    onChange={e => setEditingPage({
                      ...editingPage,
                      slug: e.target.value
                    })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="edit-description">Descripción (Meta)</Label>
                  <Input
                    id="edit-description"
                    value={editingPage.meta?.description || ''}
                    onChange={e => setEditingPage({
                      ...editingPage,
                      meta: { ...editingPage.meta, description: e.target.value }
                    })}
                  />
                </div>
              </div>
              
              <div>
                <Label>Bloques</Label>
                <BlockEditor
                  blocks={editingPage.blocks || []}
                  onBlocksChange={blocks => setEditingPage({
                    ...editingPage,
                    blocks
                  })}
                  availableBlocks={AVAILABLE_BLOCKS}
                />
              </div>

              <Button type="submit" disabled={updateMutation.isPending}>
                Guardar Cambios
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
