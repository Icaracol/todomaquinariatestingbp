
import { useEffect, useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useAdmin } from "@/hooks/useAdmin";
import type { UserAdminData, UserRole } from "@/types/admin";
import { format } from "date-fns";
import { Loader2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";

export function AdminPanel() {
  const { loading, getUserList, updateUserRole, resetUserLimits, isAdmin } = useAdmin();
  const [users, setUsers] = useState<UserAdminData[]>([]);
  const [updatingUser, setUpdatingUser] = useState<string | null>(null);
  const [isLoadingAdmin, setIsLoadingAdmin] = useState(true);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    const checkAdminAccess = async () => {
      const adminStatus = await isAdmin();
      if (!adminStatus) {
        toast({
          title: "Acceso denegado",
          description: "No tienes permisos para acceder al panel de administración",
          variant: "destructive",
        });
        navigate("/dashboard");
      }
      setIsLoadingAdmin(false);
    };

    checkAdminAccess();
  }, []);

  useEffect(() => {
    if (!isLoadingAdmin) {
      loadUsers();
    }
  }, [isLoadingAdmin]);

  const loadUsers = async () => {
    const userList = await getUserList();
    setUsers(userList);
  };

  const handleRoleChange = async (userId: string, newRole: UserRole) => {
    setUpdatingUser(userId);
    const success = await updateUserRole(userId, newRole);
    if (success) await loadUsers();
    setUpdatingUser(null);
  };

  const handleResetLimits = async (userId: string) => {
    setUpdatingUser(userId);
    const success = await resetUserLimits(userId);
    if (success) await loadUsers();
    setUpdatingUser(null);
  };

  if (isLoadingAdmin || loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-lime-600" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Panel de Administración</h2>
      </div>
      
      <div className="bg-white rounded-lg shadow overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Email</TableHead>
              <TableHead>Role</TableHead>
              <TableHead>Maquinaria</TableHead>
              <TableHead>Descargas</TableHead>
              <TableHead>Último Reset</TableHead>
              <TableHead>Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {users.map((user) => (
              <TableRow key={user.id} className="hover:bg-gray-50">
                <TableCell className="font-medium">{user.email}</TableCell>
                <TableCell>
                  <Select
                    value={user.role}
                    onValueChange={(value: UserRole) =>
                      handleRoleChange(user.id, value)
                    }
                    disabled={updatingUser === user.id}
                  >
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectGroup>
                        <SelectItem value="free">Free</SelectItem>
                        <SelectItem value="premium">Premium</SelectItem>
                        <SelectItem value="super_premium">Super Premium</SelectItem>
                      </SelectGroup>
                    </SelectContent>
                  </Select>
                </TableCell>
                <TableCell>{user.machineryCount}</TableCell>
                <TableCell>{user.downloadsCount}</TableCell>
                <TableCell>
                  {user.downloadsResetDate
                    ? format(new Date(user.downloadsResetDate), 'dd/MM/yyyy')
                    : 'Nunca'}
                </TableCell>
                <TableCell>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleResetLimits(user.id)}
                    disabled={updatingUser === user.id}
                    className="text-sm"
                  >
                    {updatingUser === user.id ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      'Reset Límites'
                    )}
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

