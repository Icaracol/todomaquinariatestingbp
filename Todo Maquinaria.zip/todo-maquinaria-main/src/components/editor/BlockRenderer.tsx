
import React from 'react';
import type { Block } from '@/types/editor';
import { HeroBlock } from './blocks/HeroBlock';
import { FeaturesBlock } from './blocks/FeaturesBlock';
import { PricingBlock } from './blocks/PricingBlock';
import { CTABlock } from './blocks/CTABlock';
import { TextBlock } from './blocks/TextBlock';
import { ImageBlock } from './blocks/ImageBlock';

interface BlockRendererProps {
  block: Block;
}

export function BlockRenderer({ block }: BlockRendererProps) {
  switch (block.type) {
    case 'hero':
      return <HeroBlock {...block.content} />;
    case 'features':
      return <FeaturesBlock {...block.content} />;
    case 'pricing':
      return <PricingBlock {...block.content} />;
    case 'cta':
      return <CTABlock {...block.content} />;
    case 'text':
      return <TextBlock {...block.content} />;
    case 'image':
      return <ImageBlock {...block.content} />;
    default:
      return null;
  }
}
