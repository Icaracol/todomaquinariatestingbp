
import React, { useState } from 'react';
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Move, Trash2, Settings } from "lucide-react";
import { 
  DragDropContext, 
  Droppable, 
  Draggable, 
  DropResult 
} from 'react-beautiful-dnd';
import { BlockControls } from './BlockControls';
import { BlockRenderer } from './BlockRenderer';
import type { Block, BlockType } from '@/types/editor';

interface BlockEditorProps {
  blocks: Block[];
  onBlocksChange: (blocks: Block[]) => void;
  availableBlocks: BlockType[];
  isEditing?: boolean;
}

export function BlockEditor({ 
  blocks, 
  onBlocksChange, 
  availableBlocks,
  isEditing = true 
}: BlockEditorProps) {
  const [selectedBlock, setSelectedBlock] = useState<string | null>(null);

  const handleDragEnd = (result: DropResult) => {
    if (!result.destination) return;

    const items = Array.from(blocks);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);

    onBlocksChange(items);
  };

  const handleAddBlock = (type: BlockType) => {
    const newBlock: Block = {
      id: `block-${Date.now()}`,
      type,
      content: {},
    };
    onBlocksChange([...blocks, newBlock]);
  };

  const handleUpdateBlock = (blockId: string, content: any) => {
    const updatedBlocks = blocks.map(block => 
      block.id === blockId ? { ...block, content } : block
    );
    onBlocksChange(updatedBlocks);
  };

  const handleDeleteBlock = (blockId: string) => {
    const updatedBlocks = blocks.filter(block => block.id !== blockId);
    onBlocksChange(updatedBlocks);
    setSelectedBlock(null);
  };

  if (!isEditing) {
    return (
      <div className="space-y-4">
        {blocks.map(block => (
          <BlockRenderer key={block.id} block={block} />
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <DragDropContext onDragEnd={handleDragEnd}>
        <Droppable droppableId="blocks">
          {(provided) => (
            <div
              {...provided.droppableProps}
              ref={provided.innerRef}
              className="space-y-4"
            >
              {blocks.map((block, index) => (
                <Draggable 
                  key={block.id} 
                  draggableId={block.id} 
                  index={index}
                >
                  {(provided) => (
                    <div
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                    >
                      <Card className="p-4 relative group">
                        <div className="flex items-center gap-2 mb-2">
                          <div
                            {...provided.dragHandleProps}
                            className="cursor-move p-2 hover:bg-gray-100 rounded"
                          >
                            <Move className="h-4 w-4 text-gray-500" />
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setSelectedBlock(
                              selectedBlock === block.id ? null : block.id
                            )}
                          >
                            <Settings className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteBlock(block.id)}
                            className="text-red-500 hover:text-red-600"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>

                        <BlockRenderer block={block} />

                        {selectedBlock === block.id && (
                          <BlockControls
                            block={block}
                            onUpdate={(content) => handleUpdateBlock(block.id, content)}
                          />
                        )}
                      </Card>
                    </div>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>

      <Card className="p-4">
        <h3 className="font-medium mb-4">Añadir nuevo bloque</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
          {availableBlocks.map((blockType) => (
            <Button
              key={blockType}
              variant="outline"
              className="flex items-center gap-2"
              onClick={() => handleAddBlock(blockType)}
            >
              <Plus className="h-4 w-4" />
              {blockType}
            </Button>
          ))}
        </div>
      </Card>
    </div>
  );
}
