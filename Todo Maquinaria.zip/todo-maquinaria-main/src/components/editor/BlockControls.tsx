
import React from 'react';
import type { Block } from '@/types/editor';

interface BlockControlsProps {
  block: Block;
  onUpdate: (content: any) => void;
}

export function BlockControls({ block, onUpdate }: BlockControlsProps) {
  // Renderizar los controles específicos según el tipo de bloque
  switch (block.type) {
    case 'text':
      return null; // Los controles de texto ya están en el componente TextBlock
    default:
      return null;
  }
}
