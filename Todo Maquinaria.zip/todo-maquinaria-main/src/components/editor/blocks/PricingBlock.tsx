
import React from 'react';

interface PricingTier {
  name: string;
  price: string;
  features: string[];
}

interface PricingBlockProps {
  title?: string;
  description?: string;
  tiers?: PricingTier[];
}

export function PricingBlock({ title = '', description = '', tiers = [] }: PricingBlockProps) {
  return (
    <div className="py-12">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-4 text-center">{title}</h2>
        <p className="text-center text-gray-600 mb-8">{description}</p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {tiers.map((tier, index) => (
            <div key={index} className="p-6 rounded-lg border">
              <h3 className="text-xl font-semibold">{tier.name}</h3>
              <p className="text-3xl font-bold my-4">{tier.price}</p>
              <ul className="space-y-2">
                {tier.features.map((feature, i) => (
                  <li key={i}>{feature}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
