
import React from 'react';

interface Feature {
  title: string;
  description: string;
  icon?: string;
}

interface FeaturesBlockProps {
  title?: string;
  features?: Feature[];
}

export function FeaturesBlock({ title = '', features = [] }: FeaturesBlockProps) {
  return (
    <div className="py-12">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold mb-8 text-center">{title}</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="p-6 rounded-lg border">
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
