
import React from 'react';
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

interface TextBlockProps {
  title?: string;
  content?: string;
  isEditing?: boolean;
  onUpdate?: (content: any) => void;
}

export function TextBlock({ 
  title = '', 
  content = '',
  isEditing = false,
  onUpdate
}: TextBlockProps) {
  if (isEditing) {
    return (
      <div className="space-y-4">
        <div>
          <Label>Título</Label>
          <Input
            value={title}
            onChange={(e) => onUpdate?.({ 
              title: e.target.value, 
              content 
            })}
            placeholder="Ingresa un título"
          />
        </div>
        <div>
          <Label>Contenido</Label>
          <Textarea
            value={content}
            onChange={(e) => onUpdate?.({ 
              title, 
              content: e.target.value 
            })}
            placeholder="Ingresa el contenido"
          />
        </div>
      </div>
    );
  }

  return (
    <div className="prose max-w-none">
      {title && <h2>{title}</h2>}
      {content && <p>{content}</p>}
    </div>
  );
}
