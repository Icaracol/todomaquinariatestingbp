
import React from 'react';

interface HeroBlockProps {
  title?: string;
  subtitle?: string;
  image?: string;
}

export function HeroBlock({ title = '', subtitle = '', image = '' }: HeroBlockProps) {
  return (
    <div className="relative py-16">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl font-bold mb-4">{title}</h1>
        <p className="text-xl text-gray-600">{subtitle}</p>
      </div>
    </div>
  );
}
