
import React from 'react';

interface ImageBlockProps {
  src?: string;
  alt?: string;
  caption?: string;
}

export function ImageBlock({ src = '', alt = '', caption = '' }: ImageBlockProps) {
  return (
    <figure className="my-8">
      {src && (
        <img
          src={src}
          alt={alt}
          className="w-full h-auto rounded-lg"
        />
      )}
      {caption && (
        <figcaption className="mt-2 text-center text-sm text-gray-600">
          {caption}
        </figcaption>
      )}
    </figure>
  );
}
