
import React from 'react';
import { Button } from "@/components/ui/button";

interface CTABlockProps {
  title?: string;
  description?: string;
  buttonText?: string;
  buttonLink?: string;
}

export function CTABlock({ 
  title = '', 
  description = '', 
  buttonText = 'Comenzar', 
  buttonLink = '#' 
}: CTABlockProps) {
  return (
    <div className="py-16 bg-gray-50">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl font-bold mb-4">{title}</h2>
        <p className="text-xl text-gray-600 mb-8">{description}</p>
        <Button variant="primary" asChild>
          <a href={buttonLink}>{buttonText}</a>
        </Button>
      </div>
    </div>
  );
}
