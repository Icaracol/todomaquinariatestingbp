
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/lib/supabase";
import { Label } from "@/components/ui/label";
import { Loader2 } from "lucide-react";

export function VerificationForm() {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const [selectedFiles, setSelectedFiles] = useState<FileList | null>(null);
  const [formData, setFormData] = useState({
    companyName: '',
    taxId: '',
    website: '',
    businessType: ''
  });

  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setSelectedFiles(e.target.files);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFiles?.length) {
      toast({
        title: "Error",
        description: "Por favor selecciona al menos un documento",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const user = (await supabase.auth.getUser()).data.user;
      if (!user) throw new Error("No se encontró usuario autenticado");

      // Subir documentos a Storage
      const uploadPromises = Array.from(selectedFiles).map(async (file) => {
        const fileExt = file.name.split('.').pop();
        const fileName = `${user.id}/${Date.now()}.${fileExt}`;
        const { error: uploadError, data } = await supabase.storage
          .from('verification_documents')
          .upload(fileName, file);

        if (uploadError) throw uploadError;
        return data.path;
      });

      const uploadedPaths = await Promise.all(uploadPromises);

      // Actualizar el perfil de la empresa
      const { error: updateError } = await supabase
        .from('business_profiles')
        .update({
          verification_documents: uploadedPaths,
          verification_status: 'pending',
          company_name: formData.companyName,
          tax_id: formData.taxId,
          website: formData.website || null,
          business_type: formData.businessType
        })
        .eq('user_id', user.id);

      if (updateError) throw updateError;

      toast({
        title: "Documentos enviados",
        description: "Tu solicitud de verificación ha sido enviada. Te notificaremos cuando sea revisada.",
      });
    } catch (error: any) {
      toast({
        title: "Error al enviar documentos",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle>Verificación Empresarial</CardTitle>
        <CardDescription>
          Complete el formulario y suba los documentos necesarios para verificar su empresa
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="companyName">Nombre de la Empresa *</Label>
              <Input
                id="companyName"
                name="companyName"
                required
                value={formData.companyName}
                onChange={handleFormChange}
                placeholder="Nombre legal de su empresa"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="taxId">RFC *</Label>
              <Input
                id="taxId"
                name="taxId"
                required
                value={formData.taxId}
                onChange={handleFormChange}
                placeholder="RFC de la empresa"
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="businessType">Tipo de Negocio *</Label>
              <Input
                id="businessType"
                name="businessType"
                required
                value={formData.businessType}
                onChange={handleFormChange}
                placeholder="Ej: Distribuidor, Fabricante, etc."
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="website">Sitio Web</Label>
              <Input
                id="website"
                name="website"
                type="url"
                value={formData.website}
                onChange={handleFormChange}
                placeholder="https://www.ejemplo.com"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="documents">Documentos Requeridos *</Label>
              <Input
                id="documents"
                type="file"
                multiple
                onChange={handleFileChange}
                accept=".pdf,.jpg,.jpeg,.png"
                disabled={loading}
              />
              <p className="text-sm text-muted-foreground">
                Formatos aceptados: PDF, JPG, PNG. Máximo 5MB por archivo.
              </p>
            </div>

            <div className="space-y-2">
              <p className="text-sm font-medium">Documentos necesarios:</p>
              <ul className="text-sm text-muted-foreground list-disc list-inside space-y-1">
                <li>Acta constitutiva</li>
                <li>Comprobante de domicilio reciente</li>
                <li>Identificación oficial del representante legal</li>
                <li>RFC de la empresa</li>
              </ul>
            </div>
          </div>

          <Button 
            type="submit" 
            className="w-full" 
            disabled={loading || !selectedFiles}
          >
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Enviando documentos...
              </>
            ) : (
              "Enviar para verificación"
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
