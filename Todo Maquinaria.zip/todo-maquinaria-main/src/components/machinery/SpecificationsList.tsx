
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { MachinerySpec } from "@/types/machinery";

interface SpecificationsListProps {
  specs: MachinerySpec[];
}

export function SpecificationsList({ specs }: SpecificationsListProps) {
  if (!specs.length) {
    return null;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Especificaciones Técnicas</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {specs.map((spec) => (
            <div key={spec.id} className="flex justify-between p-2 border-b">
              <span className="font-medium text-muted-foreground">{spec.spec_key}</span>
              <span>{spec.spec_value}</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
