
import { useState, useCallback } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  ChevronLeft, 
  ChevronRight, 
  Star, 
  X, 
  Image as ImageIcon, 
  Upload,
  ArrowLeft,
  ArrowRight
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/lib/supabase";
import type { MachineryImage } from "@/types/machinery";

interface ImageGalleryProps {
  images: MachineryImage[];
  onSetPrimary?: (imageId: string) => void;
  showPrimaryButton?: boolean;
  isEditing?: boolean;
  machineId?: string;
  onImagesUpdate?: (updatedImages: MachineryImage[]) => void;
}

export function ImageGallery({ 
  images, 
  onSetPrimary, 
  showPrimaryButton = false,
  isEditing = false,
  machineId,
  onImagesUpdate
}: ImageGalleryProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [uploadingImages, setUploadingImages] = useState(false);
  const { toast } = useToast();

  const navigate = (direction: 'prev' | 'next') => {
    if (direction === 'prev') {
      setCurrentIndex(current => current === 0 ? images.length - 1 : current - 1);
    } else {
      setCurrentIndex(current => current === images.length - 1 ? 0 : current + 1);
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || !machineId) return;
    
    setUploadingImages(true);
    const files = Array.from(e.target.files);
    const newImages: MachineryImage[] = [];

    try {
      for (const file of files) {
        const fileExt = file.name.split('.').pop();
        const fileName = `${machineId}/${crypto.randomUUID()}.${fileExt}`;

        const { data: uploadResult, error: uploadError } = await supabase.storage
          .from('machinery')
          .upload(fileName, file);

        if (uploadError) throw uploadError;

        const { data: urlData } = supabase.storage
          .from('machinery')
          .getPublicUrl(fileName);

        const { data: imageData, error: insertError } = await supabase
          .from('machinery_images')
          .insert({
            machinery_id: machineId,
            url: urlData.publicUrl,
            is_primary: images.length === 0
          })
          .select()
          .single();

        if (insertError) throw insertError;
        if (imageData) newImages.push(imageData);
      }

      toast({
        title: "Imágenes subidas",
        description: `Se subieron ${files.length} imágenes correctamente`
      });

      if (onImagesUpdate) {
        onImagesUpdate([...images, ...newImages]);
      }
    } catch (error) {
      console.error('Error uploading images:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "No se pudieron subir las imágenes"
      });
    } finally {
      setUploadingImages(false);
    }
  };

  const handleDeleteImage = async (imageId: string) => {
    if (!machineId || images.length <= 1) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Debe mantener al menos una imagen"
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('machinery_images')
        .delete()
        .eq('id', imageId);

      if (error) throw error;

      const updatedImages = images.filter(img => img.id !== imageId);
      if (onImagesUpdate) {
        onImagesUpdate(updatedImages);
      }

      if (currentIndex >= updatedImages.length) {
        setCurrentIndex(Math.max(0, updatedImages.length - 1));
      }

      toast({
        title: "Imagen eliminada",
        description: "La imagen se eliminó correctamente"
      });
    } catch (error) {
      console.error('Error deleting image:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "No se pudo eliminar la imagen"
      });
    }
  };

  const moveImage = async (imageId: string, direction: 'left' | 'right') => {
    const currentIndex = images.findIndex(img => img.id === imageId);
    if (currentIndex === -1) return;

    const newIndex = direction === 'left' 
      ? Math.max(0, currentIndex - 1)
      : Math.min(images.length - 1, currentIndex + 1);

    if (currentIndex === newIndex) return;

    const newImages = [...images];
    const [movedImage] = newImages.splice(currentIndex, 1);
    newImages.splice(newIndex, 0, movedImage);

    if (onImagesUpdate) {
      onImagesUpdate(newImages);
    }
  };

  if (!images.length) {
    return (
      <Card>
        <CardContent className="p-6">
          {isEditing ? (
            <div className="flex flex-col items-center gap-4">
              <Input
                type="file"
                multiple
                accept="image/*"
                onChange={handleImageUpload}
                disabled={uploadingImages}
                className="hidden"
                id="image-upload"
              />
              <label 
                htmlFor="image-upload"
                className="flex flex-col items-center gap-2 p-8 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-primary transition-colors"
              >
                <Upload className="h-8 w-8 text-gray-400" />
                <p className="text-sm text-gray-600">
                  {uploadingImages ? 'Subiendo imágenes...' : 'Haz clic para subir imágenes'}
                </p>
              </label>
            </div>
          ) : (
            <div className="aspect-video bg-muted flex items-center justify-center text-muted-foreground">
              <ImageIcon className="h-8 w-8" />
              <span className="ml-2">No hay imágenes disponibles</span>
            </div>
          )}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="relative">
      <CardContent className="p-0">
        <div className="aspect-video relative">
          <img
            src={images[currentIndex].url}
            alt={`Imagen ${currentIndex + 1}`}
            className="w-full h-full object-cover"
          />
          {images.length > 1 && (
            <>
              <Button
                variant="ghost"
                size="icon"
                className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white"
                onClick={() => navigate('prev')}
              >
                <ChevronLeft className="h-6 w-6" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white"
                onClick={() => navigate('next')}
              >
                <ChevronRight className="h-6 w-6" />
              </Button>
            </>
          )}
          {showPrimaryButton && onSetPrimary && (
            <Button
              variant="ghost"
              size="icon"
              className={`absolute top-2 right-2 ${
                images[currentIndex].is_primary 
                  ? 'text-yellow-400 hover:text-yellow-500'
                  : 'text-white hover:text-yellow-400'
              }`}
              onClick={() => onSetPrimary(images[currentIndex].id)}
            >
              <Star className="h-5 w-5" />
            </Button>
          )}
          {isEditing && (
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-2 left-2 bg-black/50 hover:bg-black/70 text-white"
              onClick={() => handleDeleteImage(images[currentIndex].id)}
            >
              <X className="h-5 w-5" />
            </Button>
          )}
        </div>
        <div className="p-4">
          <div className="flex items-center gap-2 overflow-x-auto">
            {isEditing && (
              <div className="flex-shrink-0">
                <Input
                  type="file"
                  multiple
                  accept="image/*"
                  onChange={handleImageUpload}
                  disabled={uploadingImages}
                  className="hidden"
                  id="additional-image-upload"
                />
                <label 
                  htmlFor="additional-image-upload"
                  className="flex items-center justify-center w-20 h-20 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-primary transition-colors"
                >
                  <Upload className="h-6 w-6 text-gray-400" />
                </label>
              </div>
            )}
            {images.map((image, index) => (
              <div 
                key={image.id}
                className="relative flex-shrink-0"
              >
                <button
                  onClick={() => setCurrentIndex(index)}
                  className={`w-20 h-20 rounded-lg overflow-hidden border-2 transition-colors relative ${
                    index === currentIndex ? 'border-primary' : 'border-transparent'
                  }`}
                >
                  <img
                    src={image.url}
                    alt={`Miniatura ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                  {image.is_primary && (
                    <div className="absolute top-1 right-1">
                      <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                    </div>
                  )}
                </button>
                {isEditing && images.length > 1 && (
                  <div className="absolute -bottom-2 left-0 right-0 flex justify-center gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6 bg-white shadow-sm hover:bg-gray-100"
                      onClick={() => moveImage(image.id, 'left')}
                      disabled={index === 0}
                    >
                      <ArrowLeft className="h-3 w-3" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6 bg-white shadow-sm hover:bg-gray-100"
                      onClick={() => moveImage(image.id, 'right')}
                      disabled={index === images.length - 1}
                    >
                      <ArrowRight className="h-3 w-3" />
                    </Button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
