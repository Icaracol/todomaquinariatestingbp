
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, MapPin, Tag } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { ContactForm } from "./ContactForm";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { supabase } from "@/lib/supabase";
import { useToast } from "@/hooks/use-toast";
import type { DetailedMachinery } from "@/types/machinery";
import { useState } from "react";

interface DetailsSidebarProps {
  machinery: DetailedMachinery;
  isSellerView: boolean;
  showContactForm: boolean;
  onContactClick: () => void;
  isEditing?: boolean;
  onUpdate?: (updatedData: Partial<DetailedMachinery>) => void;
}

export function DetailsSidebar({ 
  machinery, 
  isSellerView, 
  showContactForm, 
  onContactClick,
  isEditing = false,
  onUpdate
}: DetailsSidebarProps) {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [editForm, setEditForm] = useState({
    price: machinery.price?.toString() || "",
    year: machinery.year?.toString() || "",
    location: machinery.location || "",
    is_public: machinery.is_public
  });

  const handleSave = async () => {
    try {
      const { error } = await supabase
        .from('machinery')
        .update({
          price: editForm.price ? parseFloat(editForm.price) : null,
          year: editForm.year ? parseInt(editForm.year) : null,
          location: editForm.location,
          is_public: editForm.is_public
        })
        .eq('id', machinery.id);

      if (error) throw error;

      if (onUpdate) {
        onUpdate({
          ...machinery,
          price: editForm.price ? parseFloat(editForm.price) : null,
          year: editForm.year ? parseInt(editForm.year) : null,
          location: editForm.location,
          is_public: editForm.is_public
        });
      }

      toast({
        title: "Éxito",
        description: "La información se actualizó correctamente"
      });
    } catch (error) {
      console.error('Error updating machinery:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "No se pudo actualizar la información"
      });
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardContent className="p-6 bg-lime-50">
          <div className="space-y-6">
            {isEditing ? (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="price">Precio</Label>
                  <Input
                    id="price"
                    type="number"
                    value={editForm.price}
                    onChange={(e) => setEditForm(prev => ({ ...prev, price: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="year">Año</Label>
                  <Input
                    id="year"
                    type="number"
                    value={editForm.year}
                    onChange={(e) => setEditForm(prev => ({ ...prev, year: e.target.value }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="location">Ubicación</Label>
                  <Input
                    id="location"
                    value={editForm.location}
                    onChange={(e) => setEditForm(prev => ({ ...prev, location: e.target.value }))}
                  />
                </div>

                <div className="flex items-center justify-between pt-2">
                  <div>
                    <Label>Visibilidad</Label>
                    <p className="text-sm text-muted-foreground">
                      {editForm.is_public ? 'Publicación visible' : 'Publicación oculta'}
                    </p>
                  </div>
                  <Switch
                    checked={editForm.is_public}
                    onCheckedChange={(checked) => setEditForm(prev => ({ ...prev, is_public: checked }))}
                  />
                </div>

                <Button className="w-full" onClick={handleSave}>
                  Guardar cambios
                </Button>
              </div>
            ) : (
              <>
                <div className="text-3xl font-bold px-0 rounded-xl bg-lime-200 hover:bg-lime-100">
                  {machinery?.price
                    ? new Intl.NumberFormat('es-AR', {
                        style: 'currency',
                        currency: 'ARS'
                      }).format(machinery.price)
                    : 'Precio a consultar'}
                </div>

                <div className="space-y-4">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground bg-lime-50">
                    <Calendar className="h-4 w-4 bg-transparent" />
                    <span className="font-normal text-slate-950">
                      Año: {machinery?.year || 'No especificado'}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <MapPin className="h-4 w-4" />
                    <span className="text-slate-900">
                      {machinery?.location || 'Ubicación no especificada'}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Tag className="h-4 w-4" />
                    <span className="text-slate-900">
                      Categoría: {machinery?.category?.name || 'No especificada'}
                    </span>
                  </div>
                </div>

                {!isSellerView && !showContactForm && (
                  <Button
                    className="w-full"
                    variant="default"
                    size="lg"
                    onClick={onContactClick}
                  >
                    Contactar al vendedor
                  </Button>
                )}

                {!isSellerView && showContactForm && (
                  <ContactForm
                    machineId={machinery?.id || ''}
                    machineName={machinery?.name || ''}
                  />
                )}
              </>
            )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6 bg-lime-50 py-[56px]">
          <div className="text-sm text-muted-foreground">
            <div className="flex items-center justify-between mb-2">
              <span className="text-slate-900 py-0 my-0 mx-0 px-0">ID:</span>
              <span className="font-mono text-slate-900 font-normal px-0 my-0 mx-[18px] text-left">
                {machinery?.id}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-800">Vistas:</span>
              <span className="text-slate-900 font-light py-px my-[10px] mx-[2px] px-[88px] text-left">
                {machinery?.views}
              </span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
