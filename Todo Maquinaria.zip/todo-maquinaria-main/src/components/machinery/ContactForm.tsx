import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/lib/supabase";
import { useNavigate } from "react-router-dom";
import { MessageCircle } from "lucide-react";

interface ContactFormProps {
  machineId: string;
  machineName: string;
}

export function ContactForm({ machineId, machineName }: ContactFormProps) {
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    whatsapp: "",
    message: ""
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      
      if (session?.user) {
        const { data: machineData, error: machineError } = await supabase
          .from('machinery')
          .select('user_id')
          .eq('id', machineId)
          .single();

        if (machineError) throw machineError;

        const { data: conversationData, error: conversationError } = await supabase
          .from('conversations')
          .insert({
            user1_id: session.user.id,
            user2_id: machineData.user_id,
            machinery_id: machineId,
          })
          .select()
          .single();

        if (conversationError) throw conversationError;

        const { error: messageError } = await supabase
          .from('messages')
          .insert({
            conversation_id: conversationData.id,
            sender_id: session.user.id,
            recipient_id: machineData.user_id,
            content: formData.message || `Hola, estoy interesado en ${machineName}`,
            machinery_id: machineId,
          });

        if (messageError) throw messageError;

        toast({
          title: "Mensaje enviado",
          description: "Tu mensaje ha sido enviado. El vendedor responderá pronto.",
        });

        navigate('/dashboard');
      } else {
        const { data: machineData, error: machineError } = await supabase
          .from('machinery')
          .select('user_id')
          .eq('id', machineId)
          .single();

        if (machineError) throw machineError;

        const { error } = await supabase
          .from('leads')
          .insert({
            machinery_id: machineId,
            seller_id: machineData.user_id,
            name: formData.name,
            email: formData.email,
            phone: formData.phone,
            whatsapp: formData.whatsapp || formData.phone,
            message: formData.message,
            interest: machineName,
            status: 'nuevo'
          });

        if (error) throw error;

        toast({
          title: "¡Mensaje enviado!",
          description: "El vendedor se pondrá en contacto contigo pronto.",
        });

        setFormData({
          name: "",
          email: "",
          phone: "",
          whatsapp: "",
          message: ""
        });
      }
    } catch (error) {
      console.error('Error:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "No se pudo enviar tu mensaje. Por favor intenta nuevamente.",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleLoginClick = () => {
    navigate(`/login?redirect=/maquinaria/${machineId}`);
  };

  return (
    <div className="space-y-4">
      <form onSubmit={handleSubmit} className="space-y-4">
        <Input
          placeholder="Nombre completo"
          value={formData.name}
          onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
          required
        />
        <Input
          type="email"
          placeholder="Correo electrónico"
          value={formData.email}
          onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
          required
        />
        <Input
          type="tel"
          placeholder="Teléfono"
          value={formData.phone}
          onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
          required
        />
        <Input
          type="tel"
          placeholder="WhatsApp (opcional, si es diferente al teléfono)"
          value={formData.whatsapp}
          onChange={(e) => setFormData(prev => ({ ...prev, whatsapp: e.target.value }))}
        />
        <Textarea
          placeholder="Mensaje (opcional)"
          value={formData.message}
          onChange={(e) => setFormData(prev => ({ ...prev, message: e.target.value }))}
          className="min-h-[100px]"
        />
        <div className="space-y-2">
          <Button 
            type="submit" 
            className="w-full" 
            variant="primary"
            disabled={loading}
          >
            {loading ? "Enviando..." : "Enviar mensaje"}
          </Button>
          <div className="text-center">
            <span className="text-sm text-muted-foreground">¿Ya tienes una cuenta?</span>{" "}
            <Button variant="link" type="button" onClick={handleLoginClick}>
              Inicia sesión
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
}
