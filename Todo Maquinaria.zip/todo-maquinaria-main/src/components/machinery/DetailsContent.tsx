
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { ImageGallery } from "./ImageGallery";
import { SpecificationsList } from "./SpecificationsList";
import { Label } from "@/components/ui/label";
import { Edit2, Save, X } from "lucide-react";
import { useState } from "react";
import type { DetailedMachinery } from "@/types/machinery";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/lib/supabase";

interface DetailsContentProps {
  machinery: DetailedMachinery;
  isEditing?: boolean;
  onEditToggle?: () => void;
  onUpdate?: (updatedData: Partial<DetailedMachinery>) => void;
  isSellerView?: boolean;
}

export function DetailsContent({ 
  machinery, 
  isEditing = false,
  onEditToggle,
  onUpdate,
  isSellerView = false 
}: DetailsContentProps) {
  const { toast } = useToast();
  const [editForm, setEditForm] = useState({
    name: machinery.name,
    description: machinery.description || "",
  });

  const handleSave = async () => {
    try {
      const { error } = await supabase
        .from('machinery')
        .update({
          name: editForm.name,
          description: editForm.description,
        })
        .eq('id', machinery.id);

      if (error) throw error;

      toast({
        title: "Éxito",
        description: "La maquinaria se actualizó correctamente"
      });

      if (onUpdate) {
        onUpdate({
          ...machinery,
          name: editForm.name,
          description: editForm.description,
        });
      }

      if (onEditToggle) {
        onEditToggle();
      }
    } catch (error) {
      console.error('Error updating machinery:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "No se pudo actualizar la maquinaria"
      });
    }
  };

  const EditableTitle = () => (
    isEditing ? (
      <div className="space-y-2">
        <Label htmlFor="name">Nombre</Label>
        <Input
          id="name"
          value={editForm.name}
          onChange={(e) => setEditForm(prev => ({ ...prev, name: e.target.value }))}
          className="bg-white text-black"
        />
      </div>
    ) : (
      <h1 className="text-2xl font-bold text-white mb-4">{machinery.name}</h1>
    )
  );

  return (
    <div className="lg:col-span-2 space-y-8">
      {isSellerView && (
        <div className="flex justify-end space-x-2">
          {isEditing ? (
            <>
              <Button 
                variant="outline"
                onClick={() => {
                  setEditForm({
                    name: machinery.name,
                    description: machinery.description || "",
                  });
                  if (onEditToggle) onEditToggle();
                }}
              >
                <X className="h-4 w-4 mr-2" />
                Cancelar
              </Button>
              <Button onClick={handleSave}>
                <Save className="h-4 w-4 mr-2" />
                Guardar cambios
              </Button>
            </>
          ) : (
            <Button onClick={onEditToggle}>
              <Edit2 className="h-4 w-4 mr-2" />
              Editar
            </Button>
          )}
        </div>
      )}

      <EditableTitle />
      
      <ImageGallery 
        images={machinery?.images || []} 
        showPrimaryButton={isEditing}
        onSetPrimary={async (imageId) => {
          try {
            // Update all images to not primary first
            await supabase
              .from('machinery_images')
              .update({ is_primary: false })
              .eq('machinery_id', machinery.id);

            // Set the selected image as primary
            await supabase
              .from('machinery_images')
              .update({ is_primary: true })
              .eq('id', imageId);

            toast({
              title: "Éxito",
              description: "La imagen principal se ha actualizado"
            });

            if (onUpdate) {
              const updatedImages = machinery.images.map(img => ({
                ...img,
                is_primary: img.id === imageId
              }));
              onUpdate({ ...machinery, images: updatedImages });
            }
          } catch (error) {
            console.error('Error updating primary image:', error);
            toast({
              variant: "destructive",
              title: "Error",
              description: "No se pudo actualizar la imagen principal"
            });
          }
        }}
      />
      
      <Card className="px-0 my-[20px] bg-slate-900 hover:bg-slate-800">
        <CardHeader className="py-0 px-0 mx-0 my-[12px] bg-slate-900 hover:bg-slate-800">
          <CardTitle className="text-lime-500 font-thin text-lg text-center py-0 px-0 mx-[170px] my-[4px]">
            DESCRIPCIÓN
          </CardTitle>
        </CardHeader>
        <CardContent className="bg-lime-50">
          {isEditing ? (
            <Textarea
              value={editForm.description}
              onChange={(e) => setEditForm(prev => ({ ...prev, description: e.target.value }))}
              rows={5}
              className="w-full"
            />
          ) : (
            <p className="whitespace-pre-wrap text-slate-800 text-left my-[10px] mx-0 py-[14px] px-[8px]">
              {machinery?.description || "Sin descripción disponible"}
            </p>
          )}
        </CardContent>
      </Card>

      <SpecificationsList specs={machinery?.specs || []} />
    </div>
  );
}
