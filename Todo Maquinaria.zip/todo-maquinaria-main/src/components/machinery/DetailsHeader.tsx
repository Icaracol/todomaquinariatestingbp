
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";

interface DetailsHeaderProps {
  title: string;
  isSellerView: boolean;
}

export function DetailsHeader({ title, isSellerView }: DetailsHeaderProps) {
  const navigate = useNavigate();

  return (
    <div className="flex items-center gap-4 mb-8">
      <Button 
        variant="outline" 
        size="icon" 
        onClick={() => navigate(isSellerView ? '/dashboard' : '/catalogo')}
      >
        <ArrowLeft className="h-4 w-4" />
      </Button>
      <h1 className="text-2xl font-bold text-white">{title}</h1>
    </div>
  );
}
