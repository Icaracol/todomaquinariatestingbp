
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from "@/lib/supabase";

export default function AuthCallback() {
  const navigate = useNavigate();

  useEffect(() => {
    const handleAuthCallback = async () => {
      const { error } = await supabase.auth.getSession();
      if (error) {
        console.error('Error al procesar la autenticación:', error.message);
        navigate('/login');
      } else {
        navigate('/subir-inventario');
      }
    };

    handleAuthCallback();
  }, [navigate]);

  return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="text-center">
        <h2 className="text-2xl font-semibold mb-2">Procesando autenticación...</h2>
        <p className="text-gray-600">Por favor, espere un momento.</p>
      </div>
    </div>
  );
}
