import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, Phone, Mail, MessageSquare, Calendar } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { getLeads, actualizarLead } from "@/services/api";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

const GestionLeads = () => {
  const [busqueda, setBusqueda] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: leads = [], isLoading } = useQuery({
    queryKey: ['leads'],
    queryFn: getLeads,
  });

  const mutation = useMutation({
    mutationFn: ({ id, datos }: { id: string; datos: any }) => 
      actualizarLead(id, datos),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['leads'] });
      toast({
        title: "Lead actualizado",
        description: "Los cambios han sido guardados correctamente",
      });
    },
  });

  const leadsFiltrados = leads.filter(lead => 
    lead.nombre.toLowerCase().includes(busqueda.toLowerCase()) ||
    lead.email.toLowerCase().includes(busqueda.toLowerCase())
  );

  const estadisticas = {
    total: leads.length,
    nuevos: leads.filter(l => l.estado === 'nuevo').length,
    seguimiento: leads.filter(l => l.estado === 'seguimiento').length,
    convertidos: leads.filter(l => l.estado === 'convertido').length,
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-bold">Gestión de Leads</h1>
        <Button>Nuevo Lead</Button>
      </div>

      <div className="grid md:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Total Leads</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{estadisticas.total}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Nuevos Hoy</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{estadisticas.nuevos}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">En Seguimiento</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{estadisticas.seguimiento}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Convertidos</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{estadisticas.convertidos}</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Leads Activos</CardTitle>
            <div className="relative w-64">
              <Input
                type="search"
                placeholder="Buscar leads..."
                className="pl-10"
                value={busqueda}
                onChange={(e) => setBusqueda(e.target.value)}
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {isLoading ? (
              <p>Cargando leads...</p>
            ) : (
              leadsFiltrados.map((lead) => (
                <Card key={lead.id}>
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-semibold text-lg">{lead.nombre}</h3>
                        <p className="text-sm text-gray-600">
                          Interesado en: {lead.interes}
                        </p>
                        <div className="flex gap-4 mt-2 text-sm text-gray-600">
                          <span className="flex items-center gap-1">
                            <Phone className="w-4 h-4" />
                            {lead.telefono}
                          </span>
                          <span className="flex items-center gap-1">
                            <Mail className="w-4 h-4" />
                            {lead.email}
                          </span>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            // Aquí iría la lógica para agendar una cita
                            toast({
                              title: "Función en desarrollo",
                              description: "La función de agenda estará disponible próximamente",
                            });
                          }}
                        >
                          <Calendar className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            // Aquí iría la lógica para enviar un mensaje
                            toast({
                              title: "Función en desarrollo",
                              description: "La función de mensajería estará disponible próximamente",
                            });
                          }}
                        >
                          <MessageSquare className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => {
                            mutation.mutate({
                              id: lead.id,
                              datos: {
                                estado: lead.estado === 'nuevo' ? 'seguimiento' : 'convertido',
                              },
                            });
                          }}
                        >
                          {lead.estado === 'nuevo' ? 'Iniciar Seguimiento' : 'Marcar como Convertido'}
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default GestionLeads;