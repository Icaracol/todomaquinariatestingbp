
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/lib/supabase";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Eye } from "lucide-react";
import type { DetailedMachinery } from "@/types/machinery";
import { ImageGallery } from "@/components/machinery/ImageGallery";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function EditMachinery() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    price: "",
    year: "",
    location: "",
    is_public: true
  });
  const [showPreview, setShowPreview] = useState(false);
  const [previewData, setPreviewData] = useState<DetailedMachinery | null>(null);

  const { data: machinery, isLoading } = useQuery({
    queryKey: ['machinery', id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('machinery')
        .select(`
          *,
          category:categories(*),
          images:machinery_images(*),
          specs:machinery_specs(*)
        `)
        .eq('id', id)
        .single();

      if (error) {
        toast({
          variant: "destructive",
          title: "Error",
          description: "No se pudo cargar la información de la maquinaria"
        });
        navigate('/dashboard');
        throw error;
      }

      setFormData({
        name: data.name,
        description: data.description || "",
        price: data.price?.toString() || "",
        year: data.year?.toString() || "",
        location: data.location || "",
        is_public: data.is_public
      });

      return data as DetailedMachinery;
    }
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleTogglePublic = (checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      is_public: checked
    }));
  };

  const handlePreview = () => {
    if (!machinery) return;
    
    setPreviewData({
      ...machinery,
      name: formData.name,
      description: formData.description,
      price: parseFloat(formData.price) || machinery.price,
      year: parseInt(formData.year) || machinery.year,
      location: formData.location,
      is_public: formData.is_public
    });
    setShowPreview(true);
  };

  const handleSave = async () => {
    try {
      const { error } = await supabase
        .from('machinery')
        .update({
          name: formData.name,
          description: formData.description,
          price: formData.price ? parseFloat(formData.price) : null,
          year: formData.year ? parseInt(formData.year) : null,
          location: formData.location,
          is_public: formData.is_public
        })
        .eq('id', id);

      if (error) throw error;

      toast({
        title: "Éxito",
        description: "La maquinaria se actualizó correctamente"
      });

      navigate(`/dashboard/maquinaria/${id}`);
    } catch (error) {
      console.error('Error updating machinery:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "No se pudo actualizar la maquinaria"
      });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-800 flex items-center justify-center">
        <div className="text-white">Cargando...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-800">
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center gap-4 mb-8">
          <Button 
            variant="outline" 
            size="icon"
            onClick={() => navigate(`/dashboard/maquinaria/${id}`)}
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h1 className="text-2xl font-bold text-white">Editar Maquinaria</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <Card>
              <CardContent className="p-6 space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Nombre</Label>
                  <Input
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Descripción</Label>
                  <Textarea
                    id="description"
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    rows={5}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="price">Precio</Label>
                  <Input
                    id="price"
                    name="price"
                    type="number"
                    value={formData.price}
                    onChange={handleInputChange}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="year">Año</Label>
                  <Input
                    id="year"
                    name="year"
                    type="number"
                    value={formData.year}
                    onChange={handleInputChange}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="location">Ubicación</Label>
                  <Input
                    id="location"
                    name="location"
                    value={formData.location}
                    onChange={handleInputChange}
                  />
                </div>

                <div className="flex items-center justify-between border-t pt-4">
                  <div className="space-y-0.5">
                    <Label>Visibilidad</Label>
                    <div className="text-sm text-muted-foreground">
                      {formData.is_public ? 'Publicación visible' : 'Publicación oculta'}
                    </div>
                  </div>
                  <Switch
                    checked={formData.is_public}
                    onCheckedChange={handleTogglePublic}
                  />
                </div>
              </CardContent>
            </Card>

            {machinery?.images && machinery.images.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Imágenes actuales</CardTitle>
                </CardHeader>
                <CardContent>
                  <ImageGallery images={machinery.images} />
                </CardContent>
              </Card>
            )}

            <div className="flex justify-end gap-4">
              <Button
                variant="outline"
                onClick={handlePreview}
                className="w-32"
              >
                <Eye className="h-4 w-4 mr-2" />
                Vista previa
              </Button>
              <Button
                onClick={handleSave}
                className="w-32"
              >
                Guardar cambios
              </Button>
            </div>
          </div>

          <Card className="lg:sticky lg:top-8 h-fit">
            <CardHeader>
              <CardTitle>Previsualización del marketplace</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="aspect-video bg-muted rounded-lg flex items-center justify-center text-muted-foreground">
                La vista previa estará disponible al hacer clic en el botón "Vista previa"
              </div>
            </CardContent>
          </Card>
        </div>

        <Dialog open={showPreview} onOpenChange={setShowPreview}>
          <DialogContent className="max-w-4xl">
            <DialogHeader>
              <DialogTitle>Vista previa de la publicación</DialogTitle>
            </DialogHeader>
            {previewData && (
              <div className="mt-4">
                <h2 className="text-2xl font-bold mb-4">{previewData.name}</h2>
                {previewData.images && previewData.images.length > 0 && (
                  <div className="mb-6">
                    <ImageGallery images={previewData.images} />
                  </div>
                )}
                <div className="space-y-4">
                  <p className="whitespace-pre-wrap">{previewData.description}</p>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <span className="font-semibold">Precio:</span>{" "}
                      {previewData.price
                        ? `$${previewData.price.toLocaleString()}`
                        : "Precio a consultar"}
                    </div>
                    <div>
                      <span className="font-semibold">Año:</span>{" "}
                      {previewData.year || "No especificado"}
                    </div>
                    <div>
                      <span className="font-semibold">Ubicación:</span>{" "}
                      {previewData.location || "No especificada"}
                    </div>
                    <div>
                      <span className="font-semibold">Estado:</span>{" "}
                      {previewData.is_public ? "Público" : "Privado"}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
