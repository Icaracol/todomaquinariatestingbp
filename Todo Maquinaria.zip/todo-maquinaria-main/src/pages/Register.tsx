
import { AuthForm } from "@/components/auth/AuthForm";

export default function Register() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-md mx-auto">
        <AuthForm isRegister />
      </div>
    </div>
  );
}
