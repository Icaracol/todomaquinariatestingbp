
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Check, Rocket, Shield, Zap } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/lib/supabase";

const PLANES = [
  {
    nombre: "Gratis",
    precio: "0",
    caracteristicas: [
      "1 publicación de maquinaria",
      "Listado básico",
      "Soporte por email",
      "Duración: 30 días",
    ],
    boton: "Comenzar Gratis",
    destacado: false,
    icon: Shield,
    gradientClass: "bg-gradient-to-br from-gray-50 to-gray-100",
    path: "/subir-inventario",
    requiresPayment: false
  },
  {
    nombre: "Profesional",
    precio: "29.99",
    caracteristicas: [
      "10 publicaciones de maquinaria",
      "Listados destacados",
      "Soporte prioritario",
      "Estadísticas básicas",
      "Duración: 30 días",
    ],
    boton: "Elegir Plan",
    destacado: true,
    icon: Zap,
    gradientClass: "bg-gradient-to-br from-blue-50 to-indigo-100",
    path: "/checkout",
    requiresPayment: true,
    planId: "plan_profesional"
  },
  {
    nombre: "Empresa",
    precio: "99.99",
    caracteristicas: [
      "Publicaciones ilimitadas",
      "Listados premium",
      "Soporte 24/7",
      "Estadísticas avanzadas",
      "API de integración",
      "Duración: 30 días",
    ],
    boton: "Contactar Ventas",
    destacado: false,
    icon: Rocket,
    gradientClass: "bg-gradient-to-br from-purple-50 to-purple-100",
    path: "/checkout",
    requiresPayment: true,
    planId: "plan_empresa"
  },
];

const VenderMaquinaria = () => {
  const navigate = useNavigate();
  const { toast } = useToast();

  const handlePlanSelection = async (plan: typeof PLANES[0]) => {
    // Para el plan gratuito, guardamos en sessionStorage que es registro gratuito
    // y procedemos al flujo de subida de inventario
    if (!plan.requiresPayment) {
      sessionStorage.setItem('isPlanGratuito', 'true');
      navigate(plan.path);
      return;
    }

    // Verificar autenticación para planes pagos
    const { data: { session } } = await supabase.auth.getSession();
    
    if (!session) {
      // Guardar el plan seleccionado antes de redirigir al login
      sessionStorage.setItem('selectedPlan', JSON.stringify(plan));
      toast({
        title: "Inicio de sesión requerido",
        description: "Para adquirir este plan, necesitas iniciar sesión primero.",
      });
      navigate('/login');
      return;
    }

    // Si está autenticado, redirigir a la página de pago con el plan seleccionado
    navigate(`${plan.path}?plan=${plan.planId}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto space-y-12">
          <div className="text-center space-y-6">
            <h1 className="text-5xl font-bold bg-gradient-to-r from-primary to-blue-600 bg-clip-text text-transparent">
              Vende tu Maquinaria
            </h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Únete a la plataforma líder en compra y venta de maquinaria industrial.
              Elige el plan que mejor se adapte a tus necesidades.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {PLANES.map((plan) => {
              const Icon = plan.icon;
              return (
                <Card
                  key={plan.nombre}
                  className={`relative transform transition-all duration-300 hover:scale-105 ${
                    plan.destacado
                      ? "border-primary shadow-xl"
                      : "border-gray-200 hover:shadow-lg"
                  } ${plan.gradientClass}`}
                >
                  {plan.destacado && (
                    <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                      <span className="bg-primary text-white px-6 py-2 rounded-full text-sm font-medium shadow-lg">
                        Más Popular
                      </span>
                    </div>
                  )}
                  
                  <CardHeader className="text-center pb-2">
                    <Icon className={`w-12 h-12 mx-auto mb-4 ${
                      plan.destacado ? 'text-primary' : 'text-gray-600'
                    }`} />
                    <CardTitle>
                      <div className="text-2xl font-bold mb-1">{plan.nombre}</div>
                      <div className="flex items-center justify-center gap-1">
                        <span className="text-4xl font-bold">${plan.precio}</span>
                        <span className="text-gray-600">/mes</span>
                      </div>
                    </CardTitle>
                  </CardHeader>
                  
                  <CardContent className="space-y-6">
                    <ul className="space-y-4">
                      {plan.caracteristicas.map((caracteristica) => (
                        <li key={caracteristica} className="flex items-center gap-3">
                          <div className={`rounded-full p-1 ${
                            plan.destacado ? 'bg-primary/10 text-primary' : 'bg-gray-100 text-gray-600'
                          }`}>
                            <Check className="h-4 w-4" />
                          </div>
                          <span className="text-gray-600">{caracteristica}</span>
                        </li>
                      ))}
                    </ul>
                    
                    <Button
                      className={`w-full transition-all ${
                        plan.destacado 
                          ? "bg-primary hover:bg-primary/90" 
                          : "bg-white border-2 border-primary text-primary hover:bg-primary/10"
                      }`}
                      variant={plan.destacado ? "default" : "outline"}
                      onClick={() => handlePlanSelection(plan)}
                    >
                      {plan.boton}
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          <div className="text-center mt-12">
            <p className="text-gray-500">
              ¿Necesitas ayuda para elegir? {" "}
              <Link to="/contacto" className="text-primary hover:underline">
                Contáctanos
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VenderMaquinaria;
