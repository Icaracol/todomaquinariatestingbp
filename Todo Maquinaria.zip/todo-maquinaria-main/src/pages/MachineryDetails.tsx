
import { useParams } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/lib/supabase";
import { toast } from "@/components/ui/use-toast";
import { useState, useEffect } from "react";
import { DetailsHeader } from "@/components/machinery/DetailsHeader";
import { DetailsContent } from "@/components/machinery/DetailsContent";
import { DetailsSidebar } from "@/components/machinery/DetailsSidebar";
import type { DetailedMachinery } from "@/types/machinery";

interface MachineryDetailsProps {
  isSellerView?: boolean;
}

export default function MachineryDetails({ isSellerView = false }: MachineryDetailsProps) {
  const { id } = useParams();
  const [session, setSession] = useState<boolean>(false);
  const [showContactForm, setShowContactForm] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(!!session);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(!!session);
    });

    return () => subscription.unsubscribe();
  }, []);

  const { data: machinery, isLoading } = useQuery({
    queryKey: ['machinery', id],
    queryFn: async () => {
      const { data: machineryData, error: machineryError } = await supabase
        .from('machinery')
        .select(`
          *,
          category:categories(*),
          images:machinery_images(*),
          specs:machinery_specs(*)
        `)
        .eq('id', id)
        .single();

      if (machineryError) {
        toast({
          variant: "destructive",
          title: "Error",
          description: "No se pudo cargar la información de la maquinaria"
        });
        throw machineryError;
      }

      // Only increment view count if not in seller view
      if (!isSellerView) {
        await supabase
          .from('machinery')
          .update({ views: (machineryData.views || 0) + 1 })
          .eq('id', id);
      }

      return machineryData as DetailedMachinery;
    }
  });

  const handleContactClick = () => {
    if (session) {
      toast({
        title: "Chat no disponible",
        description: "La función de chat estará disponible próximamente."
      });
    } else {
      setShowContactForm(true);
    }
  };

  const handleMachineryUpdate = (updatedData: Partial<DetailedMachinery>) => {
    queryClient.setQueryData(['machinery', id], updatedData);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-800 flex items-center justify-center">
        <div className="text-white">Cargando...</div>
      </div>
    );
  }

  if (!machinery) {
    return (
      <div className="min-h-screen bg-slate-800 flex items-center justify-center">
        <div className="text-white">Maquinaria no encontrada</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-800 hover:bg-slate-700">
      <div className="container mx-auto px-4 py-8 bg-slate-800 hover:bg-slate-700">
        <DetailsHeader 
          title={machinery.name} 
          isSellerView={isSellerView} 
        />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <DetailsContent 
            machinery={machinery}
            isEditing={isEditing}
            onEditToggle={() => setIsEditing(!isEditing)}
            onUpdate={handleMachineryUpdate}
            isSellerView={isSellerView}
          />
          <DetailsSidebar
            machinery={machinery}
            isSellerView={isSellerView}
            showContactForm={showContactForm}
            onContactClick={handleContactClick}
            isEditing={isEditing}
            onUpdate={handleMachineryUpdate}
          />
        </div>
      </div>
    </div>
  );
}
