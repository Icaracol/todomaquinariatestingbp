
import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ImagePlus, FileText, Check, Sparkles } from "lucide-react";
import InventoryForm from "@/components/subir-inventario/InventoryForm";
import IndicadorPasos from "@/components/subir-inventario/IndicadorPasos";

const PASOS = [
  { num: 1, icon: FileText, label: "Información Básica" },
  { num: 2, icon: ImagePlus, label: "Categoría y Marca" },
  { num: 3, icon: Check, label: "Detalles y Publicación" }
];

const STEP_STORAGE_KEY = 'currentInventoryStep';

const SubirInventario = () => {
  // Initialize state from localStorage or default to step 1
  const [paso, setPaso] = useState(() => {
    const savedStep = localStorage.getItem(STEP_STORAGE_KEY);
    return savedStep ? parseInt(savedStep, 10) : 1;
  });

  // Save current step to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem(STEP_STORAGE_KEY, paso.toString());
    console.log("Current step saved:", paso);
  }, [paso]);

  const siguientePaso = () => {
    setPaso((p) => {
      const newStep = Math.min(p + 1, 3);
      return newStep;
    });
  };

  const pasoAnterior = () => {
    setPaso((p) => {
      const newStep = Math.max(p - 1, 1);
      return newStep;
    });
  };

  return (
    <div className="min-h-screen bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-indigo-50 via-white to-white py-12">
      <div className="container max-w-4xl mx-auto px-4">
        <div className="text-center mb-12 space-y-4">
          <div className="inline-flex items-center justify-center gap-2 bg-indigo-50 text-primary px-4 py-2 rounded-full mb-4">
            <Sparkles className="w-4 h-4" />
            <span className="text-sm font-medium">Plataforma #1 de Maquinaria</span>
          </div>
          
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-indigo-600 bg-clip-text text-transparent">
            Publica tu Maquinaria
          </h1>
          
          <p className="text-gray-600 max-w-2xl mx-auto text-lg">
            Completa la información de tu maquinaria en tres simples pasos.
            Tu anuncio estará visible para miles de compradores potenciales.
          </p>
        </div>

        <IndicadorPasos pasoActual={paso} pasos={PASOS} />

        <Card className="border-none shadow-2xl bg-white/95 backdrop-blur-sm relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-primary/5 to-transparent" />
          
          <CardHeader className="relative border-b bg-gradient-to-r from-indigo-50/50 to-blue-50/50">
            <CardTitle className="text-2xl font-bold text-center text-gray-800">
              {paso === 1 && "Información de tu Maquinaria"}
              {paso === 2 && "Selección de Categoría y Marca"}
              {paso === 3 && "Detalles y Publicación"}
            </CardTitle>
            <p className="text-gray-600 text-center mt-2">
              {paso === 1 && "Completa los datos básicos de la maquinaria que quieres publicar"}
              {paso === 2 && "Selecciona la categoría específica y marca de tu maquinaria"}
              {paso === 3 && "Añade los detalles finales y prepárate para publicar"}
            </p>
          </CardHeader>
          
          <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-primary/10 to-transparent rounded-full -translate-y-1/2 translate-x-1/2" />
          <div className="absolute bottom-0 left-0 w-40 h-40 bg-gradient-to-tr from-blue-500/10 to-transparent rounded-full translate-y-1/2 -translate-x-1/2" />
          
          <CardContent className="p-8 relative">
            <InventoryForm
              paso={paso}
              onNext={siguientePaso}
              onPrevious={pasoAnterior}
            />
          </CardContent>
        </Card>
        
        <div className="mt-8 text-center text-sm text-gray-500">
          <p>¿Necesitas ayuda? Contáctanos en cualquier momento</p>
        </div>
      </div>
    </div>
  );
};

export default SubirInventario;
