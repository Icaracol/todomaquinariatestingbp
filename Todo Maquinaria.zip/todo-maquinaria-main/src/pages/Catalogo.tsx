
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { supabase } from "@/lib/supabase";
import { Link } from "react-router-dom";
import { ArrowLeft, Store } from "lucide-react";
import { SearchFilters } from "@/components/catalogo/SearchFilters";
import { MachineryGrid } from "@/components/catalogo/MachineryGrid";
import { ExternalResults } from "@/components/catalogo/ExternalResults";
import type { DbMachinery } from "@/types/machinery";

const Catalogo = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialQuery = searchParams.get("q") || "";
  const [searchTerm, setSearchTerm] = useState(initialQuery);
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [priceRange, setPriceRange] = useState([0, 1000000]);
  const [yearRange, setYearRange] = useState([1970, 2024]);
  const [location, setLocation] = useState<string>("");

  const { data: categories } = useQuery({
    queryKey: ['categories'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('categories')
        .select('*')
        .order('name');
      if (error) throw error;
      return data;
    }
  });

  const { data: machinery, isLoading } = useQuery({
    queryKey: ['machinery', searchTerm, selectedCategory, priceRange, yearRange, location],
    queryFn: async () => {
      let query = supabase
        .from('machinery')
        .select(`
          *,
          category:categories(name),
          images:machinery_images(url, is_primary)
        `)
        .eq('status', 'available')
        .eq('is_public', true);

      if (searchTerm) {
        query = query.ilike('name', `%${searchTerm}%`);
      }

      if (selectedCategory && selectedCategory !== 'all') {
        query = query.eq('category_id', selectedCategory);
      }

      if (location) {
        query = query.ilike('location', `%${location}%`);
      }

      query = query
        .gte('price', priceRange[0])
        .lte('price', priceRange[1])
        .gte('year', yearRange[0])
        .lte('year', yearRange[1]);

      const { data, error } = await query;
      if (error) throw error;
      return data as (DbMachinery & {
        category: { name: string } | null;
        images: { url: string; is_primary: boolean }[];
      })[];
    },
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchParams({ q: searchTerm });
  };

  return (
    <div className="min-h-screen bg-[#111A23]">
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center gap-4 mb-8">
          <Link to="/">
            <Button variant="outline" size="icon" className="bg-white hover:bg-gray-100">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-white flex items-center gap-2">
              <Store className="h-6 w-6" />
              Marketplace de Maquinaria
            </h1>
            <p className="text-gray-400 mt-1">
              Explora nuestra selección de maquinaria disponible
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <div className="lg:col-span-1">
            <SearchFilters
              searchTerm={searchTerm}
              setSearchTerm={setSearchTerm}
              selectedCategory={selectedCategory}
              setSelectedCategory={setSelectedCategory}
              location={location}
              setLocation={setLocation}
              priceRange={priceRange}
              setPriceRange={setPriceRange}
              yearRange={yearRange}
              setYearRange={setYearRange}
              categories={categories}
              onSubmit={handleSearch}
            />
          </div>

          <div className="lg:col-span-3 space-y-8">
            <MachineryGrid 
              machinery={machinery}
              isLoading={isLoading}
            />
            <ExternalResults searchTerm={searchTerm} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Catalogo;
