
import { useState, useEffect, Suspense } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/lib/supabase";
import { Header } from "@/components/home/Header";
import { HeroSection } from "@/components/home/HeroSection";
import { FeaturedMachinery } from "@/components/home/FeaturedMachinery";
import { FeaturesSection } from "@/components/home/FeaturesSection";
import { CTASection } from "@/components/home/CTASection";

const Index = () => {
  const [session, setSession] = useState(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });

    return () => subscription.unsubscribe();
  }, []);

  const { data: featuredMachinery, isLoading } = useQuery({
    queryKey: ['featured-machinery'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('machinery')
        .select(`
          *,
          category:categories(name),
          images:machinery_images(url, is_primary)
        `)
        .eq('status', 'available')
        .order('views', { ascending: false })
        .limit(6);

      if (error) throw error;
      return data;
    },
  });

  useEffect(() => {
    if (featuredMachinery) {
      featuredMachinery.forEach(machine => {
        const primaryImage = machine.images?.find(img => img.is_primary)?.url;
        if (primaryImage) {
          const img = new Image();
          img.src = primaryImage;
        }
      });
    }
  }, [featuredMachinery]);

  return (
    <div className="min-h-screen w-full bg-[#111A23] overflow-x-hidden">
      <Header session={session} />
      <main className="w-full">
        <HeroSection />
        <Suspense fallback={<div className="text-center text-white py-12">Cargando maquinaria destacada...</div>}>
          <FeaturedMachinery machinery={featuredMachinery} />
        </Suspense>
        <FeaturesSection />
        <CTASection />
      </main>
    </div>
  );
};

export default Index;
