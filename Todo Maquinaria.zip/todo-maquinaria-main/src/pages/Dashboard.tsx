
import { Tabs } from "@/components/ui/tabs";
import { DashboardHeader } from "@/components/dashboard/DashboardHeader";
import { DashboardNav } from "@/components/dashboard/DashboardNav";
import { StatCards } from "@/components/dashboard/StatCards";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/lib/supabase";
import { useDashboard } from "@/components/dashboard/useDashboard";
import { useEffect, useState } from "react";
import { useAdmin } from "@/hooks/useAdmin";
import { AdminEditModeToggle } from "@/components/dashboard/AdminEditModeToggle";
import { DashboardTabs } from "@/components/dashboard/navigation/DashboardTabs";
import { DashboardContent } from "@/components/dashboard/content/DashboardContent";

export default function Dashboard() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState(() => localStorage.getItem("dashboardTab") || "inventario");
  const [isAdmin, setIsAdmin] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const { isAdmin: checkIsAdmin } = useAdmin();
  
  const {
    loading,
    machinery,
    searchTerm,
    statusFilter,
    stats,
    setSearchTerm,
    setStatusFilter,
    fetchMachinery
  } = useDashboard();

  useEffect(() => {
    localStorage.setItem("dashboardTab", activeTab);
  }, [activeTab]);

  useEffect(() => {
    const checkAdminStatus = async () => {
      const adminStatus = await checkIsAdmin();
      setIsAdmin(adminStatus);
    };
    checkAdminStatus();
  }, []);

  useEffect(() => {
    const savedEditMode = localStorage.getItem("adminEditMode");
    if (savedEditMode) {
      setIsEditMode(savedEditMode === "true");
    }
  }, []);

  const handleEditModeChange = (enabled: boolean) => {
    setIsEditMode(enabled);
    localStorage.setItem("adminEditMode", enabled.toString());
    toast({
      title: enabled ? "Modo edición activado" : "Modo edición desactivado",
      description: enabled 
        ? "Ahora puedes editar el contenido de la aplicación" 
        : "Los cambios han sido guardados",
    });
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (file.type !== 'text/csv') {
      toast({
        title: "Error",
        description: "Por favor, selecciona un archivo CSV válido",
        variant: "destructive"
      });
      return;
    }
    const formData = new FormData();
    formData.append('file', file);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user?.id) {
        toast({
          title: "Error",
          description: "Debes iniciar sesión para importar maquinaria",
          variant: "destructive"
        });
        return;
      }
      const response = await supabase.functions.invoke('batch-machinery-upload', {
        body: formData,
        headers: {
          'x-user-id': session.user.id
        }
      });
      if (response.error) {
        throw new Error(response.error.message);
      }
      toast({
        title: "¡Importación exitosa!",
        description: `Se importaron ${response.data.count} máquinas correctamente`
      });
      fetchMachinery();
    } catch (error) {
      console.error('Error importing machinery:', error);
      toast({
        title: "Error en la importación",
        description: "Hubo un problema al importar el archivo. Por favor, revisa el formato e intenta nuevamente.",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-lime-50 via-white to-blue-50">
      <DashboardNav />
      <div className="flex-1 container mx-auto px-4 py-8">
        <DashboardHeader onImportClick={() => document.getElementById('csvInput')?.click()} />
        <input type="file" id="csvInput" accept=".csv" className="hidden" onChange={handleFileUpload} />

        {isAdmin && (
          <AdminEditModeToggle
            isEnabled={isEditMode}
            onToggle={handleEditModeChange}
          />
        )}

        <StatCards stats={stats} />

        <div className="rounded-2xl bg-white/80 backdrop-blur-sm shadow-xl border border-lime-100 p-6 transition-all duration-300 hover:shadow-lg">
          <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <DashboardTabs isAdmin={isAdmin} isEditMode={isEditMode} />
            <DashboardContent
              isAdmin={isAdmin}
              isEditMode={isEditMode}
              loading={loading}
              machinery={machinery}
              searchTerm={searchTerm}
              statusFilter={statusFilter}
              onSearchChange={setSearchTerm}
              onStatusChange={setStatusFilter}
            />
          </Tabs>
        </div>
      </div>
    </div>
  );
}
