
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Shield, Users } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useAdmin } from "@/hooks/useAdmin";
import type { UserAdminData, UserRole } from "@/types/admin";
import { format } from "date-fns";
import { Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function AdminPanelPage() {
  const { loading, getUserList, updateUserRole, resetUserLimits, isAdmin } = useAdmin();
  const [users, setUsers] = useState<UserAdminData[]>([]);
  const [updatingUser, setUpdatingUser] = useState<string | null>(null);
  const [isLoadingAdmin, setIsLoadingAdmin] = useState(true);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    const checkAdminAccess = async () => {
      const adminStatus = await isAdmin();
      if (!adminStatus) {
        toast({
          title: "Acceso denegado",
          description: "No tienes permisos para acceder al panel de administración",
          variant: "destructive",
        });
        navigate("/dashboard");
        return;
      }
      setIsLoadingAdmin(false);
    };

    checkAdminAccess();
  }, []);

  useEffect(() => {
    if (!isLoadingAdmin) {
      loadUsers();
    }
  }, [isLoadingAdmin]);

  const loadUsers = async () => {
    const userList = await getUserList();
    console.log('Loaded users:', userList); // Para debugging
    setUsers(userList);
  };

  const handleRoleChange = async (userId: string, newRole: UserRole) => {
    setUpdatingUser(userId);
    const success = await updateUserRole(userId, newRole);
    if (success) await loadUsers();
    setUpdatingUser(null);
  };

  const handleResetLimits = async (userId: string) => {
    setUpdatingUser(userId);
    const success = await resetUserLimits(userId);
    if (success) await loadUsers();
    setUpdatingUser(null);
  };

  if (isLoadingAdmin || loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-lime-600" />
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex items-center gap-3 mb-8">
        <Shield className="h-8 w-8 text-lime-600" />
        <h1 className="text-2xl font-bold">Panel de Administración</h1>
      </div>

      <div className="bg-white rounded-lg shadow-lg p-6">
        <div className="flex items-center gap-2 mb-6">
          <Users className="h-5 w-5" />
          <h2 className="text-xl font-semibold">Gestión de Usuarios</h2>
        </div>
        
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Email</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Maquinaria</TableHead>
                <TableHead>Descargas</TableHead>
                <TableHead>Último Reset</TableHead>
                <TableHead>Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {users.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-4">
                    No hay usuarios registrados
                  </TableCell>
                </TableRow>
              ) : (
                users.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium">{user.email}</TableCell>
                    <TableCell>
                      <Select
                        value={user.role}
                        onValueChange={(value: UserRole) =>
                          handleRoleChange(user.id, value)
                        }
                        disabled={updatingUser === user.id}
                      >
                        <SelectTrigger className="w-32">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectGroup>
                            <SelectItem value="free">Free</SelectItem>
                            <SelectItem value="premium">Premium</SelectItem>
                            <SelectItem value="super_premium">Super Premium</SelectItem>
                          </SelectGroup>
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell>{user.machineryCount}</TableCell>
                    <TableCell>{user.downloadsCount}</TableCell>
                    <TableCell>
                      {user.downloadsResetDate
                        ? format(new Date(user.downloadsResetDate), 'dd/MM/yyyy')
                        : 'Nunca'}
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleResetLimits(user.id)}
                        disabled={updatingUser === user.id}
                      >
                        {updatingUser === user.id ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          'Reset Límites'
                        )}
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
}
