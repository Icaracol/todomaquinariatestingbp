
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/lib/supabase";

const pricingPlans = [
  {
    name: "Básico",
    price: "65",
    description: "Dueños de negocios pequeños y usuarios individuales que desean comenzar a digitalizar su inventario.",
    trialDays: 7,
    features: [
      "1 Producto/Servicio publicado",
      "Administra tu oferta",
      "Gestión de clientes en Busca Maquinaria",
      "Compartir tu oferta en la red de Busca Maquinaria",
      "1 usuario",
      "1 sesión de 1 hora en un día hábil para aprender y conocer BMAQ",
      "Asistencia ante cualquier problema en la plataforma"
    ],
    role: "basic",
    cta: "Acceder a los beneficios"
  },
  {
    name: "Profesional",
    price: "200",
    description: "Vendedores y brokers que buscan crecimiento y mayor control en su gestión.",
    trialDays: null,
    features: [
      "Todo lo incluido en Plan Básico",
      "Gestiona clientes dentro y fuera de Busca Maquinaria",
      "Hasta 30 productos/servicios",
      "2 sesiones de 1 hora en días hábiles para aprender y conocer BMAQ"
    ],
    role: "professional",
    cta: "Acceder a los beneficios"
  },
  {
    name: "Empresarial",
    price: "300",
    description: "Equipos de ventas y grandes negocios que desean llevar sus operaciones al siguiente nivel.",
    trialDays: null,
    features: [
      "Todo lo incluido en Plan Profesional",
      "Hasta 50 productos/servicios",
      "10 usuarios",
      "3 sesiones de 1 hora en días hábiles para aprender y conocer BMAQ"
    ],
    role: "enterprise",
    cta: "Acceder a los beneficios"
  },
  {
    name: "Partner",
    price: null,
    description: "Grandes empresas que necesitan una solución completamente personalizada.",
    trialDays: null,
    features: [
      "Todo lo incluido en Plan Empresarial",
      "Accede a las ofertas exclusivas de BMAQ",
      "Funciones extra a la medida"
    ],
    role: "partner",
    cta: "Contactar ahora"
  }
];

export default function PricingPage() {
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSelectPlan = async (role: string) => {
    try {
      if (role === 'partner') {
        toast({
          title: "Plan Partner",
          description: "Te contactaremos pronto para discutir tu plan personalizado"
        });
        // TODO: Implementar lógica de contacto
        return;
      }

      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        toast({
          title: "Inicia sesión",
          description: "Debes iniciar sesión para seleccionar un plan",
          variant: "destructive"
        });
        navigate("/login");
        return;
      }

      const plan = pricingPlans.find(p => p.role === role);
      let trialEndDate = null;
      
      if (role === 'basic' && plan?.trialDays) {
        trialEndDate = new Date();
        trialEndDate.setDate(trialEndDate.getDate() + plan.trialDays);
      }

      const { error } = await supabase
        .from('user_limits')
        .update({ 
          subscription_tier: role,
          trial_end_date: trialEndDate ? trialEndDate.toISOString() : null,
          updated_at: new Date().toISOString()
        })
        .eq('user_id', user.id);

      if (error) throw error;

      const toastMessage = role === 'basic' 
        ? `Has seleccionado el plan ${role} con ${plan.trialDays} días de prueba gratis`
        : `Has seleccionado el plan ${role}`;

      toast({
        title: "Plan actualizado",
        description: toastMessage
      });
      
      navigate("/dashboard");
    } catch (error) {
      console.error('Error updating plan:', error);
      toast({
        title: "Error",
        description: "No se pudo actualizar el plan",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="bg-white">
      <div className="mx-auto max-w-7xl px-4 py-24 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
            Planes y Precios
          </h2>
          <p className="mt-4 text-lg text-gray-600">
            Elige el plan que mejor se adapte a tus necesidades
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {pricingPlans.map((plan) => (
            <div
              key={plan.name}
              className="rounded-2xl border border-gray-200 p-8 shadow-sm transition-all hover:shadow-lg"
            >
              <h3 className="text-2xl font-semibold text-gray-900">{plan.name}</h3>
              {plan.price ? (
                <p className="mt-4 flex items-baseline">
                  <span className="text-5xl font-bold tracking-tight text-gray-900">
                    ${plan.price}
                  </span>
                  <span className="ml-1 text-xl font-semibold text-gray-500">/mes</span>
                </p>
              ) : (
                <p className="mt-4 text-xl font-semibold text-gray-900">
                  Contacta a un asesor
                </p>
              )}
              {plan.trialDays && (
                <p className="mt-2 text-sm text-lime-600 font-medium">
                  {plan.trialDays} días de prueba gratis
                </p>
              )}
              <p className="mt-4 text-sm text-gray-600">
                {plan.description}
              </p>
              <ul className="mt-8 space-y-4">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-start">
                    <Check className="h-5 w-5 text-lime-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700 text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
              <Button
                variant="primary"
                className="mt-8 w-full"
                onClick={() => handleSelectPlan(plan.role)}
              >
                {plan.cta}
              </Button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
