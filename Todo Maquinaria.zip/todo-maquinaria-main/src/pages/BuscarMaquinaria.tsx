
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Search } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { getMaquinaria } from "@/services/api";
import { useToast } from "@/hooks/use-toast";

const CATEGORIAS = [
  "Todas",
  // Maquinaria Pesada
  "Excavadoras",
  "Bulldozers",
  "Grúas",
  "Cargadoras",
  "Retroexcavadoras",
  "Motoniveladoras",
  "Compactadoras",
  // Maquinaria Agrícola
  "Tractores",
  "Cosechadoras",
  "Sembradoras",
  "Fumigadoras",
  "Empacadoras",
  "Arados",
  // Maquinaria para Plásticos
  "Inyectoras",
  "Extrusoras",
  "Sopladoras",
  "Termoformadoras",
  "Molinos",
  "Mezcladoras",
];

const BuscarMaquinaria = () => {
  const { toast } = useToast();
  const [busqueda, setBusqueda] = useState("");
  const [categoria, setCategoria] = useState("Todas");
  const [hasSearched, setHasSearched] = useState(false);

  const { data: maquinarias = [], isLoading, error } = useQuery({
    queryKey: ["maquinaria"],
    queryFn: getMaquinaria,
    enabled: hasSearched,
    meta: {
      onError: () => {
        toast({
          variant: "destructive",
          title: "Error",
          description: "No se pudo cargar la lista de maquinarias. Por favor, intente más tarde.",
        });
      }
    }
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setHasSearched(true);
  };

  const maquinariasFiltradas = maquinarias.filter((maquina) => {
    const cumpleBusqueda = maquina.nombre
      .toLowerCase()
      .includes(busqueda.toLowerCase());
    const cumpleCategoria =
      categoria === "Todas" || maquina.categoria === categoria;

    return cumpleBusqueda && cumpleCategoria;
  });

  const formatPrice = (price: number | null) => {
    if (price === null || price === undefined) {
      return "Precio no disponible";
    }
    return `$${price.toLocaleString()}`;
  };

  return (
    <div className="container mx-auto px-4">
      <div className="max-w-3xl mx-auto space-y-8">
        <div className={`text-center transition-all duration-500 ${hasSearched ? 'pt-8' : 'pt-32'}`}>
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Somos tu Google de compra y venta de maquinaria
          </h1>
          {!hasSearched && (
            <p className="text-gray-600 text-lg mb-8">
              Encuentra la maquinaria perfecta para tu negocio
            </p>
          )}
        </div>

        <form onSubmit={handleSearch} className="space-y-4">
          <div className="flex gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <Input
                type="search"
                placeholder="Buscar maquinaria..."
                value={busqueda}
                onChange={(e) => setBusqueda(e.target.value)}
                className="pl-10 w-full h-12 text-lg"
              />
            </div>
            <Select value={categoria} onValueChange={setCategoria}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Categoría" />
              </SelectTrigger>
              <SelectContent>
                {CATEGORIAS.map((cat) => (
                  <SelectItem key={cat} value={cat}>
                    {cat}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </form>

        {hasSearched && (
          <div className="mt-8">
            {isLoading ? (
              <p className="text-center py-8">Buscando maquinarias...</p>
            ) : error ? (
              <p className="text-center py-8 text-red-600">
                Error al buscar maquinarias. Por favor, intente de nuevo.
              </p>
            ) : maquinariasFiltradas.length === 0 ? (
              <p className="text-center py-8">No se encontraron resultados para tu búsqueda</p>
            ) : (
              <div className="space-y-4">
                {maquinariasFiltradas.map((maquina) => (
                  <Card key={maquina.id} className="hover:shadow-lg transition-shadow">
                    <CardContent className="flex gap-4 p-4">
                      <img
                        src={maquina.imagen || "/placeholder.svg"}
                        alt={maquina.nombre}
                        className="w-32 h-32 object-cover rounded"
                      />
                      <div>
                        <h3 className="text-lg font-semibold">{maquina.nombre}</h3>
                        <p className="text-primary font-bold">
                          {formatPrice(maquina.precio)}
                        </p>
                        <p className="text-sm text-gray-600">
                          {maquina.categoria} - Año {maquina.año}
                        </p>
                        <p className="text-sm text-gray-600">{maquina.ubicacion}</p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default BuscarMaquinaria;
